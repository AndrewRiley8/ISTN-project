﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddNewPersonForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtIDNum = New System.Windows.Forms.TextBox()
        Me.btnChoose = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cmbGender = New System.Windows.Forms.ComboBox()
        Me.cmbRace = New System.Windows.Forms.ComboBox()
        Me.cboxDisability = New System.Windows.Forms.CheckBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPostCode = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtPhoneNum = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtBranchName = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtBankName = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.DateTimePickerHired = New System.Windows.Forms.DateTimePicker()
        Me.txtBranchCode = New System.Windows.Forms.TextBox()
        Me.txtMonthlySalary = New System.Windows.Forms.TextBox()
        Me.txtBankAcctNo = New System.Windows.Forms.TextBox()
        Me.txtTaxNo = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.btnFinAdd = New System.Windows.Forms.Button()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.txtIDNum)
        Me.GroupBox3.Controls.Add(Me.btnChoose)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.cmbGender)
        Me.GroupBox3.Controls.Add(Me.cmbRace)
        Me.GroupBox3.Controls.Add(Me.cboxDisability)
        Me.GroupBox3.Controls.Add(Me.txtFirstName)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.txtPosition)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.txtPostCode)
        Me.GroupBox3.Controls.Add(Me.txtCity)
        Me.GroupBox3.Controls.Add(Me.txtStreet)
        Me.GroupBox3.Controls.Add(Me.txtEmail)
        Me.GroupBox3.Controls.Add(Me.txtPhoneNum)
        Me.GroupBox3.Controls.Add(Me.txtLastName)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(524, 375)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Personal Details"
        '
        'txtIDNum
        '
        Me.txtIDNum.Location = New System.Drawing.Point(252, 21)
        Me.txtIDNum.Name = "txtIDNum"
        Me.txtIDNum.Size = New System.Drawing.Size(258, 22)
        Me.txtIDNum.TabIndex = 42
        '
        'btnChoose
        '
        Me.btnChoose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnChoose.Location = New System.Drawing.Point(435, 332)
        Me.btnChoose.Name = "btnChoose"
        Me.btnChoose.Size = New System.Drawing.Size(75, 32)
        Me.btnChoose.TabIndex = 57
        Me.btnChoose.Text = "Choose"
        Me.btnChoose.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(17, 24)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(72, 16)
        Me.Label15.TabIndex = 41
        Me.Label15.Text = "ID number:"
        '
        'cmbGender
        '
        Me.cmbGender.FormattingEnabled = True
        Me.cmbGender.Items.AddRange(New Object() {"Female", "Male", "Other", "Unspecified"})
        Me.cmbGender.Location = New System.Drawing.Point(252, 251)
        Me.cmbGender.Name = "cmbGender"
        Me.cmbGender.Size = New System.Drawing.Size(258, 24)
        Me.cmbGender.TabIndex = 56
        '
        'cmbRace
        '
        Me.cmbRace.FormattingEnabled = True
        Me.cmbRace.Items.AddRange(New Object() {"European", "Indian", "African", "Asian", "Other"})
        Me.cmbRace.Location = New System.Drawing.Point(252, 284)
        Me.cmbRace.Name = "cmbRace"
        Me.cmbRace.Size = New System.Drawing.Size(258, 24)
        Me.cmbRace.TabIndex = 55
        '
        'cboxDisability
        '
        Me.cboxDisability.AutoSize = True
        Me.cboxDisability.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cboxDisability.Location = New System.Drawing.Point(20, 311)
        Me.cboxDisability.Name = "cboxDisability"
        Me.cboxDisability.Size = New System.Drawing.Size(247, 20)
        Me.cboxDisability.TabIndex = 38
        Me.cboxDisability.TabStop = False
        Me.cboxDisability.Text = "Has a Disability:                                         "
        Me.cboxDisability.UseVisualStyleBackColor = True
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(252, 49)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(258, 22)
        Me.txtFirstName.TabIndex = 37
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(17, 282)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 16)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "Race:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(17, 254)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 16)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Gender:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(17, 226)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 16)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Postal code:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 197)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 16)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "City"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(17, 340)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(59, 16)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "Position:"
        '
        'txtPosition
        '
        Me.txtPosition.Location = New System.Drawing.Point(252, 337)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.ReadOnly = True
        Me.txtPosition.Size = New System.Drawing.Size(177, 22)
        Me.txtPosition.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(17, 167)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(157, 16)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Street name and number:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 139)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 16)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Email address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 16)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Phone number:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 81)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 16)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Last name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 16)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "First name:"
        '
        'txtPostCode
        '
        Me.txtPostCode.Location = New System.Drawing.Point(252, 223)
        Me.txtPostCode.Name = "txtPostCode"
        Me.txtPostCode.Size = New System.Drawing.Size(258, 22)
        Me.txtPostCode.TabIndex = 6
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(252, 194)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(258, 22)
        Me.txtCity.TabIndex = 5
        '
        'txtStreet
        '
        Me.txtStreet.Location = New System.Drawing.Point(252, 164)
        Me.txtStreet.Name = "txtStreet"
        Me.txtStreet.Size = New System.Drawing.Size(258, 22)
        Me.txtStreet.TabIndex = 4
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(252, 136)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(258, 22)
        Me.txtEmail.TabIndex = 3
        '
        'txtPhoneNum
        '
        Me.txtPhoneNum.Location = New System.Drawing.Point(252, 107)
        Me.txtPhoneNum.Name = "txtPhoneNum"
        Me.txtPhoneNum.Size = New System.Drawing.Size(258, 22)
        Me.txtPhoneNum.TabIndex = 2
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(252, 78)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(258, 22)
        Me.txtLastName.TabIndex = 1
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.txtBranchName)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.txtBankName)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.DateTimePickerHired)
        Me.GroupBox4.Controls.Add(Me.txtBranchCode)
        Me.GroupBox4.Controls.Add(Me.txtMonthlySalary)
        Me.GroupBox4.Controls.Add(Me.txtBankAcctNo)
        Me.GroupBox4.Controls.Add(Me.txtTaxNo)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox4.Location = New System.Drawing.Point(551, 12)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(476, 216)
        Me.GroupBox4.TabIndex = 8
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Compensation Details"
        '
        'txtBranchName
        '
        Me.txtBranchName.Location = New System.Drawing.Point(255, 186)
        Me.txtBranchName.Name = "txtBranchName"
        Me.txtBranchName.Size = New System.Drawing.Size(212, 22)
        Me.txtBranchName.TabIndex = 32
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(20, 189)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(127, 16)
        Me.Label10.TabIndex = 31
        Me.Label10.Text = "Bank Branch Name:"
        '
        'txtBankName
        '
        Me.txtBankName.Location = New System.Drawing.Point(255, 101)
        Me.txtBankName.Name = "txtBankName"
        Me.txtBankName.Size = New System.Drawing.Size(212, 22)
        Me.txtBankName.TabIndex = 30
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(20, 104)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 16)
        Me.Label14.TabIndex = 29
        Me.Label14.Text = "Bank Name:"
        '
        'DateTimePickerHired
        '
        Me.DateTimePickerHired.Location = New System.Drawing.Point(255, 19)
        Me.DateTimePickerHired.Name = "DateTimePickerHired"
        Me.DateTimePickerHired.Size = New System.Drawing.Size(212, 22)
        Me.DateTimePickerHired.TabIndex = 28
        '
        'txtBranchCode
        '
        Me.txtBranchCode.Location = New System.Drawing.Point(255, 157)
        Me.txtBranchCode.Name = "txtBranchCode"
        Me.txtBranchCode.Size = New System.Drawing.Size(212, 22)
        Me.txtBranchCode.TabIndex = 27
        '
        'txtMonthlySalary
        '
        Me.txtMonthlySalary.Location = New System.Drawing.Point(255, 46)
        Me.txtMonthlySalary.Name = "txtMonthlySalary"
        Me.txtMonthlySalary.Size = New System.Drawing.Size(212, 22)
        Me.txtMonthlySalary.TabIndex = 24
        '
        'txtBankAcctNo
        '
        Me.txtBankAcctNo.Location = New System.Drawing.Point(255, 129)
        Me.txtBankAcctNo.Name = "txtBankAcctNo"
        Me.txtBankAcctNo.Size = New System.Drawing.Size(212, 22)
        Me.txtBankAcctNo.TabIndex = 25
        '
        'txtTaxNo
        '
        Me.txtTaxNo.Location = New System.Drawing.Point(255, 73)
        Me.txtTaxNo.Name = "txtTaxNo"
        Me.txtTaxNo.Size = New System.Drawing.Size(212, 22)
        Me.txtTaxNo.TabIndex = 23
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(20, 132)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(140, 16)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "Bank account number:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(20, 47)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(117, 16)
        Me.Label18.TabIndex = 12
        Me.Label18.Text = "Monthly base pay:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(20, 160)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(123, 16)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Bank Branch Code:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(20, 76)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(82, 16)
        Me.Label21.TabIndex = 9
        Me.Label21.Text = "Tax number:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(20, 24)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(73, 16)
        Me.Label23.TabIndex = 7
        Me.Label23.Text = "Date hired:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(12, 404)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(254, 31)
        Me.btnBack.TabIndex = 9
        Me.btnBack.Text = "Back to Applicants"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'btnFinAdd
        '
        Me.btnFinAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFinAdd.Location = New System.Drawing.Point(551, 356)
        Me.btnFinAdd.Name = "btnFinAdd"
        Me.btnFinAdd.Size = New System.Drawing.Size(476, 31)
        Me.btnFinAdd.TabIndex = 10
        Me.btnFinAdd.Text = "Add This "
        Me.btnFinAdd.UseVisualStyleBackColor = True
        '
        'AddNewPersonForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(1039, 447)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnFinAdd)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "AddNewPersonForm"
        Me.Text = "New"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnChoose As Button
    Friend WithEvents cmbGender As ComboBox
    Friend WithEvents cmbRace As ComboBox
    Protected Friend WithEvents cboxDisability As CheckBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents txtPosition As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtPostCode As TextBox
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtStreet As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtPhoneNum As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents txtBranchName As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtBankName As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents DateTimePickerHired As DateTimePicker
    Friend WithEvents txtBranchCode As TextBox
    Friend WithEvents txtMonthlySalary As TextBox
    Friend WithEvents txtBankAcctNo As TextBox
    Friend WithEvents txtTaxNo As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents txtIDNum As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents btnFinAdd As Button
End Class
