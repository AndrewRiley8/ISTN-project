﻿

Partial Public Class ist2dsDataSet
End Class


Partial Public Class ist2dsDataSet
End Class



Namespace ist2dsDataSetTableAdapters

    Partial Public Class AbsenceTableAdapter
    End Class
End Namespace
