﻿Public Class ApptGuestForm
    Public AptNum As Integer
    Private Sub ApptGuestForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Employee' table. You can move, or remove it, as needed.
        'Me.EmployeeTableAdapter.Fill(Me.Ist2dsDataSet.Employee)

    End Sub

    'RADIO BUTTONS
    Private Sub rdbAddGuests_CheckedChanged(sender As Object, e As EventArgs) Handles rdbAddGuests.CheckedChanged
        btnAddRemove.Text = "Add"
        'select all from employees where not

    End Sub

    Private Sub rdbRemoveGuests_CheckedChanged(sender As Object, e As EventArgs) Handles rdbRemoveGuests.CheckedChanged
        btnAddRemove.Text = "Remove"
        'select all from employees where employeeID in (select employeeID from appt_guest where appoinmentNumber =@apptNum)
    End Sub

    Private Sub Label7_MouseHover(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Functions.searchEmployee(Me.Ist2dsDataSet.Employee, Me.EmployeeTableAdapter, txtSearchEmployeeID.Text, txtSearchEmployeeFirstName.Text, txtSearchEmployeeLastName.Text, "All")
    End Sub

    Private Sub btnAddRemove_Click(sender As Object, e As EventArgs) Handles btnAddRemove.Click
        If rdbAddGuests.Checked Then
            Functions.addAppt_Guest(AptNum, txtEmployeeID.Text)
        Else
            Functions.removeApptGuest(AptNum, txtEmployeeID.Text)
        End If
    End Sub
End Class