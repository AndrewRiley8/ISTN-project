﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EmployeeSelectionForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtSearchEmployeeID = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSearchEmployeeLastName = New System.Windows.Forms.TextBox()
        Me.txtSearchEmployeeFirstName = New System.Windows.Forms.TextBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.EmployeeIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhonenumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailaddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StreetnumberandnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PostalcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateofhireDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateofterminationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RaceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GenderDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DisabilitystatusDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.MonthlybasesalaryDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BanknameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BankaccountnumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BankbranchnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BankbranchcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TaxnumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PositionnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ist2dsDataSet = New ISTN212Project.ist2dsDataSet()
        Me.EmployeeTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.EmployeeTableAdapter()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtEmployeeLastName = New System.Windows.Forms.TextBox()
        Me.txtEmployeeFirstName = New System.Windows.Forms.TextBox()
        Me.btnSelect = New System.Windows.Forms.Button()
        Me.cmbDepartment = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.cmbDepartment)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.btnSearch)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.txtSearchEmployeeID)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.txtSearchEmployeeLastName)
        Me.GroupBox3.Controls.Add(Me.txtSearchEmployeeFirstName)
        Me.GroupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Location = New System.Drawing.Point(12, 188)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(336, 196)
        Me.GroupBox3.TabIndex = 7
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Navigation"
        '
        'btnSearch
        '
        Me.btnSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSearch.Location = New System.Drawing.Point(6, 158)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 32)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(11, 28)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(89, 16)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "Employee ID:"
        '
        'txtSearchEmployeeID
        '
        Me.txtSearchEmployeeID.Location = New System.Drawing.Point(106, 25)
        Me.txtSearchEmployeeID.Name = "txtSearchEmployeeID"
        Me.txtSearchEmployeeID.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeID.TabIndex = 28
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 16)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "First name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 16)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Last name:"
        '
        'txtSearchEmployeeLastName
        '
        Me.txtSearchEmployeeLastName.Location = New System.Drawing.Point(106, 85)
        Me.txtSearchEmployeeLastName.Name = "txtSearchEmployeeLastName"
        Me.txtSearchEmployeeLastName.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeLastName.TabIndex = 40
        '
        'txtSearchEmployeeFirstName
        '
        Me.txtSearchEmployeeFirstName.Location = New System.Drawing.Point(106, 56)
        Me.txtSearchEmployeeFirstName.Name = "txtSearchEmployeeFirstName"
        Me.txtSearchEmployeeFirstName.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeFirstName.TabIndex = 39
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(12, 390)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(98, 31)
        Me.btnBack.TabIndex = 10
        Me.btnBack.Text = "Back to menu"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.EmployeeIDDataGridViewTextBoxColumn, Me.FirstnameDataGridViewTextBoxColumn, Me.LastnameDataGridViewTextBoxColumn, Me.PhonenumberDataGridViewTextBoxColumn, Me.EmailaddressDataGridViewTextBoxColumn, Me.StreetnumberandnameDataGridViewTextBoxColumn, Me.CityDataGridViewTextBoxColumn, Me.PostalcodeDataGridViewTextBoxColumn, Me.DateofhireDataGridViewTextBoxColumn, Me.DateofterminationDataGridViewTextBoxColumn, Me.RaceDataGridViewTextBoxColumn, Me.GenderDataGridViewTextBoxColumn, Me.DisabilitystatusDataGridViewCheckBoxColumn, Me.MonthlybasesalaryDataGridViewTextBoxColumn, Me.BanknameDataGridViewTextBoxColumn, Me.BankaccountnumberDataGridViewTextBoxColumn, Me.BankbranchnameDataGridViewTextBoxColumn, Me.BankbranchcodeDataGridViewTextBoxColumn, Me.TaxnumberDataGridViewTextBoxColumn, Me.PositionnameDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.EmployeeBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(13, 13)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(676, 150)
        Me.DataGridView1.TabIndex = 11
        '
        'EmployeeIDDataGridViewTextBoxColumn
        '
        Me.EmployeeIDDataGridViewTextBoxColumn.DataPropertyName = "employee_ID"
        Me.EmployeeIDDataGridViewTextBoxColumn.HeaderText = "employee_ID"
        Me.EmployeeIDDataGridViewTextBoxColumn.Name = "EmployeeIDDataGridViewTextBoxColumn"
        Me.EmployeeIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'FirstnameDataGridViewTextBoxColumn
        '
        Me.FirstnameDataGridViewTextBoxColumn.DataPropertyName = "first_name"
        Me.FirstnameDataGridViewTextBoxColumn.HeaderText = "first_name"
        Me.FirstnameDataGridViewTextBoxColumn.Name = "FirstnameDataGridViewTextBoxColumn"
        Me.FirstnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'LastnameDataGridViewTextBoxColumn
        '
        Me.LastnameDataGridViewTextBoxColumn.DataPropertyName = "last_name"
        Me.LastnameDataGridViewTextBoxColumn.HeaderText = "last_name"
        Me.LastnameDataGridViewTextBoxColumn.Name = "LastnameDataGridViewTextBoxColumn"
        Me.LastnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PhonenumberDataGridViewTextBoxColumn
        '
        Me.PhonenumberDataGridViewTextBoxColumn.DataPropertyName = "phone_number"
        Me.PhonenumberDataGridViewTextBoxColumn.HeaderText = "phone_number"
        Me.PhonenumberDataGridViewTextBoxColumn.Name = "PhonenumberDataGridViewTextBoxColumn"
        Me.PhonenumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'EmailaddressDataGridViewTextBoxColumn
        '
        Me.EmailaddressDataGridViewTextBoxColumn.DataPropertyName = "email_address"
        Me.EmailaddressDataGridViewTextBoxColumn.HeaderText = "email_address"
        Me.EmailaddressDataGridViewTextBoxColumn.Name = "EmailaddressDataGridViewTextBoxColumn"
        Me.EmailaddressDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StreetnumberandnameDataGridViewTextBoxColumn
        '
        Me.StreetnumberandnameDataGridViewTextBoxColumn.DataPropertyName = "street_number_and_name"
        Me.StreetnumberandnameDataGridViewTextBoxColumn.HeaderText = "street_number_and_name"
        Me.StreetnumberandnameDataGridViewTextBoxColumn.Name = "StreetnumberandnameDataGridViewTextBoxColumn"
        Me.StreetnumberandnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'CityDataGridViewTextBoxColumn
        '
        Me.CityDataGridViewTextBoxColumn.DataPropertyName = "city"
        Me.CityDataGridViewTextBoxColumn.HeaderText = "city"
        Me.CityDataGridViewTextBoxColumn.Name = "CityDataGridViewTextBoxColumn"
        Me.CityDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PostalcodeDataGridViewTextBoxColumn
        '
        Me.PostalcodeDataGridViewTextBoxColumn.DataPropertyName = "postal_code"
        Me.PostalcodeDataGridViewTextBoxColumn.HeaderText = "postal_code"
        Me.PostalcodeDataGridViewTextBoxColumn.Name = "PostalcodeDataGridViewTextBoxColumn"
        Me.PostalcodeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DateofhireDataGridViewTextBoxColumn
        '
        Me.DateofhireDataGridViewTextBoxColumn.DataPropertyName = "date_of_hire"
        Me.DateofhireDataGridViewTextBoxColumn.HeaderText = "date_of_hire"
        Me.DateofhireDataGridViewTextBoxColumn.Name = "DateofhireDataGridViewTextBoxColumn"
        Me.DateofhireDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DateofterminationDataGridViewTextBoxColumn
        '
        Me.DateofterminationDataGridViewTextBoxColumn.DataPropertyName = "date_of_termination"
        Me.DateofterminationDataGridViewTextBoxColumn.HeaderText = "date_of_termination"
        Me.DateofterminationDataGridViewTextBoxColumn.Name = "DateofterminationDataGridViewTextBoxColumn"
        Me.DateofterminationDataGridViewTextBoxColumn.ReadOnly = True
        '
        'RaceDataGridViewTextBoxColumn
        '
        Me.RaceDataGridViewTextBoxColumn.DataPropertyName = "race"
        Me.RaceDataGridViewTextBoxColumn.HeaderText = "race"
        Me.RaceDataGridViewTextBoxColumn.Name = "RaceDataGridViewTextBoxColumn"
        Me.RaceDataGridViewTextBoxColumn.ReadOnly = True
        '
        'GenderDataGridViewTextBoxColumn
        '
        Me.GenderDataGridViewTextBoxColumn.DataPropertyName = "gender"
        Me.GenderDataGridViewTextBoxColumn.HeaderText = "gender"
        Me.GenderDataGridViewTextBoxColumn.Name = "GenderDataGridViewTextBoxColumn"
        Me.GenderDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DisabilitystatusDataGridViewCheckBoxColumn
        '
        Me.DisabilitystatusDataGridViewCheckBoxColumn.DataPropertyName = "disability_status"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.HeaderText = "disability_status"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.Name = "DisabilitystatusDataGridViewCheckBoxColumn"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.ReadOnly = True
        '
        'MonthlybasesalaryDataGridViewTextBoxColumn
        '
        Me.MonthlybasesalaryDataGridViewTextBoxColumn.DataPropertyName = "monthly_base_salary"
        Me.MonthlybasesalaryDataGridViewTextBoxColumn.HeaderText = "monthly_base_salary"
        Me.MonthlybasesalaryDataGridViewTextBoxColumn.Name = "MonthlybasesalaryDataGridViewTextBoxColumn"
        Me.MonthlybasesalaryDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BanknameDataGridViewTextBoxColumn
        '
        Me.BanknameDataGridViewTextBoxColumn.DataPropertyName = "bank_name"
        Me.BanknameDataGridViewTextBoxColumn.HeaderText = "bank_name"
        Me.BanknameDataGridViewTextBoxColumn.Name = "BanknameDataGridViewTextBoxColumn"
        Me.BanknameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BankaccountnumberDataGridViewTextBoxColumn
        '
        Me.BankaccountnumberDataGridViewTextBoxColumn.DataPropertyName = "bank_account_number"
        Me.BankaccountnumberDataGridViewTextBoxColumn.HeaderText = "bank_account_number"
        Me.BankaccountnumberDataGridViewTextBoxColumn.Name = "BankaccountnumberDataGridViewTextBoxColumn"
        Me.BankaccountnumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BankbranchnameDataGridViewTextBoxColumn
        '
        Me.BankbranchnameDataGridViewTextBoxColumn.DataPropertyName = "bank_branch_name"
        Me.BankbranchnameDataGridViewTextBoxColumn.HeaderText = "bank_branch_name"
        Me.BankbranchnameDataGridViewTextBoxColumn.Name = "BankbranchnameDataGridViewTextBoxColumn"
        Me.BankbranchnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BankbranchcodeDataGridViewTextBoxColumn
        '
        Me.BankbranchcodeDataGridViewTextBoxColumn.DataPropertyName = "bank_branch_code"
        Me.BankbranchcodeDataGridViewTextBoxColumn.HeaderText = "bank_branch_code"
        Me.BankbranchcodeDataGridViewTextBoxColumn.Name = "BankbranchcodeDataGridViewTextBoxColumn"
        Me.BankbranchcodeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TaxnumberDataGridViewTextBoxColumn
        '
        Me.TaxnumberDataGridViewTextBoxColumn.DataPropertyName = "tax_number"
        Me.TaxnumberDataGridViewTextBoxColumn.HeaderText = "tax_number"
        Me.TaxnumberDataGridViewTextBoxColumn.Name = "TaxnumberDataGridViewTextBoxColumn"
        Me.TaxnumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PositionnameDataGridViewTextBoxColumn
        '
        Me.PositionnameDataGridViewTextBoxColumn.DataPropertyName = "position_name"
        Me.PositionnameDataGridViewTextBoxColumn.HeaderText = "position_name"
        Me.PositionnameDataGridViewTextBoxColumn.Name = "PositionnameDataGridViewTextBoxColumn"
        Me.PositionnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'EmployeeBindingSource
        '
        Me.EmployeeBindingSource.DataMember = "Employee"
        Me.EmployeeBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'Ist2dsDataSet
        '
        Me.Ist2dsDataSet.DataSetName = "ist2dsDataSet"
        Me.Ist2dsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EmployeeTableAdapter
        '
        Me.EmployeeTableAdapter.ClearBeforeFill = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtEmployeeID)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtEmployeeLastName)
        Me.GroupBox1.Controls.Add(Me.txtEmployeeFirstName)
        Me.GroupBox1.Controls.Add(Me.btnSelect)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(354, 188)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 196)
        Me.GroupBox1.TabIndex = 12
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Currently Highligted"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 28)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 16)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Employee ID:"
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.Location = New System.Drawing.Point(101, 25)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.Size = New System.Drawing.Size(212, 22)
        Me.txtEmployeeID.TabIndex = 41
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 56)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 16)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "First name:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 85)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 16)
        Me.Label5.TabIndex = 44
        Me.Label5.Text = "Last name:"
        '
        'txtEmployeeLastName
        '
        Me.txtEmployeeLastName.Location = New System.Drawing.Point(101, 85)
        Me.txtEmployeeLastName.Name = "txtEmployeeLastName"
        Me.txtEmployeeLastName.Size = New System.Drawing.Size(212, 22)
        Me.txtEmployeeLastName.TabIndex = 46
        '
        'txtEmployeeFirstName
        '
        Me.txtEmployeeFirstName.Location = New System.Drawing.Point(101, 56)
        Me.txtEmployeeFirstName.Name = "txtEmployeeFirstName"
        Me.txtEmployeeFirstName.Size = New System.Drawing.Size(212, 22)
        Me.txtEmployeeFirstName.TabIndex = 45
        '
        'btnSelect
        '
        Me.btnSelect.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSelect.Location = New System.Drawing.Point(101, 143)
        Me.btnSelect.Name = "btnSelect"
        Me.btnSelect.Size = New System.Drawing.Size(212, 32)
        Me.btnSelect.TabIndex = 4
        Me.btnSelect.Text = "Select this Employee"
        Me.btnSelect.UseVisualStyleBackColor = True
        '
        'cmbDepartment
        '
        Me.cmbDepartment.FormattingEnabled = True
        Me.cmbDepartment.Items.AddRange(New Object() {"Accounting", "Administration", "Engineering", "Finance", "Human Resources", "IT", "Marketing", "Sales", "All"})
        Me.cmbDepartment.Location = New System.Drawing.Point(106, 113)
        Me.cmbDepartment.Name = "cmbDepartment"
        Me.cmbDepartment.Size = New System.Drawing.Size(212, 24)
        Me.cmbDepartment.TabIndex = 49
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(11, 116)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 16)
        Me.Label6.TabIndex = 48
        Me.Label6.Text = "Department:"
        '
        'EmployeeSelectionForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(701, 433)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.GroupBox3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "EmployeeSelectionForm"
        Me.Text = "Select Employee For"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents txtSearchEmployeeID As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtSearchEmployeeLastName As TextBox
    Friend WithEvents txtSearchEmployeeFirstName As TextBox
    Friend WithEvents btnBack As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Ist2dsDataSet As ist2dsDataSet
    Friend WithEvents EmployeeBindingSource As BindingSource
    Friend WithEvents EmployeeTableAdapter As ist2dsDataSetTableAdapters.EmployeeTableAdapter
    Friend WithEvents EmployeeIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FirstnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LastnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PhonenumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmailaddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StreetnumberandnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PostalcodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateofhireDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateofterminationDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RaceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GenderDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DisabilitystatusDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents MonthlybasesalaryDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BanknameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BankaccountnumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BankbranchnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BankbranchcodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TaxnumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PositionnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtEmployeeLastName As TextBox
    Friend WithEvents txtEmployeeFirstName As TextBox
    Friend WithEvents btnSelect As Button
    Friend WithEvents cmbDepartment As ComboBox
    Friend WithEvents Label6 As Label
End Class
