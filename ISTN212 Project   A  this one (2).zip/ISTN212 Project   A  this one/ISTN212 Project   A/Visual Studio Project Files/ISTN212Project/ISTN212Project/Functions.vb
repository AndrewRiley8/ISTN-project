﻿Public Class Functions



    '_________________________________________________________________________________________________________________
    'ADDING



    Public Shared Sub addApplicant(id As String, fnam As String, lnam As String, gender As String, race As String, disability As Boolean, position As String, phoneNum As String, email As String, street As String, city As String, postcode As String)


    End Sub

    Public Shared Sub addAppointment(aptDate As String, startHr As Integer, startMin As Integer, endHr As Integer, endMin As Integer, desc As String)
    End Sub

    Public Shared Sub addAppt_Guest(aptNum As Integer, empID As String)
        'do sql adding: it is already ensured that the employee has no other appointment during this time
    End Sub

    Public Shared Sub addComplaint(compdate As Date, target As String, untargetted As Boolean, desc As String)
        'validate
        'do sql adding
    End Sub

    Public Shared Sub addEmployee(id As String, fnam As String, lnam As String, gender As String, race As String, disability As Boolean, dateHired As String, monthlySal As Integer, bankNam As String, bankBranchCode As String, bankacctnum As String, bankBranchNam As String, taxNo As String, position As String, phoneNum As String, email As String, street As String, city As String, postcode As String)

    End Sub

    Public Shared Sub addPosition(positionName As String, dept As String, availablePosts As Integer)

    End Sub


    '_________________________________________________________________________________________________________________
    'UPDATING
    Public Shared Sub addressComplaint(dateIssued As Date, isUntargetted As Boolean, target As String, desc As String)

    End Sub

    Public Shared Sub rescheduleAppointment(aptDate As Date, startHr As Integer, startMin As Integer, endHr As Integer, endMin As Integer, desc As String)

    End Sub

    Public Shared Sub setApplicantInterview(appID As String, apptNum As Integer)
        'open the appointments form in add mode. 
        'after calling addAppointment(), set appointment in Applicant to the newly made appointment 
    End Sub





    Public Shared Sub terminateEmployee(id As String, type As String, termDate As Date)

    End Sub

    Public Shared Sub updateAvailablePosts(positionName As String, newNum As Integer)

    End Sub

    '_________________________________________________________________________________________________________________
    'DELETING

    Public Shared Sub clearTerminationHistory()
        'do sql delete
    End Sub

    Public Shared Sub deleteAppointment(apptNum As Integer)
    End Sub

    Public Shared Sub removeApptGuest(aptNum As Integer, empID As String)

    End Sub

    Public Shared Sub cancelLeave(EmpID As String, StartDate As Date)

    End Sub

    Public Shared Sub deleteApplicant(appID As String)

    End Sub
    'no function needed directly to delete complaint
    'no function needed to delete position

    '__________________________________________________________________________________________________________________
    'SEARCH AND FILTER
    Public Shared Sub searchComplaints(callerTable As ist2dsDataSet.ComplaintDataTable, callerAdapter As ist2dsDataSetTableAdapters.ComplaintTableAdapter, allDays As Boolean, complaintDate As Date, untargetted As Boolean, target As String)
        If untargetted Then
            target = "NULL"
        End If
        If Not (IDValid(target) And complaintDate < Today) Then
            'flag
            'message
        Else

        End If

        If allDays And untargetted Then
            callerAdapter.SelectAllComplaints(callerTable)
        ElseIf allDays Then
            callerAdapter.SearchEmployeeAllDays(callerTable, target)
        ElseIf untargetted Then
            callerAdapter.SearchDateAllEmployees(callerTable, complaintDate)
        Else
            callerAdapter.SearchDateAndEmployee(callerTable, complaintDate, target)
        End If
    End Sub




    Public Shared Sub filterPosition(dept As String)


    End Sub

    Public Shared Sub filterAbsences(allDays As Boolean, absDate As Date, allEmp As Boolean, empID As String)

    End Sub

    Public Shared Sub filterAppointments(aptDate As Date)

    End Sub


    '__________________________________________________________________________________________________________________
    'OTHER FUNCTIONS AND SUBS





End Class
