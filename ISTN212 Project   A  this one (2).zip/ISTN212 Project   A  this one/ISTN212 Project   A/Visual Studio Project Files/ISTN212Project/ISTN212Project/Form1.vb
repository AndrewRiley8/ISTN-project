﻿Public Class LoginForm
    Public showText As Boolean = True
    Public userName As String = ""
    Public Proceed As Boolean


    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        End
    End Sub

    Public Sub CheckEmpty()

        Proceed = True
        Dim pw As Boolean = True
        Dim un As Boolean = True

        If tbPassword.Text = String.Empty Then
            Proceed = False
            pw = False
        ElseIf tbUserName.Text = String.Empty Then
            Proceed = False
            un = False
        End If




    End Sub

    Private Sub btnProceed_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        Call CheckEmpty()
        If Proceed Then
            userName = tbUserName.Text
            MenuForm.lblWelcome.Text = "Welcome " & userName
            Me.Hide()
            MenuForm.Show()
        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnView.Click
        If showText Then
            tbPassword.PasswordChar = ""
            showText = False

        Else
            tbPassword.PasswordChar = "*"
            showText = True

        End If


    End Sub
End Class
