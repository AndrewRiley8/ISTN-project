﻿Public Class EmployeeTerminateForm
    Private Sub MiniEmployeeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Employee' table. You can move, or remove it, as needed.
        'Me.EmployeeTableAdapter.Fill(Me.Ist2dsDataSet.Employee)

    End Sub
    '___________________________________________________________________________________________________________________________________________________
    'BUTTON EVENT HANDLERS
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()
    End Sub

    Private Sub btnChoose_Click(sender As Object, e As EventArgs) Handles btnChoose.Click
        MenuForm.openEmployeeSelectorFrom(EmployeeSelectionForm.Terminations)
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Functions.searchEmployee(Me.Ist2dsDataSet.Employee, Me.EmployeeTableAdapter, txtSearchEmployeeID.Text, txtSearchEmployeeFirstName.Text, txtSearchEmployeeLastName.Text, cmbDepartment.Text)
    End Sub

    Private Sub btnTerminate_Click(sender As Object, e As EventArgs) Handles btnTerminate.Click
        Functions.terminateEmployee(txtEmployeeID.Text, cmbType.Text, DateTimePicker1.Value)
    End Sub

    Private Sub btnClearHistory_Click(sender As Object, e As EventArgs) Handles btnClearHistory.Click
        Functions.clearTerminationHistory()
    End Sub
End Class