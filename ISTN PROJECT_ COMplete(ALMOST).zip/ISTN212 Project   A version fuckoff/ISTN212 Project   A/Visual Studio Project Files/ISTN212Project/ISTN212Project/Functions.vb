﻿Public Class Functions



    '_________________________________________________________________________________________________________________
    'UPDATING
    Public Shared Sub rescheduleAppointment(aptDate As Date, startHr As Integer, startMin As Integer, endHr As Integer, endMin As Integer, desc As String)

    End Sub

    Public Shared Sub setApplicantInterview(appID As String, apptNum As Integer)
        'open the appointments form in add mode. 
        'after calling addAppointment(), set appointment in Applicant to the newly made appointment 
    End Sub
    '_________________________________________________________________________________________________________________
    'DELETING
    Public Shared Sub deleteAppointment(apptNum As Integer)
    End Sub

    Public Shared Sub removeApptGuest(aptNum As Integer, empID As String)

    End Sub

End Class
