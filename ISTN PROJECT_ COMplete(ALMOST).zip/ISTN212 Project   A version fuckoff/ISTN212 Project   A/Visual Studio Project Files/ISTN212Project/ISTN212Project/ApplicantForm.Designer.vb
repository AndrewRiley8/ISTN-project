﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ApplicantForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.IDnumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhonenumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailaddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StreetnameandnumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PostalcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AppointmentIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RaceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GenderDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DisabilitystatusDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.position_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApplicantBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ist2dsDataSet = New ISTN212Project.ist2dsDataSet()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.btnHireApplicant = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnRejectApplicant = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cmbGender = New System.Windows.Forms.ComboBox()
        Me.cmbRace = New System.Windows.Forms.ComboBox()
        Me.txtApplicantID = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.cboxDisability = New System.Windows.Forms.CheckBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPostCode = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtPhoneNum = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnUpdateAppointment = New System.Windows.Forms.Button()
        Me.numUDEndMin = New System.Windows.Forms.NumericUpDown()
        Me.AppointmentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.numUDEndHr = New System.Windows.Forms.NumericUpDown()
        Me.numUDStartMin = New System.Windows.Forms.NumericUpDown()
        Me.numUDStartHr = New System.Windows.Forms.NumericUpDown()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnFilterByDeptProtected = New System.Windows.Forms.Button()
        Me.btnFilterByDept = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtSearchApplicantID = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtSearchApplicantLastName = New System.Windows.Forms.TextBox()
        Me.txtSearchApplicantFirstName = New System.Windows.Forms.TextBox()
        Me.ApplicantTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.ApplicantTableAdapter()
        Me.TableAdapterManager = New ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager()
        Me.AppointmentTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.AppointmentTableAdapter()
        Me.btnEditPositions = New System.Windows.Forms.Button()
        Me.btnNewApplicant = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ApplicantBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.numUDEndMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AppointmentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numUDEndHr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numUDStartMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numUDStartHr, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.GrayText
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDnumberDataGridViewTextBoxColumn, Me.FirstnameDataGridViewTextBoxColumn, Me.LastnameDataGridViewTextBoxColumn, Me.PhonenumberDataGridViewTextBoxColumn, Me.EmailaddressDataGridViewTextBoxColumn, Me.StreetnameandnumberDataGridViewTextBoxColumn, Me.CityDataGridViewTextBoxColumn, Me.PostalcodeDataGridViewTextBoxColumn, Me.AppointmentIDDataGridViewTextBoxColumn, Me.RaceDataGridViewTextBoxColumn, Me.GenderDataGridViewTextBoxColumn, Me.DisabilitystatusDataGridViewCheckBoxColumn, Me.position_name})
        Me.DataGridView1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.DataGridView1.DataSource = Me.ApplicantBindingSource
        Me.DataGridView1.GridColor = System.Drawing.Color.Black
        Me.DataGridView1.Location = New System.Drawing.Point(13, 33)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(1341, 273)
        Me.DataGridView1.TabIndex = 1
        '
        'IDnumberDataGridViewTextBoxColumn
        '
        Me.IDnumberDataGridViewTextBoxColumn.DataPropertyName = "ID_number"
        Me.IDnumberDataGridViewTextBoxColumn.HeaderText = "ID_number"
        Me.IDnumberDataGridViewTextBoxColumn.Name = "IDnumberDataGridViewTextBoxColumn"
        Me.IDnumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'FirstnameDataGridViewTextBoxColumn
        '
        Me.FirstnameDataGridViewTextBoxColumn.DataPropertyName = "first_name"
        Me.FirstnameDataGridViewTextBoxColumn.HeaderText = "first_name"
        Me.FirstnameDataGridViewTextBoxColumn.Name = "FirstnameDataGridViewTextBoxColumn"
        Me.FirstnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'LastnameDataGridViewTextBoxColumn
        '
        Me.LastnameDataGridViewTextBoxColumn.DataPropertyName = "last_name"
        Me.LastnameDataGridViewTextBoxColumn.HeaderText = "last_name"
        Me.LastnameDataGridViewTextBoxColumn.Name = "LastnameDataGridViewTextBoxColumn"
        Me.LastnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PhonenumberDataGridViewTextBoxColumn
        '
        Me.PhonenumberDataGridViewTextBoxColumn.DataPropertyName = "phone_number"
        Me.PhonenumberDataGridViewTextBoxColumn.HeaderText = "phone_number"
        Me.PhonenumberDataGridViewTextBoxColumn.Name = "PhonenumberDataGridViewTextBoxColumn"
        Me.PhonenumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'EmailaddressDataGridViewTextBoxColumn
        '
        Me.EmailaddressDataGridViewTextBoxColumn.DataPropertyName = "email_address"
        Me.EmailaddressDataGridViewTextBoxColumn.HeaderText = "email_address"
        Me.EmailaddressDataGridViewTextBoxColumn.Name = "EmailaddressDataGridViewTextBoxColumn"
        Me.EmailaddressDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StreetnameandnumberDataGridViewTextBoxColumn
        '
        Me.StreetnameandnumberDataGridViewTextBoxColumn.DataPropertyName = "street_name_and_number"
        Me.StreetnameandnumberDataGridViewTextBoxColumn.HeaderText = "street_name_and_number"
        Me.StreetnameandnumberDataGridViewTextBoxColumn.Name = "StreetnameandnumberDataGridViewTextBoxColumn"
        Me.StreetnameandnumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'CityDataGridViewTextBoxColumn
        '
        Me.CityDataGridViewTextBoxColumn.DataPropertyName = "city"
        Me.CityDataGridViewTextBoxColumn.HeaderText = "city"
        Me.CityDataGridViewTextBoxColumn.Name = "CityDataGridViewTextBoxColumn"
        Me.CityDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PostalcodeDataGridViewTextBoxColumn
        '
        Me.PostalcodeDataGridViewTextBoxColumn.DataPropertyName = "postal_code"
        Me.PostalcodeDataGridViewTextBoxColumn.HeaderText = "postal_code"
        Me.PostalcodeDataGridViewTextBoxColumn.Name = "PostalcodeDataGridViewTextBoxColumn"
        Me.PostalcodeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AppointmentIDDataGridViewTextBoxColumn
        '
        Me.AppointmentIDDataGridViewTextBoxColumn.DataPropertyName = "appointment_ID"
        Me.AppointmentIDDataGridViewTextBoxColumn.HeaderText = "appointment_ID"
        Me.AppointmentIDDataGridViewTextBoxColumn.Name = "AppointmentIDDataGridViewTextBoxColumn"
        Me.AppointmentIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'RaceDataGridViewTextBoxColumn
        '
        Me.RaceDataGridViewTextBoxColumn.DataPropertyName = "race"
        Me.RaceDataGridViewTextBoxColumn.HeaderText = "race"
        Me.RaceDataGridViewTextBoxColumn.Name = "RaceDataGridViewTextBoxColumn"
        Me.RaceDataGridViewTextBoxColumn.ReadOnly = True
        '
        'GenderDataGridViewTextBoxColumn
        '
        Me.GenderDataGridViewTextBoxColumn.DataPropertyName = "gender"
        Me.GenderDataGridViewTextBoxColumn.HeaderText = "gender"
        Me.GenderDataGridViewTextBoxColumn.Name = "GenderDataGridViewTextBoxColumn"
        Me.GenderDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DisabilitystatusDataGridViewCheckBoxColumn
        '
        Me.DisabilitystatusDataGridViewCheckBoxColumn.DataPropertyName = "disability_status"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.HeaderText = "disability_status"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.Name = "DisabilitystatusDataGridViewCheckBoxColumn"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.ReadOnly = True
        '
        'position_name
        '
        Me.position_name.DataPropertyName = "position_name"
        Me.position_name.HeaderText = "position_name"
        Me.position_name.Name = "position_name"
        Me.position_name.ReadOnly = True
        '
        'ApplicantBindingSource
        '
        Me.ApplicantBindingSource.DataMember = "Applicant"
        Me.ApplicantBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'Ist2dsDataSet
        '
        Me.Ist2dsDataSet.DataSetName = "ist2dsDataSet"
        Me.Ist2dsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDate.Location = New System.Drawing.Point(641, 9)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(37, 16)
        Me.lblDate.TabIndex = 2
        Me.lblDate.Text = "Date"
        '
        'btnHireApplicant
        '
        Me.btnHireApplicant.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnHireApplicant.Location = New System.Drawing.Point(12, 23)
        Me.btnHireApplicant.Name = "btnHireApplicant"
        Me.btnHireApplicant.Size = New System.Drawing.Size(211, 32)
        Me.btnHireApplicant.TabIndex = 0
        Me.btnHireApplicant.Text = "Hire This Applicant"
        Me.btnHireApplicant.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.btnRejectApplicant)
        Me.GroupBox2.Controls.Add(Me.btnHireApplicant)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Location = New System.Drawing.Point(905, 619)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(449, 68)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Acceptance"
        '
        'btnRejectApplicant
        '
        Me.btnRejectApplicant.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnRejectApplicant.Location = New System.Drawing.Point(229, 23)
        Me.btnRejectApplicant.Name = "btnRejectApplicant"
        Me.btnRejectApplicant.Size = New System.Drawing.Size(203, 32)
        Me.btnRejectApplicant.TabIndex = 2
        Me.btnRejectApplicant.Text = "Reject this Applicant"
        Me.btnRejectApplicant.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.cmbGender)
        Me.GroupBox3.Controls.Add(Me.cmbRace)
        Me.GroupBox3.Controls.Add(Me.txtApplicantID)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.cboxDisability)
        Me.GroupBox3.Controls.Add(Me.txtFirstName)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.txtPosition)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.txtPostCode)
        Me.GroupBox3.Controls.Add(Me.txtCity)
        Me.GroupBox3.Controls.Add(Me.txtStreet)
        Me.GroupBox3.Controls.Add(Me.txtEmail)
        Me.GroupBox3.Controls.Add(Me.txtPhoneNum)
        Me.GroupBox3.Controls.Add(Me.txtLastName)
        Me.GroupBox3.Enabled = False
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Location = New System.Drawing.Point(366, 312)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(524, 375)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Applicant Details"
        '
        'cmbGender
        '
        Me.cmbGender.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "gender", True))
        Me.cmbGender.FormattingEnabled = True
        Me.cmbGender.Items.AddRange(New Object() {"Female", "Male", "Other", "Unspecified"})
        Me.cmbGender.Location = New System.Drawing.Point(260, 225)
        Me.cmbGender.Name = "cmbGender"
        Me.cmbGender.Size = New System.Drawing.Size(258, 24)
        Me.cmbGender.TabIndex = 56
        '
        'cmbRace
        '
        Me.cmbRace.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "race", True))
        Me.cmbRace.FormattingEnabled = True
        Me.cmbRace.Items.AddRange(New Object() {"European", "Indian", "African", "Asian", "Other"})
        Me.cmbRace.Location = New System.Drawing.Point(260, 258)
        Me.cmbRace.Name = "cmbRace"
        Me.cmbRace.Size = New System.Drawing.Size(258, 24)
        Me.cmbRace.TabIndex = 55
        '
        'txtApplicantID
        '
        Me.txtApplicantID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "ID_number", True))
        Me.txtApplicantID.Location = New System.Drawing.Point(260, 342)
        Me.txtApplicantID.Name = "txtApplicantID"
        Me.txtApplicantID.Size = New System.Drawing.Size(258, 22)
        Me.txtApplicantID.TabIndex = 40
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(25, 345)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(72, 16)
        Me.Label15.TabIndex = 39
        Me.Label15.Text = "ID number:"
        '
        'cboxDisability
        '
        Me.cboxDisability.AutoSize = True
        Me.cboxDisability.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cboxDisability.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.ApplicantBindingSource, "disability_status", True))
        Me.cboxDisability.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.ApplicantBindingSource, "disability_status", True))
        Me.cboxDisability.Location = New System.Drawing.Point(28, 288)
        Me.cboxDisability.Name = "cboxDisability"
        Me.cboxDisability.Size = New System.Drawing.Size(248, 20)
        Me.cboxDisability.TabIndex = 38
        Me.cboxDisability.TabStop = False
        Me.cboxDisability.Text = "This applicant has a disability:              "
        Me.cboxDisability.UseVisualStyleBackColor = True
        '
        'txtFirstName
        '
        Me.txtFirstName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "first_name", True))
        Me.txtFirstName.Location = New System.Drawing.Point(260, 23)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(258, 22)
        Me.txtFirstName.TabIndex = 37
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(25, 256)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 16)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "Race:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(25, 228)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 16)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Gender:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(25, 200)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 16)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Postal code:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(25, 171)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 16)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "City"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(25, 314)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(126, 16)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "Position applied for:"
        '
        'txtPosition
        '
        Me.txtPosition.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "position_name", True))
        Me.txtPosition.Location = New System.Drawing.Point(260, 311)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.Size = New System.Drawing.Size(258, 22)
        Me.txtPosition.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 141)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(157, 16)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Street name and number:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 113)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 16)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Email address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(25, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 16)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Phone number:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 16)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Last name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(25, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 16)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "First name:"
        '
        'txtPostCode
        '
        Me.txtPostCode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "postal_code", True))
        Me.txtPostCode.Location = New System.Drawing.Point(260, 197)
        Me.txtPostCode.Name = "txtPostCode"
        Me.txtPostCode.Size = New System.Drawing.Size(258, 22)
        Me.txtPostCode.TabIndex = 6
        '
        'txtCity
        '
        Me.txtCity.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "city", True))
        Me.txtCity.Location = New System.Drawing.Point(260, 168)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(258, 22)
        Me.txtCity.TabIndex = 5
        '
        'txtStreet
        '
        Me.txtStreet.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "street_name_and_number", True))
        Me.txtStreet.Location = New System.Drawing.Point(260, 138)
        Me.txtStreet.Name = "txtStreet"
        Me.txtStreet.Size = New System.Drawing.Size(258, 22)
        Me.txtStreet.TabIndex = 4
        '
        'txtEmail
        '
        Me.txtEmail.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "email_address", True))
        Me.txtEmail.Location = New System.Drawing.Point(260, 110)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(258, 22)
        Me.txtEmail.TabIndex = 3
        '
        'txtPhoneNum
        '
        Me.txtPhoneNum.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "phone_number", True))
        Me.txtPhoneNum.Location = New System.Drawing.Point(260, 81)
        Me.txtPhoneNum.Name = "txtPhoneNum"
        Me.txtPhoneNum.Size = New System.Drawing.Size(258, 22)
        Me.txtPhoneNum.TabIndex = 2
        '
        'txtLastName
        '
        Me.txtLastName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ApplicantBindingSource, "last_name", True))
        Me.txtLastName.Location = New System.Drawing.Point(260, 52)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(258, 22)
        Me.txtLastName.TabIndex = 1
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(13, 706)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(98, 31)
        Me.btnBack.TabIndex = 7
        Me.btnBack.Text = "Back to menu"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.btnUpdateAppointment)
        Me.GroupBox4.Controls.Add(Me.numUDEndMin)
        Me.GroupBox4.Controls.Add(Me.numUDEndHr)
        Me.GroupBox4.Controls.Add(Me.numUDStartMin)
        Me.GroupBox4.Controls.Add(Me.numUDStartHr)
        Me.GroupBox4.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox4.Location = New System.Drawing.Point(905, 312)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(449, 187)
        Me.GroupBox4.TabIndex = 8
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Interview Appointment"
        '
        'btnUpdateAppointment
        '
        Me.btnUpdateAppointment.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnUpdateAppointment.Location = New System.Drawing.Point(159, 125)
        Me.btnUpdateAppointment.Name = "btnUpdateAppointment"
        Me.btnUpdateAppointment.Size = New System.Drawing.Size(242, 32)
        Me.btnUpdateAppointment.TabIndex = 25
        Me.btnUpdateAppointment.Text = "Set Appointment"
        Me.btnUpdateAppointment.UseVisualStyleBackColor = True
        '
        'numUDEndMin
        '
        Me.numUDEndMin.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "end_min", True))
        Me.numUDEndMin.Enabled = False
        Me.numUDEndMin.Location = New System.Drawing.Point(285, 81)
        Me.numUDEndMin.Maximum = New Decimal(New Integer() {59, 0, 0, 0})
        Me.numUDEndMin.Name = "numUDEndMin"
        Me.numUDEndMin.Size = New System.Drawing.Size(120, 22)
        Me.numUDEndMin.TabIndex = 24
        '
        'AppointmentBindingSource
        '
        Me.AppointmentBindingSource.DataMember = "Appointment"
        Me.AppointmentBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'numUDEndHr
        '
        Me.numUDEndHr.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "end_hour", True))
        Me.numUDEndHr.Enabled = False
        Me.numUDEndHr.Location = New System.Drawing.Point(159, 81)
        Me.numUDEndHr.Maximum = New Decimal(New Integer() {17, 0, 0, 0})
        Me.numUDEndHr.Minimum = New Decimal(New Integer() {11, 0, 0, 0})
        Me.numUDEndHr.Name = "numUDEndHr"
        Me.numUDEndHr.Size = New System.Drawing.Size(120, 22)
        Me.numUDEndHr.TabIndex = 23
        Me.numUDEndHr.Value = New Decimal(New Integer() {11, 0, 0, 0})
        '
        'numUDStartMin
        '
        Me.numUDStartMin.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "start_min", True))
        Me.numUDStartMin.Enabled = False
        Me.numUDStartMin.Location = New System.Drawing.Point(285, 52)
        Me.numUDStartMin.Maximum = New Decimal(New Integer() {59, 0, 0, 0})
        Me.numUDStartMin.Name = "numUDStartMin"
        Me.numUDStartMin.Size = New System.Drawing.Size(120, 22)
        Me.numUDStartMin.TabIndex = 22
        '
        'numUDStartHr
        '
        Me.numUDStartHr.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "start_hour", True))
        Me.numUDStartHr.Enabled = False
        Me.numUDStartHr.Location = New System.Drawing.Point(159, 52)
        Me.numUDStartHr.Maximum = New Decimal(New Integer() {15, 0, 0, 0})
        Me.numUDStartHr.Minimum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.numUDStartHr.Name = "numUDStartHr"
        Me.numUDStartHr.Size = New System.Drawing.Size(120, 22)
        Me.numUDStartHr.TabIndex = 21
        Me.numUDStartHr.Value = New Decimal(New Integer() {9, 0, 0, 0})
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "date", True))
        Me.DateTimePicker1.Enabled = False
        Me.DateTimePicker1.Location = New System.Drawing.Point(159, 20)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(246, 22)
        Me.DateTimePicker1.TabIndex = 20
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(9, 83)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 16)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "End Time:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(9, 54)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 16)
        Me.Label11.TabIndex = 18
        Me.Label11.Text = "Start Time:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(9, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(40, 16)
        Me.Label18.TabIndex = 17
        Me.Label18.Text = "Date:"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.btnFilterByDeptProtected)
        Me.GroupBox1.Controls.Add(Me.btnFilterByDept)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(13, 501)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 121)
        Me.GroupBox1.TabIndex = 29
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filter"
        '
        'btnFilterByDeptProtected
        '
        Me.btnFilterByDeptProtected.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnFilterByDeptProtected.Location = New System.Drawing.Point(14, 67)
        Me.btnFilterByDeptProtected.Name = "btnFilterByDeptProtected"
        Me.btnFilterByDeptProtected.Size = New System.Drawing.Size(304, 31)
        Me.btnFilterByDeptProtected.TabIndex = 1
        Me.btnFilterByDeptProtected.Text = "Show Only Protected Class Applicants"
        Me.btnFilterByDeptProtected.UseVisualStyleBackColor = True
        '
        'btnFilterByDept
        '
        Me.btnFilterByDept.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnFilterByDept.Location = New System.Drawing.Point(14, 21)
        Me.btnFilterByDept.Name = "btnFilterByDept"
        Me.btnFilterByDept.Size = New System.Drawing.Size(304, 32)
        Me.btnFilterByDept.TabIndex = 0
        Me.btnFilterByDept.Text = "Show All Applicants"
        Me.btnFilterByDept.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox5.Controls.Add(Me.btnSearch)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.txtSearchApplicantID)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.Label17)
        Me.GroupBox5.Controls.Add(Me.txtSearchApplicantLastName)
        Me.GroupBox5.Controls.Add(Me.txtSearchApplicantFirstName)
        Me.GroupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox5.Location = New System.Drawing.Point(13, 312)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(336, 183)
        Me.GroupBox5.TabIndex = 28
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Navigation"
        '
        'btnSearch
        '
        Me.btnSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSearch.Location = New System.Drawing.Point(9, 143)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 32)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(11, 28)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(83, 16)
        Me.Label13.TabIndex = 29
        Me.Label13.Text = "Applicant ID:"
        '
        'txtSearchApplicantID
        '
        Me.txtSearchApplicantID.Location = New System.Drawing.Point(106, 25)
        Me.txtSearchApplicantID.Name = "txtSearchApplicantID"
        Me.txtSearchApplicantID.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchApplicantID.TabIndex = 28
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(11, 56)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(73, 16)
        Me.Label14.TabIndex = 37
        Me.Label14.Text = "First name:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(11, 85)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(73, 16)
        Me.Label17.TabIndex = 38
        Me.Label17.Text = "Last name:"
        '
        'txtSearchApplicantLastName
        '
        Me.txtSearchApplicantLastName.Location = New System.Drawing.Point(106, 85)
        Me.txtSearchApplicantLastName.Name = "txtSearchApplicantLastName"
        Me.txtSearchApplicantLastName.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchApplicantLastName.TabIndex = 40
        '
        'txtSearchApplicantFirstName
        '
        Me.txtSearchApplicantFirstName.Location = New System.Drawing.Point(106, 56)
        Me.txtSearchApplicantFirstName.Name = "txtSearchApplicantFirstName"
        Me.txtSearchApplicantFirstName.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchApplicantFirstName.TabIndex = 39
        '
        'ApplicantTableAdapter
        '
        Me.ApplicantTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AbsenceTableAdapter = Nothing
        Me.TableAdapterManager.ApplicantTableAdapter = Me.ApplicantTableAdapter
        Me.TableAdapterManager.AppointmentTableAdapter = Nothing
        Me.TableAdapterManager.Appt_guestTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComplaintTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Nothing
        Me.TableAdapterManager.PositionTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'AppointmentTableAdapter
        '
        Me.AppointmentTableAdapter.ClearBeforeFill = True
        '
        'btnEditPositions
        '
        Me.btnEditPositions.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEditPositions.Location = New System.Drawing.Point(13, 628)
        Me.btnEditPositions.Name = "btnEditPositions"
        Me.btnEditPositions.Size = New System.Drawing.Size(163, 31)
        Me.btnEditPositions.TabIndex = 30
        Me.btnEditPositions.Text = "Edit Job Positions"
        Me.btnEditPositions.UseVisualStyleBackColor = True
        '
        'btnNewApplicant
        '
        Me.btnNewApplicant.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNewApplicant.Location = New System.Drawing.Point(186, 628)
        Me.btnNewApplicant.Name = "btnNewApplicant"
        Me.btnNewApplicant.Size = New System.Drawing.Size(163, 31)
        Me.btnNewApplicant.TabIndex = 31
        Me.btnNewApplicant.Text = "Add New Applicant"
        Me.btnNewApplicant.UseVisualStyleBackColor = True
        '
        'ApplicantForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnNewApplicant)
        Me.Controls.Add(Me.btnEditPositions)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.DataGridView1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "ApplicantForm"
        Me.Text = "ApplicantForm"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ApplicantBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.numUDEndMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AppointmentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numUDEndHr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numUDStartMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numUDStartHr, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lblDate As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents txtPostCode As TextBox
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtStreet As TextBox
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtPhoneNum As TextBox
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnHireApplicant As Button
    Friend WithEvents btnRejectApplicant As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtPosition As TextBox
    Friend WithEvents txtFirstName As TextBox
    Protected Friend WithEvents cboxDisability As CheckBox
    Friend WithEvents Ist2dsDataSet As ist2dsDataSet
    Friend WithEvents txtApplicantID As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnFilterByDeptProtected As Button
    Friend WithEvents btnFilterByDept As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents txtSearchApplicantID As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents txtSearchApplicantLastName As TextBox
    Friend WithEvents txtSearchApplicantFirstName As TextBox
    Friend WithEvents ApplicantBindingSource As BindingSource
    Friend WithEvents ApplicantTableAdapter As ist2dsDataSetTableAdapters.ApplicantTableAdapter
    Friend WithEvents TableAdapterManager As ist2dsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents IDnumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FirstnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LastnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PhonenumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmailaddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StreetnameandnumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PostalcodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AppointmentIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RaceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GenderDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DisabilitystatusDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents position_name As DataGridViewTextBoxColumn
    Friend WithEvents cmbGender As ComboBox
    Friend WithEvents cmbRace As ComboBox
    Friend WithEvents numUDEndMin As NumericUpDown
    Friend WithEvents numUDEndHr As NumericUpDown
    Friend WithEvents numUDStartMin As NumericUpDown
    Friend WithEvents numUDStartHr As NumericUpDown
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents btnUpdateAppointment As Button
    Friend WithEvents AppointmentBindingSource As BindingSource
    Friend WithEvents AppointmentTableAdapter As ist2dsDataSetTableAdapters.AppointmentTableAdapter
    Friend WithEvents btnEditPositions As Button
    Friend WithEvents btnNewApplicant As Button
End Class
