﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AbsenceForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.AbsencenumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmployeeIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DatebeganDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateendedDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TypeofabsenceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AbsenceBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ist2dsDataSet = New ISTN212Project.ist2dsDataSet()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnCancelFutureAbsence = New System.Windows.Forms.Button()
        Me.btnChoose = New System.Windows.Forms.Button()
        Me.BtnAddAbsence = New System.Windows.Forms.Button()
        Me.cmbType = New System.Windows.Forms.ComboBox()
        Me.DateTimePickerEnd = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePickerStart = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DateTimePickerFilter = New System.Windows.Forms.DateTimePicker()
        Me.cboxAllDays = New System.Windows.Forms.CheckBox()
        Me.lblEmployee = New System.Windows.Forms.Label()
        Me.txtSearchEmployeeID = New System.Windows.Forms.TextBox()
        Me.cboxAllEmployees = New System.Windows.Forms.CheckBox()
        Me.BtnSearch = New System.Windows.Forms.Button()
        Me.AbsenceTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.AbsenceTableAdapter()
        Me.TableAdapterManager = New ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AbsenceBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AbsencenumberDataGridViewTextBoxColumn, Me.EmployeeIDDataGridViewTextBoxColumn, Me.DatebeganDataGridViewTextBoxColumn, Me.DateendedDataGridViewTextBoxColumn, Me.TypeofabsenceDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.AbsenceBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 33)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(925, 241)
        Me.DataGridView1.TabIndex = 1
        '
        'AbsencenumberDataGridViewTextBoxColumn
        '
        Me.AbsencenumberDataGridViewTextBoxColumn.DataPropertyName = "absence_number"
        Me.AbsencenumberDataGridViewTextBoxColumn.HeaderText = "absence_number"
        Me.AbsencenumberDataGridViewTextBoxColumn.Name = "AbsencenumberDataGridViewTextBoxColumn"
        Me.AbsencenumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'EmployeeIDDataGridViewTextBoxColumn
        '
        Me.EmployeeIDDataGridViewTextBoxColumn.DataPropertyName = "employee_ID"
        Me.EmployeeIDDataGridViewTextBoxColumn.HeaderText = "employee_ID"
        Me.EmployeeIDDataGridViewTextBoxColumn.Name = "EmployeeIDDataGridViewTextBoxColumn"
        Me.EmployeeIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DatebeganDataGridViewTextBoxColumn
        '
        Me.DatebeganDataGridViewTextBoxColumn.DataPropertyName = "date_began"
        Me.DatebeganDataGridViewTextBoxColumn.HeaderText = "date_began"
        Me.DatebeganDataGridViewTextBoxColumn.Name = "DatebeganDataGridViewTextBoxColumn"
        Me.DatebeganDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DateendedDataGridViewTextBoxColumn
        '
        Me.DateendedDataGridViewTextBoxColumn.DataPropertyName = "date_ended"
        Me.DateendedDataGridViewTextBoxColumn.HeaderText = "date_ended"
        Me.DateendedDataGridViewTextBoxColumn.Name = "DateendedDataGridViewTextBoxColumn"
        Me.DateendedDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TypeofabsenceDataGridViewTextBoxColumn
        '
        Me.TypeofabsenceDataGridViewTextBoxColumn.DataPropertyName = "type_of_absence"
        Me.TypeofabsenceDataGridViewTextBoxColumn.HeaderText = "type_of_absence"
        Me.TypeofabsenceDataGridViewTextBoxColumn.Name = "TypeofabsenceDataGridViewTextBoxColumn"
        Me.TypeofabsenceDataGridViewTextBoxColumn.ReadOnly = True
        '
        'AbsenceBindingSource
        '
        Me.AbsenceBindingSource.DataMember = "Absence"
        Me.AbsenceBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'Ist2dsDataSet
        '
        Me.Ist2dsDataSet.DataSetName = "ist2dsDataSet"
        Me.Ist2dsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(720, 9)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(37, 16)
        Me.lblDate.TabIndex = 2
        Me.lblDate.Text = "Date"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.btnCancelFutureAbsence)
        Me.GroupBox3.Controls.Add(Me.btnChoose)
        Me.GroupBox3.Controls.Add(Me.BtnAddAbsence)
        Me.GroupBox3.Controls.Add(Me.cmbType)
        Me.GroupBox3.Controls.Add(Me.DateTimePickerEnd)
        Me.GroupBox3.Controls.Add(Me.DateTimePickerStart)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.txtEmployeeID)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Location = New System.Drawing.Point(402, 280)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(535, 319)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Details"
        '
        'btnCancelFutureAbsence
        '
        Me.btnCancelFutureAbsence.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnCancelFutureAbsence.Location = New System.Drawing.Point(243, 233)
        Me.btnCancelFutureAbsence.Name = "btnCancelFutureAbsence"
        Me.btnCancelFutureAbsence.Size = New System.Drawing.Size(280, 32)
        Me.btnCancelFutureAbsence.TabIndex = 17
        Me.btnCancelFutureAbsence.Text = "Cancel This Planned Absence"
        Me.btnCancelFutureAbsence.UseVisualStyleBackColor = True
        Me.btnCancelFutureAbsence.Visible = False
        '
        'btnChoose
        '
        Me.btnChoose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnChoose.Location = New System.Drawing.Point(448, 17)
        Me.btnChoose.Name = "btnChoose"
        Me.btnChoose.Size = New System.Drawing.Size(75, 32)
        Me.btnChoose.TabIndex = 16
        Me.btnChoose.Text = "Choose"
        Me.btnChoose.UseVisualStyleBackColor = True
        '
        'BtnAddAbsence
        '
        Me.BtnAddAbsence.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnAddAbsence.Location = New System.Drawing.Point(350, 155)
        Me.BtnAddAbsence.Name = "BtnAddAbsence"
        Me.BtnAddAbsence.Size = New System.Drawing.Size(174, 32)
        Me.BtnAddAbsence.TabIndex = 15
        Me.BtnAddAbsence.Text = "Record This Absence"
        Me.BtnAddAbsence.UseVisualStyleBackColor = True
        Me.BtnAddAbsence.Visible = False
        '
        'cmbType
        '
        Me.cmbType.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AbsenceBindingSource, "type_of_absence", True))
        Me.cmbType.FormattingEnabled = True
        Me.cmbType.Items.AddRange(New Object() {"Annual Leave", "Family Responsibility Leave", "Maternity Leave", "Sick Leave", ""})
        Me.cmbType.Location = New System.Drawing.Point(243, 109)
        Me.cmbType.Name = "cmbType"
        Me.cmbType.Size = New System.Drawing.Size(280, 24)
        Me.cmbType.TabIndex = 14
        '
        'DateTimePickerEnd
        '
        Me.DateTimePickerEnd.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AbsenceBindingSource, "date_ended", True))
        Me.DateTimePickerEnd.Enabled = False
        Me.DateTimePickerEnd.Location = New System.Drawing.Point(243, 81)
        Me.DateTimePickerEnd.Name = "DateTimePickerEnd"
        Me.DateTimePickerEnd.Size = New System.Drawing.Size(280, 22)
        Me.DateTimePickerEnd.TabIndex = 13
        '
        'DateTimePickerStart
        '
        Me.DateTimePickerStart.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AbsenceBindingSource, "date_began", True))
        Me.DateTimePickerStart.Enabled = False
        Me.DateTimePickerStart.Location = New System.Drawing.Point(243, 51)
        Me.DateTimePickerStart.Name = "DateTimePickerStart"
        Me.DateTimePickerStart.Size = New System.Drawing.Size(280, 22)
        Me.DateTimePickerStart.TabIndex = 12
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label5.Location = New System.Drawing.Point(22, 25)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 16)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Employee ID:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label4.Location = New System.Drawing.Point(22, 109)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(113, 16)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Type of absence:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label3.Location = New System.Drawing.Point(22, 81)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Date ended:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label2.Location = New System.Drawing.Point(22, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Date began:"
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AbsenceBindingSource, "employee_ID", True))
        Me.txtEmployeeID.Location = New System.Drawing.Point(243, 22)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.ReadOnly = True
        Me.txtEmployeeID.Size = New System.Drawing.Size(200, 22)
        Me.txtEmployeeID.TabIndex = 4
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(24, 614)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(98, 31)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back to menu"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.DateTimePickerFilter)
        Me.GroupBox1.Controls.Add(Me.cboxAllDays)
        Me.GroupBox1.Controls.Add(Me.lblEmployee)
        Me.GroupBox1.Controls.Add(Me.txtSearchEmployeeID)
        Me.GroupBox1.Controls.Add(Me.cboxAllEmployees)
        Me.GroupBox1.Controls.Add(Me.BtnSearch)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(24, 280)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(357, 319)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Filter"
        '
        'DateTimePickerFilter
        '
        Me.DateTimePickerFilter.Location = New System.Drawing.Point(95, 52)
        Me.DateTimePickerFilter.Name = "DateTimePickerFilter"
        Me.DateTimePickerFilter.Size = New System.Drawing.Size(227, 22)
        Me.DateTimePickerFilter.TabIndex = 12
        '
        'cboxAllDays
        '
        Me.cboxAllDays.AutoSize = True
        Me.cboxAllDays.Location = New System.Drawing.Point(95, 21)
        Me.cboxAllDays.Name = "cboxAllDays"
        Me.cboxAllDays.Size = New System.Drawing.Size(100, 20)
        Me.cboxAllDays.TabIndex = 11
        Me.cboxAllDays.Text = "For All Days"
        Me.cboxAllDays.UseVisualStyleBackColor = True
        '
        'lblEmployee
        '
        Me.lblEmployee.AutoSize = True
        Me.lblEmployee.Location = New System.Drawing.Point(13, 243)
        Me.lblEmployee.Name = "lblEmployee"
        Me.lblEmployee.Size = New System.Drawing.Size(76, 16)
        Me.lblEmployee.TabIndex = 10
        Me.lblEmployee.Text = "Employee: "
        '
        'txtSearchEmployeeID
        '
        Me.txtSearchEmployeeID.Location = New System.Drawing.Point(95, 243)
        Me.txtSearchEmployeeID.Name = "txtSearchEmployeeID"
        Me.txtSearchEmployeeID.Size = New System.Drawing.Size(227, 22)
        Me.txtSearchEmployeeID.TabIndex = 9
        '
        'cboxAllEmployees
        '
        Me.cboxAllEmployees.AutoSize = True
        Me.cboxAllEmployees.Location = New System.Drawing.Point(95, 217)
        Me.cboxAllEmployees.Name = "cboxAllEmployees"
        Me.cboxAllEmployees.Size = New System.Drawing.Size(137, 20)
        Me.cboxAllEmployees.TabIndex = 6
        Me.cboxAllEmployees.Text = "For All Employees"
        Me.cboxAllEmployees.UseVisualStyleBackColor = True
        '
        'BtnSearch
        '
        Me.BtnSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnSearch.Location = New System.Drawing.Point(95, 281)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.Size = New System.Drawing.Size(75, 32)
        Me.BtnSearch.TabIndex = 4
        Me.BtnSearch.Text = "Search"
        Me.BtnSearch.UseVisualStyleBackColor = True
        '
        'AbsenceTableAdapter
        '
        Me.AbsenceTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AbsenceTableAdapter = Me.AbsenceTableAdapter
        Me.TableAdapterManager.ApplicantTableAdapter = Nothing
        Me.TableAdapterManager.AppointmentTableAdapter = Nothing
        Me.TableAdapterManager.Appt_guestTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComplaintTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Nothing
        Me.TableAdapterManager.PositionTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'AbsenceForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(949, 657)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.DataGridView1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "AbsenceForm"
        Me.Text = "AbsenceForm"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AbsenceBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lblDate As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents cboxAllDays As CheckBox
    Friend WithEvents lblEmployee As Label
    Friend WithEvents txtSearchEmployeeID As TextBox
    Friend WithEvents cboxAllEmployees As CheckBox
    Friend WithEvents BtnSearch As Button
    Friend WithEvents Ist2dsDataSet As ist2dsDataSet
    Friend WithEvents AbsenceBindingSource As BindingSource
    Friend WithEvents AbsenceTableAdapter As ist2dsDataSetTableAdapters.AbsenceTableAdapter
    Friend WithEvents TableAdapterManager As ist2dsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents AbsencenumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmployeeIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DatebeganDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateendedDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TypeofabsenceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BtnAddAbsence As Button
    Friend WithEvents cmbType As ComboBox
    Friend WithEvents DateTimePickerEnd As DateTimePicker
    Friend WithEvents DateTimePickerStart As DateTimePicker
    Friend WithEvents btnChoose As Button
    Friend WithEvents btnCancelFutureAbsence As Button
    Friend WithEvents DateTimePickerFilter As DateTimePicker
End Class
