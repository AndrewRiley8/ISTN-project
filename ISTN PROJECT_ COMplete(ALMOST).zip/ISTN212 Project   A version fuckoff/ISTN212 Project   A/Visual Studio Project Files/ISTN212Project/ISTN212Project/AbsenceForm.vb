﻿Public Class AbsenceForm
    Private Sub AbsenceForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()

    End Sub

    Private Sub AbsenceForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Absence' table. You can move, or remove it, as needed.
        Me.AbsenceTableAdapter.Fill(Me.Ist2dsDataSet.Absence)

    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        FunctionResources.filterAbsences(cboxAllDays.Checked, DateTimePickerFilter.Value, cboxAllEmployees.Checked, txtSearchEmployeeID.Text)
    End Sub

    Private Sub BtnAddAbsence_Click(sender As Object, e As EventArgs) Handles BtnAddAbsence.Click
        FunctionResources.addAbsence(txtEmployeeID.Text, DateTimePickerStart.Text, DateTimePickerEnd.Text, cmbType.Text)
    End Sub


    Private Sub BtnChoose_Click(sender As Object, e As EventArgs) Handles btnChoose.Click
        MenuForm.openEmployeeSelectorFrom(EmployeeSelectionForm.Absences)
    End Sub

    Private Sub btnCancelFutureAbsence_Click(sender As Object, e As EventArgs) Handles btnCancelFutureAbsence.Click
        FunctionResources.cancelLeave(txtEmployeeID.Text, DateTimePickerStart.Text)
    End Sub
End Class