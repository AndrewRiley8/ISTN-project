﻿Public Class ApplicantForm
    Public Dept As String
    Private Sub ApplicantForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub ApplicantForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.Ist2dsDataSet.Appointment)
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Applicant' table. You can move, or remove it, as needed.

        'ODO: This line of code loads data into the 'Ist2dsDataSet.Applicant' table. You can move, or remove it, as needed.
        Me.ApplicantTableAdapter.Fill(Me.Ist2dsDataSet.Applicant)

        FunctionResources.filterApplicants(Me.Ist2dsDataSet.Applicant, Me.ApplicantTableAdapter, Dept, False)



    End Sub
    '_____________________________________________________________________________________________________________
    'BUTTON EVENT HANDLERS

    'back button'
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()
    End Sub

    'edit positions
    Private Sub btnEditPositions_Click(sender As Object, e As EventArgs) Handles btnEditPositions.Click
        MenuForm.openPositionsAsAdd(Dept)
    End Sub

    'set an interview appointment
    Private Sub btnUpdateAppointment_Click(sender As Object, e As EventArgs) Handles btnUpdateAppointment.Click
        AppointmentForm.Applicant = txtApplicantID.Text
        MenuForm.openAppointmentsAsAdd(AppointmentForm.Applicants)
    End Sub

    'add new applicant
    Private Sub btnNewApplicant_Click(sender As Object, e As EventArgs) Handles btnNewApplicant.Click
        'doesn't hide this form
        MenuForm.openNewPersonFrom(AddNewPersonForm.Applicant)
    End Sub

    'search
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Functions.searchApplicant(Ist2dsDataSet.Applicant, Me.ApplicantTableAdapter, txtSearchApplicantID.Text, txtSearchApplicantFirstName.Text, txtSearchApplicantLastName.Text, Dept)
    End Sub
    'filter
    Private Sub btnFilterByDept_Click(sender As Object, e As EventArgs) Handles btnFilterByDept.Click
        Functions.filterApplicants(Ist2dsDataSet.Applicant, Me.ApplicantTableAdapter, Dept, False)
    End Sub

    Private Sub btnFilterByDeptProtected_Click(sender As Object, e As EventArgs) Handles btnFilterByDeptProtected.Click
        Functions.filterApplicants(ist2dsDataSet.Applicant, Me.ApplicantTableAdapter, Dept, True)
    End Sub
    'reject applicant
    Private Sub btnRejectApplicant_Click(sender As Object, e As EventArgs) Handles btnRejectApplicant.Click
        Functions.deleteApplicant(txtApplicantID.Text)
    End Sub
    'hire applicant
    Private Sub btnHireApplicant_Click(sender As Object, e As EventArgs) Handles btnHireApplicant.Click
        'enter fields from applicant to employee
        AddNewPersonForm.txtCity.Text = txtCity.Text
        AddNewPersonForm.txtIDNum.Text = txtApplicantID.Text
        AddNewPersonForm.txtFirstName.Text = txtFirstName.Text
        AddNewPersonForm.txtLastName.Text = txtLastName.Text
        AddNewPersonForm.txtPhoneNum.Text = txtPhoneNum.Text
        AddNewPersonForm.txtPosition.Text = txtPosition.Text
        AddNewPersonForm.txtPostCode.Text = txtPostCode.Text
        AddNewPersonForm.txtStreet.Text = txtStreet.Text
        AddNewPersonForm.txtEmail.Text = txtEmail.Text
        AddNewPersonForm.cmbGender.SelectedItem = cmbGender.SelectedItem
        AddNewPersonForm.cmbRace.Text = cmbRace.Text
        AddNewPersonForm.cboxDisability.CheckState = cboxDisability.Checked
        'doesn't hide this form
        MenuForm.openNewPersonFrom(AddNewPersonForm.Employee)
    End Sub
End Class