﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ApptGuestForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.EmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ist2dsDataSet = New ISTN212Project.ist2dsDataSet()
        Me.EmployeeTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.EmployeeTableAdapter()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtEmployeeLastName = New System.Windows.Forms.TextBox()
        Me.txtEmployeeFirstName = New System.Windows.Forms.TextBox()
        Me.rdbRemoveGuests = New System.Windows.Forms.RadioButton()
        Me.rdbAddGuests = New System.Windows.Forms.RadioButton()
        Me.btnAddRemove = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtSearchEmployeeID = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSearchEmployeeLastName = New System.Windows.Forms.TextBox()
        Me.txtSearchEmployeeFirstName = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.Appt_guestBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Appt_guestTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.Appt_guestTableAdapter()
        Me.TableAdapterManager = New ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager()
        Me.EmployeeIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.first_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.last_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.date_of_hire = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.position_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Appt_guestBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'EmployeeBindingSource
        '
        Me.EmployeeBindingSource.DataMember = "Employee"
        Me.EmployeeBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'Ist2dsDataSet
        '
        Me.Ist2dsDataSet.DataSetName = "ist2dsDataSet"
        Me.Ist2dsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EmployeeTableAdapter
        '
        Me.EmployeeTableAdapter.ClearBeforeFill = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtEmployeeID)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtEmployeeLastName)
        Me.GroupBox1.Controls.Add(Me.txtEmployeeFirstName)
        Me.GroupBox1.Controls.Add(Me.rdbRemoveGuests)
        Me.GroupBox1.Controls.Add(Me.rdbAddGuests)
        Me.GroupBox1.Controls.Add(Me.btnAddRemove)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(370, 217)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(372, 252)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Change Guest List"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(115, 86)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 16)
        Me.Label6.TabIndex = 47
        Me.Label6.Text = "Currently Selected:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(23, 120)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 16)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Employee ID:"
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.Location = New System.Drawing.Point(118, 117)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.Size = New System.Drawing.Size(212, 22)
        Me.txtEmployeeID.TabIndex = 41
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(23, 148)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(73, 16)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "First name:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(23, 177)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 16)
        Me.Label5.TabIndex = 44
        Me.Label5.Text = "Last name:"
        '
        'txtEmployeeLastName
        '
        Me.txtEmployeeLastName.Location = New System.Drawing.Point(118, 177)
        Me.txtEmployeeLastName.Name = "txtEmployeeLastName"
        Me.txtEmployeeLastName.Size = New System.Drawing.Size(212, 22)
        Me.txtEmployeeLastName.TabIndex = 46
        '
        'txtEmployeeFirstName
        '
        Me.txtEmployeeFirstName.Location = New System.Drawing.Point(118, 148)
        Me.txtEmployeeFirstName.Name = "txtEmployeeFirstName"
        Me.txtEmployeeFirstName.Size = New System.Drawing.Size(212, 22)
        Me.txtEmployeeFirstName.TabIndex = 45
        '
        'rdbRemoveGuests
        '
        Me.rdbRemoveGuests.AutoSize = True
        Me.rdbRemoveGuests.Checked = True
        Me.rdbRemoveGuests.Location = New System.Drawing.Point(46, 63)
        Me.rdbRemoveGuests.Name = "rdbRemoveGuests"
        Me.rdbRemoveGuests.Size = New System.Drawing.Size(271, 20)
        Me.rdbRemoveGuests.TabIndex = 6
        Me.rdbRemoveGuests.TabStop = True
        Me.rdbRemoveGuests.Text = "Remove Guests From Invited Employees"
        Me.rdbRemoveGuests.UseVisualStyleBackColor = True
        '
        'rdbAddGuests
        '
        Me.rdbAddGuests.AutoSize = True
        Me.rdbAddGuests.Location = New System.Drawing.Point(46, 20)
        Me.rdbAddGuests.Name = "rdbAddGuests"
        Me.rdbAddGuests.Size = New System.Drawing.Size(261, 20)
        Me.rdbAddGuests.TabIndex = 5
        Me.rdbAddGuests.TabStop = True
        Me.rdbAddGuests.Text = "Add Guests From Uninvited Employees"
        Me.rdbAddGuests.UseVisualStyleBackColor = True
        '
        'btnAddRemove
        '
        Me.btnAddRemove.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnAddRemove.Location = New System.Drawing.Point(118, 209)
        Me.btnAddRemove.Name = "btnAddRemove"
        Me.btnAddRemove.Size = New System.Drawing.Size(212, 32)
        Me.btnAddRemove.TabIndex = 4
        Me.btnAddRemove.Text = "Remove"
        Me.btnAddRemove.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.btnSearch)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.txtSearchEmployeeID)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txtSearchEmployeeLastName)
        Me.GroupBox2.Controls.Add(Me.txtSearchEmployeeFirstName)
        Me.GroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Location = New System.Drawing.Point(12, 217)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(336, 183)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Navigation"
        '
        'btnSearch
        '
        Me.btnSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSearch.Location = New System.Drawing.Point(9, 143)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 32)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(11, 28)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(89, 16)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "Employee ID:"
        '
        'txtSearchEmployeeID
        '
        Me.txtSearchEmployeeID.Location = New System.Drawing.Point(106, 25)
        Me.txtSearchEmployeeID.Name = "txtSearchEmployeeID"
        Me.txtSearchEmployeeID.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeID.TabIndex = 28
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 16)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "First name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 16)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Last name:"
        '
        'txtSearchEmployeeLastName
        '
        Me.txtSearchEmployeeLastName.Location = New System.Drawing.Point(106, 85)
        Me.txtSearchEmployeeLastName.Name = "txtSearchEmployeeLastName"
        Me.txtSearchEmployeeLastName.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeLastName.TabIndex = 40
        '
        'txtSearchEmployeeFirstName
        '
        Me.txtSearchEmployeeFirstName.Location = New System.Drawing.Point(106, 56)
        Me.txtSearchEmployeeFirstName.Name = "txtSearchEmployeeFirstName"
        Me.txtSearchEmployeeFirstName.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeFirstName.TabIndex = 39
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.EmployeeIDDataGridViewTextBoxColumn, Me.first_name, Me.last_name, Me.date_of_hire, Me.position_name})
        Me.DataGridView1.DataSource = Me.EmployeeBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 13)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(730, 198)
        Me.DataGridView1.TabIndex = 6
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(12, 438)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(188, 31)
        Me.btnBack.TabIndex = 7
        Me.btnBack.Text = "Back to Appointments"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'Appt_guestBindingSource
        '
        Me.Appt_guestBindingSource.DataMember = "Appt_guest"
        Me.Appt_guestBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'Appt_guestTableAdapter
        '
        Me.Appt_guestTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AbsenceTableAdapter = Nothing
        Me.TableAdapterManager.ApplicantTableAdapter = Nothing
        Me.TableAdapterManager.AppointmentTableAdapter = Nothing
        Me.TableAdapterManager.Appt_guestTableAdapter = Me.Appt_guestTableAdapter
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComplaintTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Me.EmployeeTableAdapter
        Me.TableAdapterManager.PositionTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'EmployeeIDDataGridViewTextBoxColumn
        '
        Me.EmployeeIDDataGridViewTextBoxColumn.DataPropertyName = "employee_ID"
        Me.EmployeeIDDataGridViewTextBoxColumn.HeaderText = "employee_ID"
        Me.EmployeeIDDataGridViewTextBoxColumn.Name = "EmployeeIDDataGridViewTextBoxColumn"
        '
        'first_name
        '
        Me.first_name.DataPropertyName = "first_name"
        Me.first_name.HeaderText = "first_name"
        Me.first_name.Name = "first_name"
        '
        'last_name
        '
        Me.last_name.DataPropertyName = "last_name"
        Me.last_name.HeaderText = "last_name"
        Me.last_name.Name = "last_name"
        '
        'date_of_hire
        '
        Me.date_of_hire.DataPropertyName = "date_of_hire"
        Me.date_of_hire.HeaderText = "date_of_hire"
        Me.date_of_hire.Name = "date_of_hire"
        '
        'position_name
        '
        Me.position_name.DataPropertyName = "position_name"
        Me.position_name.HeaderText = "position_name"
        Me.position_name.Name = "position_name"
        '
        'ApptGuestForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(754, 481)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "ApptGuestForm"
        Me.Text = "ApptGuestForm"
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Appt_guestBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Ist2dsDataSet As ist2dsDataSet
    Friend WithEvents EmployeeBindingSource As BindingSource
    Friend WithEvents EmployeeTableAdapter As ist2dsDataSetTableAdapters.EmployeeTableAdapter
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnAddRemove As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents Label15 As Label
    Friend WithEvents txtSearchEmployeeID As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtSearchEmployeeLastName As TextBox
    Friend WithEvents txtSearchEmployeeFirstName As TextBox
    Friend WithEvents rdbRemoveGuests As RadioButton
    Friend WithEvents rdbAddGuests As RadioButton
    Friend WithEvents Label6 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtEmployeeLastName As TextBox
    Friend WithEvents txtEmployeeFirstName As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnBack As Button
    Friend WithEvents Appt_guestBindingSource As BindingSource
    Friend WithEvents Appt_guestTableAdapter As ist2dsDataSetTableAdapters.Appt_guestTableAdapter
    Friend WithEvents TableAdapterManager As ist2dsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents EmployeeIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents first_name As DataGridViewTextBoxColumn
    Friend WithEvents last_name As DataGridViewTextBoxColumn
    Friend WithEvents date_of_hire As DataGridViewTextBoxColumn
    Friend WithEvents position_name As DataGridViewTextBoxColumn
End Class
