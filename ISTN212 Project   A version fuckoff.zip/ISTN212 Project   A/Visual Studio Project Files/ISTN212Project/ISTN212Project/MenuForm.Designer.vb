﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MenuForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnSignOut = New System.Windows.Forms.Button()
        Me.lblDateTime = New System.Windows.Forms.Label()
        Me.btnAbout = New System.Windows.Forms.Button()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.p = New System.Windows.Forms.PictureBox()
        Me.pboxHelp = New System.Windows.Forms.PictureBox()
        Me.ttHelp = New System.Windows.Forms.ToolTip(Me.components)
        Me.ttTools = New System.Windows.Forms.ToolTip(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HiringToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AdministrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EngineeringToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FinanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HumanResourcesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MarketingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TerminationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TermEmplToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewTerminationHistoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GeneralToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComplaintsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewAllComplaintsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewComplaintToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AbsencesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewAllAbsencesToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewAbsenceToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditGenEmployeeDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AppointmentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewAllAppointmentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddNewAppointmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewTablesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnalyticsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ComplaintsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.DiversityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.p, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pboxHelp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnSignOut
        '
        Me.btnSignOut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.btnSignOut.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSignOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSignOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSignOut.ImageAlign = System.Drawing.ContentAlignment.TopRight
        Me.btnSignOut.Location = New System.Drawing.Point(12, 369)
        Me.btnSignOut.Name = "btnSignOut"
        Me.btnSignOut.Size = New System.Drawing.Size(94, 31)
        Me.btnSignOut.TabIndex = 1
        Me.btnSignOut.Text = "Sign Out"
        Me.btnSignOut.UseVisualStyleBackColor = True
        '
        'lblDateTime
        '
        Me.lblDateTime.AutoSize = True
        Me.lblDateTime.BackColor = System.Drawing.Color.Transparent
        Me.lblDateTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblDateTime.Location = New System.Drawing.Point(178, 51)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(43, 16)
        Me.lblDateTime.TabIndex = 3
        Me.lblDateTime.Text = "Date: "
        '
        'btnAbout
        '
        Me.btnAbout.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.abt
        Me.btnAbout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btnAbout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAbout.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAbout.ForeColor = System.Drawing.Color.Transparent
        Me.btnAbout.Location = New System.Drawing.Point(223, 349)
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(56, 51)
        Me.btnAbout.TabIndex = 11
        Me.ttHelp.SetToolTip(Me.btnAbout, "Find out more about this system from the developers")
        Me.btnAbout.UseVisualStyleBackColor = True
        '
        'lblWelcome
        '
        Me.lblWelcome.AutoSize = True
        Me.lblWelcome.BackColor = System.Drawing.Color.Transparent
        Me.lblWelcome.Cursor = System.Windows.Forms.Cursors.PanWest
        Me.lblWelcome.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.ForeColor = System.Drawing.Color.White
        Me.lblWelcome.Location = New System.Drawing.Point(178, 24)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(66, 16)
        Me.lblWelcome.TabIndex = 2
        Me.lblWelcome.Text = "Welcome"
        '
        'p
        '
        Me.p.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.download
        Me.p.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.p.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.p.Location = New System.Drawing.Point(12, 12)
        Me.p.Name = "p"
        Me.p.Size = New System.Drawing.Size(141, 83)
        Me.p.TabIndex = 14
        Me.p.TabStop = False
        Me.ttHelp.SetToolTip(Me.p, "An EMS that makes your business more effecient!")
        '
        'pboxHelp
        '
        Me.pboxHelp.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.help
        Me.pboxHelp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pboxHelp.Cursor = System.Windows.Forms.Cursors.Help
        Me.pboxHelp.Location = New System.Drawing.Point(300, 349)
        Me.pboxHelp.Name = "pboxHelp"
        Me.pboxHelp.Size = New System.Drawing.Size(57, 51)
        Me.pboxHelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pboxHelp.TabIndex = 15
        Me.pboxHelp.TabStop = False
        Me.ttHelp.SetToolTip(Me.pboxHelp, "Information to assist you")
        '
        'ttHelp
        '
        Me.ttHelp.IsBalloon = True
        Me.ttHelp.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ttHelp.ToolTipTitle = "Help"
        '
        'ttTools
        '
        Me.ttTools.IsBalloon = True
        Me.ttTools.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.ttTools.ToolTipTitle = "Tools"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.MenuStrip1.BackColor = System.Drawing.Color.White
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HiringToolStripMenuItem, Me.TerminationsToolStripMenuItem, Me.GeneralToolStripMenuItem, Me.AppointmentsToolStripMenuItem, Me.ViewTablesToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(12, 120)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(437, 24)
        Me.MenuStrip1.TabIndex = 16
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'HiringToolStripMenuItem
        '
        Me.HiringToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccountingToolStripMenuItem, Me.AdministrationToolStripMenuItem, Me.EngineeringToolStripMenuItem, Me.FinanceToolStripMenuItem, Me.HumanResourcesToolStripMenuItem, Me.ITToolStripMenuItem, Me.MarketingToolStripMenuItem, Me.SalesToolStripMenuItem, Me.AllToolStripMenuItem})
        Me.HiringToolStripMenuItem.Name = "HiringToolStripMenuItem"
        Me.HiringToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.HiringToolStripMenuItem.Text = "Hiring"
        '
        'AccountingToolStripMenuItem
        '
        Me.AccountingToolStripMenuItem.Name = "AccountingToolStripMenuItem"
        Me.AccountingToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.AccountingToolStripMenuItem.Text = "Accounting"
        '
        'AdministrationToolStripMenuItem
        '
        Me.AdministrationToolStripMenuItem.Name = "AdministrationToolStripMenuItem"
        Me.AdministrationToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.AdministrationToolStripMenuItem.Text = "Administration"
        '
        'EngineeringToolStripMenuItem
        '
        Me.EngineeringToolStripMenuItem.Name = "EngineeringToolStripMenuItem"
        Me.EngineeringToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.EngineeringToolStripMenuItem.Text = "Engineering"
        '
        'FinanceToolStripMenuItem
        '
        Me.FinanceToolStripMenuItem.Name = "FinanceToolStripMenuItem"
        Me.FinanceToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.FinanceToolStripMenuItem.Text = "Finance"
        '
        'HumanResourcesToolStripMenuItem
        '
        Me.HumanResourcesToolStripMenuItem.Name = "HumanResourcesToolStripMenuItem"
        Me.HumanResourcesToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.HumanResourcesToolStripMenuItem.Text = "Human Resources"
        '
        'ITToolStripMenuItem
        '
        Me.ITToolStripMenuItem.Name = "ITToolStripMenuItem"
        Me.ITToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.ITToolStripMenuItem.Text = "IT"
        '
        'MarketingToolStripMenuItem
        '
        Me.MarketingToolStripMenuItem.Name = "MarketingToolStripMenuItem"
        Me.MarketingToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.MarketingToolStripMenuItem.Text = "Marketing"
        '
        'SalesToolStripMenuItem
        '
        Me.SalesToolStripMenuItem.Name = "SalesToolStripMenuItem"
        Me.SalesToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.SalesToolStripMenuItem.Text = "Sales"
        '
        'AllToolStripMenuItem
        '
        Me.AllToolStripMenuItem.Name = "AllToolStripMenuItem"
        Me.AllToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.AllToolStripMenuItem.Text = "All"
        '
        'TerminationsToolStripMenuItem
        '
        Me.TerminationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TermEmplToolStripMenuItem, Me.ViewTerminationHistoryToolStripMenuItem})
        Me.TerminationsToolStripMenuItem.Name = "TerminationsToolStripMenuItem"
        Me.TerminationsToolStripMenuItem.Size = New System.Drawing.Size(87, 20)
        Me.TerminationsToolStripMenuItem.Text = "Terminations"
        '
        'TermEmplToolStripMenuItem
        '
        Me.TermEmplToolStripMenuItem.Name = "TermEmplToolStripMenuItem"
        Me.TermEmplToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.TermEmplToolStripMenuItem.Text = "Terminate Employee"
        '
        'ViewTerminationHistoryToolStripMenuItem
        '
        Me.ViewTerminationHistoryToolStripMenuItem.Name = "ViewTerminationHistoryToolStripMenuItem"
        Me.ViewTerminationHistoryToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.ViewTerminationHistoryToolStripMenuItem.Text = "View Termination History"
        '
        'GeneralToolStripMenuItem
        '
        Me.GeneralToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ComplaintsToolStripMenuItem, Me.AbsencesToolStripMenuItem, Me.EditGenEmployeeDetailsToolStripMenuItem})
        Me.GeneralToolStripMenuItem.Name = "GeneralToolStripMenuItem"
        Me.GeneralToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.GeneralToolStripMenuItem.Text = "General"
        '
        'ComplaintsToolStripMenuItem
        '
        Me.ComplaintsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewAllComplaintsToolStripMenuItem1, Me.AddNewComplaintToolStripMenuItem1})
        Me.ComplaintsToolStripMenuItem.Name = "ComplaintsToolStripMenuItem"
        Me.ComplaintsToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.ComplaintsToolStripMenuItem.Text = "Complaints"
        '
        'ViewAllComplaintsToolStripMenuItem1
        '
        Me.ViewAllComplaintsToolStripMenuItem1.Name = "ViewAllComplaintsToolStripMenuItem1"
        Me.ViewAllComplaintsToolStripMenuItem1.Size = New System.Drawing.Size(123, 22)
        Me.ViewAllComplaintsToolStripMenuItem1.Text = "View All"
        '
        'AddNewComplaintToolStripMenuItem1
        '
        Me.AddNewComplaintToolStripMenuItem1.Name = "AddNewComplaintToolStripMenuItem1"
        Me.AddNewComplaintToolStripMenuItem1.Size = New System.Drawing.Size(123, 22)
        Me.AddNewComplaintToolStripMenuItem1.Text = "Add New"
        '
        'AbsencesToolStripMenuItem
        '
        Me.AbsencesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewAllAbsencesToolStripMenuItem2, Me.AddNewAbsenceToolStripMenuItem2})
        Me.AbsencesToolStripMenuItem.Name = "AbsencesToolStripMenuItem"
        Me.AbsencesToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.AbsencesToolStripMenuItem.Text = "Absences"
        '
        'ViewAllAbsencesToolStripMenuItem2
        '
        Me.ViewAllAbsencesToolStripMenuItem2.Name = "ViewAllAbsencesToolStripMenuItem2"
        Me.ViewAllAbsencesToolStripMenuItem2.Size = New System.Drawing.Size(123, 22)
        Me.ViewAllAbsencesToolStripMenuItem2.Text = "View All"
        '
        'AddNewAbsenceToolStripMenuItem2
        '
        Me.AddNewAbsenceToolStripMenuItem2.Name = "AddNewAbsenceToolStripMenuItem2"
        Me.AddNewAbsenceToolStripMenuItem2.Size = New System.Drawing.Size(123, 22)
        Me.AddNewAbsenceToolStripMenuItem2.Text = "Add New"
        '
        'EditGenEmployeeDetailsToolStripMenuItem
        '
        Me.EditGenEmployeeDetailsToolStripMenuItem.Name = "EditGenEmployeeDetailsToolStripMenuItem"
        Me.EditGenEmployeeDetailsToolStripMenuItem.Size = New System.Drawing.Size(187, 22)
        Me.EditGenEmployeeDetailsToolStripMenuItem.Text = "Edit Employee Details"
        '
        'AppointmentsToolStripMenuItem
        '
        Me.AppointmentsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewAllAppointmentsToolStripMenuItem, Me.AddNewAppointmentToolStripMenuItem})
        Me.AppointmentsToolStripMenuItem.Name = "AppointmentsToolStripMenuItem"
        Me.AppointmentsToolStripMenuItem.Size = New System.Drawing.Size(95, 20)
        Me.AppointmentsToolStripMenuItem.Text = "Appointments"
        '
        'ViewAllAppointmentsToolStripMenuItem
        '
        Me.ViewAllAppointmentsToolStripMenuItem.Name = "ViewAllAppointmentsToolStripMenuItem"
        Me.ViewAllAppointmentsToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.ViewAllAppointmentsToolStripMenuItem.Text = "View All"
        '
        'AddNewAppointmentToolStripMenuItem
        '
        Me.AddNewAppointmentToolStripMenuItem.Name = "AddNewAppointmentToolStripMenuItem"
        Me.AddNewAppointmentToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.AddNewAppointmentToolStripMenuItem.Text = "Add New "
        '
        'ViewTablesToolStripMenuItem
        '
        Me.ViewTablesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AnalyticsToolStripMenuItem})
        Me.ViewTablesToolStripMenuItem.Name = "ViewTablesToolStripMenuItem"
        Me.ViewTablesToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.ViewTablesToolStripMenuItem.Text = "Misc"
        '
        'AnalyticsToolStripMenuItem
        '
        Me.AnalyticsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ComplaintsToolStripMenuItem1, Me.DiversityToolStripMenuItem})
        Me.AnalyticsToolStripMenuItem.Name = "AnalyticsToolStripMenuItem"
        Me.AnalyticsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AnalyticsToolStripMenuItem.Text = "Analytics"
        '
        'ComplaintsToolStripMenuItem1
        '
        Me.ComplaintsToolStripMenuItem1.Name = "ComplaintsToolStripMenuItem1"
        Me.ComplaintsToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.ComplaintsToolStripMenuItem1.Text = "Complaints"
        '
        'DiversityToolStripMenuItem
        '
        Me.DiversityToolStripMenuItem.Name = "DiversityToolStripMenuItem"
        Me.DiversityToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.DiversityToolStripMenuItem.Text = "Diversity"
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(112, 369)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(94, 31)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Appearance"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MenuForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(369, 420)
        Me.ControlBox = False
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.pboxHelp)
        Me.Controls.Add(Me.p)
        Me.Controls.Add(Me.btnAbout)
        Me.Controls.Add(Me.lblDateTime)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.btnSignOut)
        Me.Controls.Add(Me.MenuStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MenuForm"
        Me.Text = "Menu"
        CType(Me.p, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pboxHelp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSignOut As Button
    Friend WithEvents lblDateTime As Label
    Friend WithEvents btnAbout As Button
    Friend WithEvents lblWelcome As Label
    Friend WithEvents p As PictureBox
    Friend WithEvents pboxHelp As PictureBox
    Friend WithEvents ttHelp As ToolTip
    Friend WithEvents ttTools As ToolTip
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents HiringToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TerminationsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents GeneralToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AppointmentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewTablesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Button1 As Button
    Friend WithEvents TermEmplToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TermHistToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComplaintsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AbsencesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditGenEmployeeDetailsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewAllAppointmentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddNewAppointmentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewAllComplaintsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents AddNewComplaintToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ViewAllAbsencesToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents AddNewAbsenceToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents AccountingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AdministrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EngineeringToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HumanResourcesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ITToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MarketingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AllToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ViewTerminationHistoryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AnalyticsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComplaintsToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents DiversityToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FinanceToolStripMenuItem As ToolStripMenuItem
End Class
