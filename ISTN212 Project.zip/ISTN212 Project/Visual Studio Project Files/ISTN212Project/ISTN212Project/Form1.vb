﻿Public Class LoginForm
    Public showText As Boolean = True
    Public userName As String = ""
    Public Proceed As Boolean


    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        End
    End Sub

    Public Sub CheckEmpty()
        lblPW.Text = String.Empty
        lblUN.Text = String.Empty
        Proceed = True

        If tbPassword.Text = String.Empty Then
            Proceed = False
            lblPW.Text = "*"
        End If
        If tbUserName.Text = String.Empty Then
            Proceed = False
            lblUN.Text = "*"
        End If

    End Sub

    Private Sub btnProceed_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        Call CheckEmpty()
        If Proceed Then
            userName = tbUserName.Text
            MenuForm.lblWelcome.Text = "Welcome " & userName
            Me.Hide()
            MenuForm.Show()
        End If
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnView.Click
        If showText Then
            tbPassword.PasswordChar = ""
            showText = False
            btnView.Text = "Hide password"
        Else
            tbPassword.PasswordChar = "*"
            showText = True
            btnView.Text = "Show password"
        End If


    End Sub
End Class
