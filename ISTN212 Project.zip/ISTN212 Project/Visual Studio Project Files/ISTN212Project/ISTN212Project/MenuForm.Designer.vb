﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MenuForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnSignOut = New System.Windows.Forms.Button()
        Me.lblWelcome = New System.Windows.Forms.Label()
        Me.lblDateTime = New System.Windows.Forms.Label()
        Me.btnAbout = New System.Windows.Forms.Button()
        Me.btnHelp = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnViewEmployees = New System.Windows.Forms.Button()
        Me.btnViewDepts = New System.Windows.Forms.Button()
        Me.btnViewApplicants = New System.Windows.Forms.Button()
        Me.btnViewPositions = New System.Windows.Forms.Button()
        Me.btnViewAppointments = New System.Windows.Forms.Button()
        Me.btnViewAbsence = New System.Windows.Forms.Button()
        Me.btnViewComplaints = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(-4, -10)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(656, 616)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'btnSignOut
        '
        Me.btnSignOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSignOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSignOut.Location = New System.Drawing.Point(12, 347)
        Me.btnSignOut.Name = "btnSignOut"
        Me.btnSignOut.Size = New System.Drawing.Size(75, 31)
        Me.btnSignOut.TabIndex = 1
        Me.btnSignOut.Text = "Sign Out"
        Me.btnSignOut.UseVisualStyleBackColor = True
        '
        'lblWelcome
        '
        Me.lblWelcome.AutoSize = True
        Me.lblWelcome.BackColor = System.Drawing.Color.Black
        Me.lblWelcome.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWelcome.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblWelcome.Location = New System.Drawing.Point(12, 9)
        Me.lblWelcome.Name = "lblWelcome"
        Me.lblWelcome.Size = New System.Drawing.Size(66, 16)
        Me.lblWelcome.TabIndex = 2
        Me.lblWelcome.Text = "Welcome"
        '
        'lblDateTime
        '
        Me.lblDateTime.AutoSize = True
        Me.lblDateTime.BackColor = System.Drawing.Color.Black
        Me.lblDateTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblDateTime.Location = New System.Drawing.Point(541, 9)
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(43, 16)
        Me.lblDateTime.TabIndex = 3
        Me.lblDateTime.Text = "Date: "
        '
        'btnAbout
        '
        Me.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAbout.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAbout.Location = New System.Drawing.Point(481, 347)
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(75, 31)
        Me.btnAbout.TabIndex = 11
        Me.btnAbout.Text = "About"
        Me.btnAbout.UseVisualStyleBackColor = True
        '
        'btnHelp
        '
        Me.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnHelp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHelp.Location = New System.Drawing.Point(562, 347)
        Me.btnHelp.Name = "btnHelp"
        Me.btnHelp.Size = New System.Drawing.Size(75, 31)
        Me.btnHelp.TabIndex = 12
        Me.btnHelp.Text = "Help"
        Me.btnHelp.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.DimGray
        Me.GroupBox1.Controls.Add(Me.btnViewComplaints)
        Me.GroupBox1.Controls.Add(Me.btnViewAbsence)
        Me.GroupBox1.Controls.Add(Me.btnViewAppointments)
        Me.GroupBox1.Controls.Add(Me.btnViewPositions)
        Me.GroupBox1.Controls.Add(Me.btnViewApplicants)
        Me.GroupBox1.Controls.Add(Me.btnViewDepts)
        Me.GroupBox1.Controls.Add(Me.btnViewEmployees)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(12, 42)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(625, 272)
        Me.GroupBox1.TabIndex = 13
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Actions"
        '
        'btnViewEmployees
        '
        Me.btnViewEmployees.BackColor = System.Drawing.Color.White
        Me.btnViewEmployees.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewEmployees.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnViewEmployees.Location = New System.Drawing.Point(66, 38)
        Me.btnViewEmployees.Name = "btnViewEmployees"
        Me.btnViewEmployees.Size = New System.Drawing.Size(210, 31)
        Me.btnViewEmployees.TabIndex = 0
        Me.btnViewEmployees.Text = "View Employees"
        Me.btnViewEmployees.UseVisualStyleBackColor = False
        '
        'btnViewDepts
        '
        Me.btnViewDepts.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnViewDepts.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewDepts.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnViewDepts.Location = New System.Drawing.Point(347, 38)
        Me.btnViewDepts.Name = "btnViewDepts"
        Me.btnViewDepts.Size = New System.Drawing.Size(210, 31)
        Me.btnViewDepts.TabIndex = 1
        Me.btnViewDepts.Text = "View Departments"
        Me.btnViewDepts.UseVisualStyleBackColor = False
        '
        'btnViewApplicants
        '
        Me.btnViewApplicants.BackColor = System.Drawing.Color.White
        Me.btnViewApplicants.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewApplicants.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnViewApplicants.Location = New System.Drawing.Point(66, 96)
        Me.btnViewApplicants.Name = "btnViewApplicants"
        Me.btnViewApplicants.Size = New System.Drawing.Size(210, 31)
        Me.btnViewApplicants.TabIndex = 2
        Me.btnViewApplicants.Text = "View Applicants"
        Me.btnViewApplicants.UseVisualStyleBackColor = False
        '
        'btnViewPositions
        '
        Me.btnViewPositions.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnViewPositions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewPositions.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnViewPositions.Location = New System.Drawing.Point(347, 96)
        Me.btnViewPositions.Name = "btnViewPositions"
        Me.btnViewPositions.Size = New System.Drawing.Size(210, 31)
        Me.btnViewPositions.TabIndex = 3
        Me.btnViewPositions.Text = "View Positions"
        Me.btnViewPositions.UseVisualStyleBackColor = False
        '
        'btnViewAppointments
        '
        Me.btnViewAppointments.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnViewAppointments.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewAppointments.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnViewAppointments.Location = New System.Drawing.Point(66, 154)
        Me.btnViewAppointments.Name = "btnViewAppointments"
        Me.btnViewAppointments.Size = New System.Drawing.Size(210, 31)
        Me.btnViewAppointments.TabIndex = 4
        Me.btnViewAppointments.Text = "View Appointments"
        Me.btnViewAppointments.UseVisualStyleBackColor = False
        '
        'btnViewAbsence
        '
        Me.btnViewAbsence.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnViewAbsence.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewAbsence.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnViewAbsence.Location = New System.Drawing.Point(347, 154)
        Me.btnViewAbsence.Name = "btnViewAbsence"
        Me.btnViewAbsence.Size = New System.Drawing.Size(210, 31)
        Me.btnViewAbsence.TabIndex = 5
        Me.btnViewAbsence.Text = "View Absence"
        Me.btnViewAbsence.UseVisualStyleBackColor = False
        '
        'btnViewComplaints
        '
        Me.btnViewComplaints.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.btnViewComplaints.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewComplaints.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnViewComplaints.Location = New System.Drawing.Point(66, 209)
        Me.btnViewComplaints.Name = "btnViewComplaints"
        Me.btnViewComplaints.Size = New System.Drawing.Size(210, 31)
        Me.btnViewComplaints.TabIndex = 6
        Me.btnViewComplaints.Text = "View Complaints"
        Me.btnViewComplaints.UseVisualStyleBackColor = False
        '
        'MenuForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(649, 392)
        Me.ControlBox = False
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnHelp)
        Me.Controls.Add(Me.btnAbout)
        Me.Controls.Add(Me.lblDateTime)
        Me.Controls.Add(Me.lblWelcome)
        Me.Controls.Add(Me.btnSignOut)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "MenuForm"
        Me.Text = "Menu"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnSignOut As Button
    Friend WithEvents lblWelcome As Label
    Friend WithEvents lblDateTime As Label
    Friend WithEvents btnAbout As Button
    Friend WithEvents btnHelp As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnViewAppointments As Button
    Friend WithEvents btnViewPositions As Button
    Friend WithEvents btnViewApplicants As Button
    Friend WithEvents btnViewDepts As Button
    Friend WithEvents btnViewEmployees As Button
    Friend WithEvents btnViewAbsence As Button
    Friend WithEvents btnViewComplaints As Button
End Class
