﻿Public Class MenuForm

    Private Sub btnSignOut_Click(sender As Object, e As EventArgs) Handles btnSignOut.Click
        LoginForm.Show()
        Me.Hide()
        LoginForm.tbPassword.Text = ""
        LoginForm.tbUserName.Text = ""
        LoginForm.Proceed = True

    End Sub

    Private Sub MenuForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDateTime.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        MessageBox.Show("Captain CrackHead Enterprises HRMU (Human Resource Management Utility) V1.0.0", "About:")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnViewDepts.Click
        Me.Hide()
        DepartmentForm.Show()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles btnViewAppointments.Click
        Me.Hide()
        AppointmentForm.Show()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles btnViewApplicants.Click
        Me.Hide()
        ApplicantForm.Show()

    End Sub

    Private Sub btnViewEmployees_Click(sender As Object, e As EventArgs) Handles btnViewEmployees.Click
        Me.Hide()
        EmployeeForm.Show()

    End Sub

    Private Sub btnViewComplaints_Click(sender As Object, e As EventArgs) Handles btnViewComplaints.Click
        Me.Hide()
        ComplaintsForm.Show()

    End Sub

    Private Sub btnViewAbsence_Click(sender As Object, e As EventArgs) Handles btnViewAbsence.Click
        Me.Hide()
        AbsenceForm.Show()

    End Sub

    Private Sub btnViewPositions_Click(sender As Object, e As EventArgs) Handles btnViewPositions.Click
        Me.Hide()
        PositionForm.Show()

    End Sub
End Class