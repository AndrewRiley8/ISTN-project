﻿Public Class DepartmentForm
    Private Sub DepartmentForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()

    End Sub
End Class