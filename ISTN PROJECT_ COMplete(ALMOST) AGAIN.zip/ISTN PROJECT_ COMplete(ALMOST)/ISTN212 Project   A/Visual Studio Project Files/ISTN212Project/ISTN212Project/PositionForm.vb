﻿Public Class PositionForm
    Public Department As String
    Public caller As Integer
    Public Const ApplicantAdd = 0
    Public Const EmployeeUpdate = 1
    Private Sub PositionForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
    End Sub

    Private Sub PositionForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Position' table. You can move, or remove it, as needed.
        FunctionResources.filterPosition(Department)
    End Sub

    Private Sub btnPositionChanges_Click(sender As Object, e As EventArgs) Handles btnPositionChanges.Click
        If cboxNewPosition.Checked Then
            FunctionResources.addPosition(txtPositionName.Text, cmbDepartment.Text, numUDPositionsAvailable.Value)
        Else
            FunctionResources.updateAvailablePosts(txtPositionName.Text, numUDPositionsAvailable.Value)
        End If

    End Sub

    Private Sub cboxNewPosition_CheckedChanged(sender As Object, e As EventArgs) Handles cboxNewPosition.CheckedChanged
        If cboxNewPosition.Checked Then
            btnPositionChanges.Text = "Add"
            txtPositionName.Enabled = True
            cmbDepartment.Enabled = True


        Else
            btnPositionChanges.Text = "Save Changes"
            txtPositionName.Enabled = False
            cmbDepartment.Enabled = False
        End If
    End Sub

    Private Sub btnSelectPosition_Click(sender As Object, e As EventArgs) Handles btnSelectPosition.Click
        Select Case caller
            Case ApplicantAdd
                'data transfer: PROBLEMATIC
                AddNewPersonForm.txtPosition.Text = txtPositionName.Text
            Case EmployeeUpdate
                'data transfer: PROBLEMATIC
                EmployeeForm.txtPosition.Text = txtPositionName.Text
        End Select
        Me.Hide()
    End Sub
End Class