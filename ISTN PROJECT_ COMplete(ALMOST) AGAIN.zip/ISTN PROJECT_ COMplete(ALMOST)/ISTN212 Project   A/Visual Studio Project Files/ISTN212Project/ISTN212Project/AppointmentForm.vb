﻿Public Class AppointmentForm
    'FIELDS AND CONSTANTS
    Public action As Integer
    Public Const view = 0
    Public Const add = 1
    Public Applicant As String = vbNullString

    Public caller As Integer
    Public Const MenuForm = 0
    Public Const Applicants = 1

    'INITIALIZATION
    Private Sub AppointmentForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub AppointmentForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.Ist2dsDataSet.Appointment)
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.Ist2dsDataSet.Appointment)
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.Ist2dsDataSet.Appointment)

    End Sub
    '_________________________________________________________________________________________________________________________________________
    'BUTTON EVENT HANDLERS

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
    End Sub

    Private Sub btnShowGuests_Click(sender As Object, e As EventArgs) Handles btnShowGuests.Click
        Me.Hide()
        ApptGuestForm.AptNum = lblAptNum.Text
        ApptGuestForm.Show()
    End Sub

    Private Sub btnDeleteAppointment_Click(sender As Object, e As EventArgs) Handles btnDeleteAppointment.Click
        FunctionResources.deleteAppointment(lblAptNum.Text)
    End Sub

    Private Sub btnAddRescheduleAppointment_Click(sender As Object, e As EventArgs) Handles btnAddRescheduleAppointment.Click
        If action = add Then
            FunctionResources.addAppointment(DateTimePicker1.Value, numUDStartHr.Value, numUDStartMin.Value, numUDEndHr.Value, numUDEndMin.Value, txtDescription.Text)
            If Applicant <> vbNullString Then
                FunctionResources.setApplicantInterview(Applicant, lblAptNum.Text)
                Applicant = vbNullString
            End If

        Else 'action = view, where rescheduling is allowed
            FunctionResources.rescheduleAppointment(lblAptNum.Text, DateTimePicker1.Value, numUDStartHr.Value, numUDStartMin.Value, numUDEndHr.Value, numUDEndMin.Value, txtDescription.Text)

        End If
    End Sub

    Private Sub BtnFilter_Click(sender As Object, e As EventArgs) Handles BtnFilter.Click
        If rdbToday.Checked Then
            FunctionResources.filterAppointments(Today)
        Else 'rdbCustom is checked
            FunctionResources.filterAppointments(DateTimePickerFilter.Value)
        End If

    End Sub

    Private Sub cboxReschedule_CheckedChanged(sender As Object, e As EventArgs) Handles cboxReschedule.CheckedChanged
        If cboxReschedule.Checked Then
            DateTimePicker1.Enabled = True
            numUDStartHr.Enabled = True
            numUDStartMin.Enabled = True
            numUDEndHr.Enabled = True
            numUDEndMin.Enabled = True
            txtDescription.ReadOnly = False
            btnAddRescheduleAppointment.Visible = True
        Else
            DateTimePicker1.Enabled = False
            numUDStartHr.Enabled = False
            numUDStartMin.Enabled = False
            numUDEndHr.Enabled = False
            numUDEndMin.Enabled = False
            txtDescription.ReadOnly = True
            btnAddRescheduleAppointment.Visible = True

        End If
    End Sub
End Class