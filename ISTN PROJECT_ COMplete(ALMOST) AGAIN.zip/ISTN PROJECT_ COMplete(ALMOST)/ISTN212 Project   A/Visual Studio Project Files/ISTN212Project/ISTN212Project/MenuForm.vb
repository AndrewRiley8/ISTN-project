﻿Public Class MenuForm

    Private Sub MenuForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDateTime.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    'sign out button click
    Private Sub btnSignOut_Click(sender As Object, e As EventArgs) Handles btnSignOut.Click
        LoginForm.Show()
        Me.Hide()
        LoginForm.tbPassword.Text = ""
        LoginForm.tbUserName.Text = ""
        LoginForm.Proceed = True

    End Sub

    'about button click
    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        MessageBox.Show("r/programmerhumor HRMU (Human Resource Management Utility) V1.0.0", "About:")
    End Sub

    'help picture box click'
    Private Sub pboxHelp_Click(sender As Object, e As EventArgs) Handles pboxHelp.Click
        Process.Start("www.youtube.com")
    End Sub

    'personalisation button click'
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Personalised.Show()
        Me.Hide()
    End Sub




    'MENUSTRIP BUTTONS'

    'HIRING SECTION'
    Private Sub AccountingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccountingToolStripMenuItem.Click
        openApplicantsAsView("Accounting")
    End Sub

    Private Sub AdministrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdministrationToolStripMenuItem.Click
        openApplicantsAsView("Administration")
    End Sub

    Private Sub EngineeringToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EngineeringToolStripMenuItem.Click
        openApplicantsAsView("Engineering")
    End Sub

    Private Sub FinanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FinanceToolStripMenuItem.Click
        openApplicantsAsView("Finance")
    End Sub

    Private Sub HumanResourcesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HumanResourcesToolStripMenuItem.Click
        openApplicantsAsView("Human Resources")
    End Sub

    Private Sub ITToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ITToolStripMenuItem.Click
        openApplicantsAsView("IT")
    End Sub

    Private Sub MarketingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MarketingToolStripMenuItem.Click
        openApplicantsAsView("Marketing")
    End Sub

    Private Sub SalesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalesToolStripMenuItem.Click
        openApplicantsAsView("Sales")
    End Sub

    Private Sub AllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AllToolStripMenuItem.Click
        openApplicantsAsView("All")

    End Sub


    'TERMINATION SECTION'
    Private Sub TermEmplToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TermEmplToolStripMenuItem.Click
        Me.Hide()
        openTerminationsAsAdd()

    End Sub

    Private Sub ViewTerminationHistoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewTerminationHistoryToolStripMenuItem.Click
        Me.Hide()
        openTerminationsAsView()

    End Sub


    'GENERAL SECTION'
    'COMPLAINTS'
    Private Sub ViewAllComplaintsToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ViewAllComplaintsToolStripMenuItem1.Click
        Me.Hide()
        openComplaintsAsView()
    End Sub

    Private Sub AddNewComplaintToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AddNewComplaintToolStripMenuItem1.Click
        Me.Hide()
        openComplaintsAsAdd()
    End Sub

    'ABSENCES'
    Private Sub ViewAllAbsencesToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ViewAllAbsencesToolStripMenuItem2.Click
        Me.Hide()
        openAbsencesAsView()
    End Sub

    Private Sub AddNewAbsenceToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles AddNewAbsenceToolStripMenuItem2.Click
        Me.Hide()
        openAbsencesAsAdd()
    End Sub


    'EDIT GENERAL DETAILS'

    Private Sub EditGenEmployeeDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditGenEmployeeDetailsToolStripMenuItem.Click
        Me.Hide()
        openEmployeesAsEdit()
    End Sub

    'APPOINTMENT SECTION'

    Private Sub ViewAllAppointmentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewAllAppointmentsToolStripMenuItem.Click
        Me.Hide()
        openAppointmentsAsView()
    End Sub

    Private Sub AddNewAppointmentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddNewAppointmentToolStripMenuItem.Click
        Me.Hide()
        openAppointmentsAsAdd(AppointmentForm.MenuForm)
    End Sub

    Private Sub AnalyticsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AnalyticsToolStripMenuItem.Click
        Me.Hide()

    End Sub

    'MISC SECTION'
    'OPENING FORM FunctionResources'

    'APPLICANTFORM
    Private Sub openApplicantsAsView(DeptName As String)
        Me.Hide()
        ApplicantForm.Dept = DeptName
        'let the dgview on the applicant form hold:  select * from applicant where position_ID IN (select * from position where department = @Dept) 
        FunctionResources.filterApplicants(ApplicantForm.Ist2dsDataSet.Applicant, ApplicantForm.ApplicantTableAdapter, DeptName, False)
        ApplicantForm.Show()
    End Sub

    'EMPLOYEETERMINATEFORM
    Public Sub openTerminationsAsView()
        EmployeeTerminateForm.GroupBox2.Enabled = False
        EmployeeTerminateForm.Show()
    End Sub
    Public Sub openTerminationsAsAdd()
        EmployeeTerminateForm.GroupBox2.Enabled = True
        EmployeeTerminateForm.Show()
    End Sub

    'ABSENCEFORM
    Public Sub openAbsencesAsView()
        AbsenceForm.BtnAddAbsence.Visible = False
        AbsenceForm.btnChoose.Enabled = False
        AbsenceForm.txtEmployeeID.ReadOnly = True
        AbsenceForm.DateTimePickerStart.Enabled = False
        AbsenceForm.DateTimePickerStart.Enabled = False
        AbsenceForm.cmbType.Enabled = False
        AbsenceForm.Show()
    End Sub
    Public Sub openAbsencesAsAdd()
        AbsenceForm.BtnAddAbsence.Visible = True
        AbsenceForm.btnChoose.Enabled = True
        AbsenceForm.txtEmployeeID.ReadOnly = False
        AbsenceForm.DateTimePickerStart.Enabled = True
        AbsenceForm.DateTimePickerStart.Enabled = True
        AbsenceForm.cmbType.Enabled = True
        AbsenceForm.Show()
    End Sub

    'COMPLAINTSFORM
    Public Sub openComplaintsAsView()
        ComplaintsForm.DateTimePickerIssued.Enabled = False
        ComplaintsForm.txtEmployeeID.ReadOnly = True
        ComplaintsForm.txtDescription.ReadOnly = True
        ComplaintsForm.btnChooseTarget.Enabled = False
        ComplaintsForm.btnAddressComplaint.Visible = True
        ComplaintsForm.btnAddComplaint.Visible = False
        ComplaintsForm.Show()
    End Sub
    Public Sub openComplaintsAsAdd()
        ComplaintsForm.DateTimePickerIssued.Enabled = True
        ComplaintsForm.txtEmployeeID.ReadOnly = False
        ComplaintsForm.txtDescription.ReadOnly = False
        ComplaintsForm.btnChooseTarget.Enabled = True
        ComplaintsForm.btnAddressComplaint.Visible = False
        ComplaintsForm.btnAddComplaint.Visible = True
        ComplaintsForm.Show()
    End Sub

    'APPOINTMENTFORM
    Public Sub openAppointmentsAsView()
        AppointmentForm.action = AppointmentForm.view


        AppointmentForm.DateTimePicker1.Enabled = False
        AppointmentForm.numUDStartHr.Enabled = False
        AppointmentForm.numUDStartMin.Enabled = False
        AppointmentForm.numUDEndHr.Enabled = False
        AppointmentForm.numUDEndMin.Enabled = False
        AppointmentForm.txtDescription.ReadOnly = True
        AppointmentForm.btnAddRescheduleAppointment.Visible = False
        AppointmentForm.btnAddRescheduleAppointment.Text = "Reschedule appointment"
        AppointmentForm.cboxReschedule.Visible = True

        AppointmentForm.Show()
    End Sub
    Public Sub openAppointmentsAsAdd(callerform As Integer)
        AppointmentForm.caller = callerform
        AppointmentForm.action = AppointmentForm.add

        AppointmentForm.DateTimePicker1.Enabled = True
        AppointmentForm.numUDStartHr.Enabled = True
        AppointmentForm.numUDStartMin.Enabled = True
        AppointmentForm.numUDEndHr.Enabled = True
        AppointmentForm.numUDEndMin.Enabled = True
        AppointmentForm.txtDescription.ReadOnly = False
        AppointmentForm.btnAddRescheduleAppointment.Visible = True
        AppointmentForm.btnAddRescheduleAppointment.Text = "Add Appointment"
        AppointmentForm.cboxReschedule.Visible = True

        Select Case AppointmentForm.caller
            Case AppointmentForm.Applicants
                AppointmentForm.btnBack.Text = "Back to Applicants"
                AppointmentForm.cboxReschedule.Enabled = False

            Case AppointmentForm.MenuForm
                AppointmentForm.btnBack.Text = "Back to Menu"
                AppointmentForm.cboxReschedule.Enabled = True


        End Select


        AppointmentForm.Show()
    End Sub

    'EMPLOYEEFORM
    Public Sub openEmployeesAsView()
        EmployeeForm.btnUpdateEmployee.Visible = False
        EmployeeForm.GroupBox3.Enabled = False
        EmployeeForm.GroupBox4.Enabled = False
        EmployeeForm.GroupBox5.Enabled = False

        EmployeeForm.DataGridView1.Enabled = True
        EmployeeForm.Show()
    End Sub
    Public Sub openEmployeesAsEdit()
        EmployeeForm.btnUpdateEmployee.Visible = True
        EmployeeForm.GroupBox3.Enabled = True
        EmployeeForm.GroupBox4.Enabled = True
        EmployeeForm.GroupBox5.Enabled = True
        EmployeeForm.DataGridView1.Enabled = False
        EmployeeForm.Show()
    End Sub

    'ADDNEWPERSONFORM
    Public Sub openNewPersonFrom(callerform As Integer)
        AddNewPersonForm.Type = callerform
        Dim callString As String
        Select Case AddNewPersonForm.Type
            Case AddNewPersonForm.Employee
                callString = "Employee"
                AddNewPersonForm.GroupBox3.Enabled = False
                AddNewPersonForm.GroupBox4.Enabled = True
            Case Else
                callString = "Applicant"
                AddNewPersonForm.GroupBox3.Enabled = True
                AddNewPersonForm.GroupBox4.Enabled = False
        End Select

        AddNewPersonForm.btnFinAdd.Text = "Add This " & callString

        AddNewPersonForm.Text = "create New " & callString

        AddNewPersonForm.Show()
    End Sub

    'POSITIONFORM
    Public Sub openPositionsAsAdd(dept As String)
        PositionForm.Department = dept
        PositionForm.btnSelectPosition.Enabled = False
        PositionForm.GroupBox3.Enabled = True
        PositionForm.Show()
    End Sub
    Public Sub openPositionAsView(callerForm As Integer, dept As String)
        'set department
        PositionForm.Department = dept
        'set Type
        PositionForm.caller = callerForm
        'prepare for selection
        PositionForm.btnSelectPosition.Enabled = True
        PositionForm.GroupBox3.Enabled = False
        PositionForm.Show()
    End Sub

    'EMPLOYEESSELECTIONFORM
    Public Sub openEmployeeSelectorFrom(callerForm As Integer)
        EmployeeSelectionForm.caller = callerForm
        Dim callString As String
        Select Case EmployeeSelectionForm.caller
            Case EmployeeSelectionForm.Complaints
                callString = "Complaints"

            Case EmployeeSelectionForm.Absences
                callString = "Absences"

            Case Else
                callString = "Terminations"
        End Select

        EmployeeSelectionForm.btnBack.Text = "Back to " & callString
        EmployeeSelectionForm.Text = "Select Employee for " & callString

        EmployeeSelectionForm.Show()
    End Sub


End Class