﻿Imports System.Net.Mail

Public Class FunctionResources



    '_________________________________________________________________________________________________________________
    'ADDING
    Public Shared Sub addAbsence(employeeID As String, absStart As String, absEnd As String, type As String)
        'validate inputs. if valid:
        If Not (hasClashingAbsence(employeeID, absStart, absEnd)) Then
            AbsenceForm.AbsenceTableAdapter.InsertAbsence(AbsenceForm.AbsenceTableAdapter.GetNextAbsenceNum, employeeID, absStart, absEnd, type)
        Else
            MsgBox("This employee already has an absence which clashes with this one")
        End If

    End Sub

    Public Shared Sub addApplicant(id As String, fnam As String, lnam As String, gender As String, race As String, disability As Boolean, position As String, phoneNum As String, email As String, street As String, city As String, postcode As String)
        Dim flagged As Boolean = False

        If Not emailValid(email) Then
            MsgBox("invalid email address")

            flagged = True
        End If

        If Not IDValid(id) Then
            MsgBox("invalid ID Number")
            flagged = True
        End If

        If Not PhoneNumValid(phoneNum) Then
            MsgBox("invalid Phone Number")
            flagged = True
        End If

        If fnam = vbNullString Then
            MsgBox("no first name given")

            flagged = True
        End If

        If lnam = vbNullString Then
            MsgBox("no last name given")
            flagged = True
        End If

        If position = vbNullString Then
            MsgBox("no position name chosen")
            flagged = True
        End If

        If gender = vbNullString Then
            MsgBox("no gender chosen (This is optional however)")
        End If

        If race = vbNullString Then
            MsgBox("no race chosen (This is optional however)")
        End If

        If city = vbNullString Then
            MsgBox("no city given")
            flagged = True
        End If

        If street = vbNullString Then
            MsgBox("no street address given")
            flagged = True
        End If

        If postcode = vbNullString Then
            MsgBox("no postal code given")
            flagged = True
        End If

        If Not flagged Then
            ApplicantForm.ApplicantTableAdapter.InsertApplicant(id, fnam, lnam, phoneNum, email, street, city, postcode, position, race, gender, 0)
            MsgBox("Applicant Successfully Added")
            filterApplicants(ApplicantForm.Ist2dsDataSet.Applicant, ApplicantForm.ApplicantTableAdapter, ApplicantForm.Dept, False)
        End If


    End Sub

    Public Shared Sub addAppointment(aptDate As String, startHr As Integer, startMin As Integer, endHr As Integer, endMin As Integer, desc As String)
        Dim flagged As Boolean = False

        If String.IsNullOrEmpty(aptDate) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(startHr.ToString) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(startMin.ToString) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(endHr.ToString) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(endMin.ToString) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(desc) Then
            flagged = True
        End If

        If endHr < startHr Then
            flagged = True
        End If

        If (endHr = startHr) And (endMin < startMin) Then
            flagged = True
        End If


        If Not flagged Then
            AppointmentForm.AppointmentTableAdapter.InsertAppointment(AppointmentForm.AppointmentTableAdapter.GetNextApptNum, aptDate, startHr, startMin, endHr, endMin, desc)


        Else
            MsgBox("some Data is incomplete or may contain errors")
        End If


    End Sub

    Public Shared Sub addAppt_Guest(aptNum As Integer, empID As String)
        Dim flagged As Boolean = False

        If String.IsNullOrEmpty(aptNum.ToString) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(empID) Then
            flagged = True
        End If


        If Not flagged Then
            ApptGuestForm.Appt_guestTableAdapter.InsertApptGuest(ApptGuestForm.Appt_guestTableAdapter.GetNextApptGNum, aptNum, empID)
        Else
            MsgBox("some Data is incomplete or may contain errors")
        End If


        'do sql adding: it is already ensured that the employee has no other appointment during this time
    End Sub

    Public Shared Sub addComplaint(compdate As Date, target As String, untargetted As Boolean, desc As String)
        Try
            ComplaintsForm.ComplaintTableAdapter.InsertComplaint(ComplaintsForm.ComplaintTableAdapter.GetNextComplaintNum, target, desc, compdate, False)
        Catch ex As Exception
            MsgBox("some Data is incomplete or may contain errors")
        End Try
    End Sub

    Public Shared Sub addEmployee(id As String, fnam As String, lnam As String, gender As String, race As String, disability As Boolean, dateHired As String, monthlySal As Decimal, bankNam As String, bankBranchCode As String, bankacctnum As String, bankBranchNam As String, taxNo As String, position As String, phoneNum As String, email As String, street As String, city As String, postcode As String)
        Dim flagged As Boolean = False

        If Not emailValid(email) Then

            flagged = True
        End If

        If Not IDValid(id) Then

            flagged = True
        End If

        If Not PhoneNumValid(phoneNum) Then

            flagged = True
        End If

        If fnam = vbNullString Then
            flagged = True
        End If

        If lnam = vbNullString Then
            flagged = True
        End If

        If monthlySal <= 0 Or monthlySal > 214748 Then
            flagged = True
        End If

        If bankNam = vbNullString Then
            flagged = True
        End If

        If bankacctnum = vbNullString Then
            flagged = True
        End If

        If bankBranchCode = vbNullString Then
            flagged = True
        End If

        If bankBranchNam = vbNullString Then
            flagged = True
        End If

        If taxNo = vbNullString Then

            flagged = True
        End If

        If position = vbNullString Then
            flagged = True
        End If

        If city = vbNullString Then
            flagged = True
        End If

        If street = vbNullString Then
            flagged = True
        End If

        If postcode = vbNullString Then
            flagged = True
        End If


        If Not flagged Then
            If (PositionForm.PositionTableAdapter.GetAvailablePosts(position) = 0) Then
                MsgBox("no position available for this employee")

            Else
                EmployeeForm.EmployeeTableAdapter.InsertEmployee(id, fnam, lnam, position, phoneNum, email, street, city, postcode, dateHired, "active", race, gender, disability, monthlySal, bankNam, bankacctnum, bankBranchNam, bankBranchCode, taxNo)
                ApplicantForm.ApplicantTableAdapter.DeleteApplicant(id)
            End If

        Else
            MsgBox("some Data is incomplete or may contain errors")
        End If

    End Sub

    Public Shared Sub addPosition(positionName As String, dept As String, availablePosts As Integer)

        Dim flag As Boolean = False

        If positionName = vbNullString Then
            flag = True
        End If
        If dept = vbNullString Then
            flag = True
        End If
        If availablePosts = vbNullString Then
            flag = True
        End If

        If flag = True Then
            MsgBox("Some data is incomplete or may contain errors")
        Else
            PositionForm.PositionTableAdapter.InsertPosition(positionName, availablePosts, dept)
        End If



    End Sub


    '_________________________________________________________________________________________________________________
    'UPDATING
    Public Shared Sub addressComplaint(dateIssued As Date, isUntargetted As Boolean, target As String, desc As String)
        Dim flagged As Boolean = False

        If String.IsNullOrEmpty(dateIssued) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(isUntargetted) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(target) And Not isUntargetted Then
            flagged = True
        End If

        If String.IsNullOrEmpty(desc) Then
            flagged = True
        End If

        If isUntargetted Then
            target = "NULL"
        End If

        If flagged = True Then
            MsgBox("Some data is incomplete or may contain errors")
        Else
            ComplaintsForm.ComplaintTableAdapter.AddressComplaint(True, dateIssued, desc, target)
        End If




    End Sub

    Public Shared Sub rescheduleAppointment(aptNum As Short, aptDate As Date, startHr As Integer, startMin As Integer, endHr As Integer, endMin As Integer, desc As String)
        Dim flagged As Boolean = False

        If String.IsNullOrEmpty(aptDate) Then
            flagged = True
        End If
        If String.IsNullOrEmpty(startHr) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(startMin) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(endHr) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(endMin) Then
            flagged = True
        End If

        If String.IsNullOrEmpty(desc) Then
            flagged = True
        End If

        If endHr < startHr Then
            flagged = True
        End If

        If (endHr = startHr) And (endMin < startMin) Then
            flagged = True
        End If

        If flagged = True Then
            MsgBox("Some data is incomplete or may contain errors")
        Else
            AppointmentForm.AppointmentTableAdapter.UpdateAppointment(aptDate, startHr, startMin, endHr, endMin, desc, aptNum)
        End If


    End Sub

    Public Shared Sub setApplicantInterview(appID As String, apptNum As Integer)
        'open the appointments form in add mode. 
        'after calling addAppointment(), set appointment in Applicant to the newly made appointment 
    End Sub



    Public Shared Sub updateEmployeeGen(caller As ist2dsDataSetTableAdapters.EmployeeTableAdapter, id As String, fnam As String, lnam As String, disability As Boolean, phoneNum As String, email As String, street As String, city As String, postcode As String)

        Dim flagged As Boolean = False

        If Not emailValid(email) Then
            'message
            flagged = True
        End If

        If Not IDValid(id) Then
            'message
            flagged = True
        End If

        If Not PhoneNumValid(phoneNum) Then
            'message
            flagged = True
        End If
        If fnam = vbNullString Then
            'message
            flagged = True
        End If

        If lnam = vbNullString Then
            'message
            flagged = True
        End If

        If city = vbNullString Then
            'message
            flagged = True
        End If

        If street = vbNullString Then
            'message
            flagged = True
        End If

        If postcode = vbNullString Then
            'message
            flagged = True
        End If

        If Not flagged Then
            caller.UpdateEmployeeGenDetails(fnam, lnam, phoneNum, email, street, city, postcode, disability, id)
        Else
            MsgBox("some Data is incomplete or may contain errors")
        End If
    End Sub

    Public Shared Sub updateEmployeeFin(caller As ist2dsDataSetTableAdapters.EmployeeTableAdapter, id As String, monthlySal As Integer, bankNam As String, bankBranchCode As String, bankacctnum As String, bankBranchNam As String, taxNo As String, position As String)

        Dim flagged As Boolean = False

        If String.IsNullOrEmpty(monthlySal.ToString) Then
            'message
            flagged = True
        End If

        If Not IDValid(id) Then
            'message
            flagged = True
        End If

        If bankNam = vbNullString Then
            'message
            flagged = True
        End If
        If bankBranchCode = vbNullString Then
            'message
            flagged = True
        End If

        If bankacctnum = vbNullString Then
            'message
            flagged = True
        End If

        If position = vbNullString Then
            'message
            flagged = True
        End If

        If bankBranchNam = vbNullString Then
            'message
            flagged = True
        End If

        If taxNo = vbNullString Then
            'message
            flagged = True
        End If


        If Not flagged Then
            caller.UpdateEmployeeFinDetails(monthlySal, bankNam, bankBranchCode, bankacctnum, bankBranchNam, taxNo, position, id)
        Else
            MsgBox("some Data is incomplete or may contain errors")
        End If
    End Sub

    Public Shared Sub terminateEmployee(id As String, type As String, termDate As Date)

        Dim flagged As Boolean = False

        If Not IDValid(id) Then
            flagged = True
        End If


        If String.IsNullOrEmpty(type.ToString) Then
            'message
            flagged = True
        End If

        If String.IsNullOrEmpty(termDate.ToString) Then
            'message
            flagged = True
        End If

        If Not flagged Then
            Try
                EmployeeTerminateForm.EmployeeTableAdapter.TerminateEmployee(id, termDate, type)
            Catch ex As Exception
                MsgBox("Something went wrong")
            End Try
        Else
            MsgBox("Some data is incomplete or may contain errors")
        End If


    End Sub

    Public Shared Sub updateAvailablePosts(positionName As String, newNum As Integer)
        Dim flagged As Boolean = False

        If String.IsNullOrEmpty(positionName.ToString) Then
            'message
            flagged = True
        End If

        If String.IsNullOrEmpty(newNum.ToString) Then
            'message
            flagged = True
        End If
        If Not flagged Then
            PositionForm.PositionTableAdapter.UpdateAvailablePosts(newNum, positionName)
        Else
            MsgBox("Some data is incomplete or may contain errors")
        End If

    End Sub

    '_________________________________________________________________________________________________________________
    'DELETING

    Public Shared Sub clearTerminationHistory()
        EmployeeForm.EmployeeTableAdapter.ClearTerminationHistory()
    End Sub

    Public Shared Sub deleteAppointment(aptNUm As Short)

        If String.IsNullOrEmpty(aptNUm.ToString) Then
            MsgBox("Some data is incomplete or may contain errors")
        Else
            AppointmentForm.AppointmentTableAdapter.DeleteAppointment(aptNUm)
        End If
    End Sub

    Public Shared Sub removeApptGuest(aptNum As Integer, empID As String)

        If String.IsNullOrEmpty(aptNum.ToString) Or String.IsNullOrEmpty(empID) Then
            MsgBox("some data is incomplete or contains errors")
        Else
            ApptGuestForm.Appt_guestTableAdapter.DeleteApptGuest(aptNum, empID)
        End If

    End Sub

    Public Shared Sub cancelLeave(EmpID As String, StartDate As Date)

        If String.IsNullOrEmpty(StartDate.ToString) Or String.IsNullOrEmpty(EmpID) Then
            MsgBox("Some data is incomplete or may contain errors")
        Else
            If StartDate.CompareTo(Today) <= 0 Then 'cant deleted leave once it has already started
                MsgBox("it is too late cancel this leave request")
            Else
                AbsenceForm.AbsenceTableAdapter.CancelLeave(EmpID, StartDate)
            End If

        End If

    End Sub

    Public Shared Sub deleteApplicant(appID As String)

        If String.IsNullOrEmpty(appID.ToString) Then
            MsgBox("Some data is incomplete or may contain errors")
        Else
            ApplicantForm.ApplicantTableAdapter.DeleteApplicant(appID)
            ApplicantForm.ApplicantTableAdapter.FilterByDepartment_app(ApplicantForm.Ist2dsDataSet.Applicant, ApplicantForm.Dept)
        End If

    End Sub
    'no function needed directly to delete complaint
    'no function needed to delete position

    '__________________________________________________________________________________________________________________
    'SEARCH AND FILTER
    Public Shared Sub searchComplaints(callerTable As ist2dsDataSet.ComplaintDataTable, callerAdapter As ist2dsDataSetTableAdapters.ComplaintTableAdapter, allDays As Boolean, complaintDate As Date, untargetted As Boolean, target As String)
        If Not (IDValid(target) And complaintDate < Today) Then
            MsgBox("invalid inputs")
        Else
            If allDays And untargetted Then
                callerAdapter.SelectAllComplaints(callerTable)
            ElseIf allDays Then
                callerAdapter.SearchEmployeeAllDays(callerTable, target)
            ElseIf untargetted Then
                callerAdapter.SearchDateAllEmployees(callerTable, complaintDate)
            Else
                callerAdapter.SearchDateAndEmployee(callerTable, complaintDate, target)
            End If
        End If
    End Sub




    Public Shared Sub searchEmployee(callerTable As ist2dsDataSet.EmployeeDataTable, callerAdapter As ist2dsDataSetTableAdapters.EmployeeTableAdapter, id As String, fnam As String, lnam As String)
        callerAdapter.SearchEmployee(callerTable, id, fnam, lnam)
    End Sub




    Public Shared Sub filterEmployee(callerTable As ist2dsDataSet.EmployeeDataTable, callerAdapter As ist2dsDataSetTableAdapters.EmployeeTableAdapter, dept As String, protectedOnly As Boolean)
        If protectedOnly Then
            callerAdapter.FilterByDept_Protected(callerTable, dept)
        Else
            callerAdapter.FilterByDept(callerTable, dept)
        End If

    End Sub

    Public Shared Sub searchApplicant(callerTable As ist2dsDataSet.ApplicantDataTable, callerAdapter As ist2dsDataSetTableAdapters.ApplicantTableAdapter, id As String, fnam As String, lnam As String, dept As String)
        If dept = "All" Then
            callerAdapter.SearchApplicant(callerTable, id, fnam, lnam)
        Else
            callerAdapter.SearchApplicantByDept(callerTable, id, fnam, lnam, dept)
        End If

    End Sub

    Public Shared Sub filterApplicants(callerTable As ist2dsDataSet.ApplicantDataTable, callerAdapter As ist2dsDataSetTableAdapters.ApplicantTableAdapter, dept As String, protectedOnly As Boolean)
        If dept = "All" Then
            callerAdapter.Fill(callerTable)
        Else
            If protectedOnly Then
                callerAdapter.FilterByDepartment_protected_app(callerTable, dept)
            Else
                callerAdapter.FilterByDepartment_app(callerTable, dept)
            End If
        End If
    End Sub

    Public Shared Sub filterPosition(dept As String)
        If dept = "All" Then
            PositionForm.PositionTableAdapter.SelectAllPositions(PositionForm.Ist2dsDataSet.Position)

        Else
            PositionForm.PositionTableAdapter.SelectAllPositionsFromDept(PositionForm.Ist2dsDataSet.Position, dept)

        End If
    End Sub

    Public Shared Sub filterAbsences(allDays As Boolean, absDate As Date, allEmp As Boolean, empID As String)
        If allDays And allEmp Then
            AbsenceForm.AbsenceTableAdapter.FilterAbsencesByDateBeganAndEmployee(AbsenceForm.Ist2dsDataSet.Absence, empID, absDate)
        ElseIf allDays Then
            AbsenceForm.AbsenceTableAdapter.FilterAbsencesByEmployee(AbsenceForm.Ist2dsDataSet.Absence, empID)

        ElseIf allEmp Then
            AbsenceForm.AbsenceTableAdapter.FilterAbsencesByDateBegan(AbsenceForm.Ist2dsDataSet.Absence, absDate)

        Else
            AbsenceForm.AbsenceTableAdapter.Fill(AbsenceForm.Ist2dsDataSet.Absence)
        End If
    End Sub

    Public Shared Sub filterAppointments(aptDate As Date)
        AppointmentForm.AppointmentTableAdapter.FilterAppointmentByDate(AppointmentForm.Ist2dsDataSet.Appointment, aptDate)
    End Sub




    Public Shared Sub ShowAllAvailableEmployees(Aptdate As Date, SHr As Integer, SMn As Integer, EHr As Integer, EMn As Integer)
        ApptGuestForm.EmployeeTableAdapter.SelectAllUninvited(ApptGuestForm.Ist2dsDataSet.Employee, Aptdate, SHr, SMn, EHr, EMn)
    End Sub

    Public Shared Sub ShowAllInvitedEmployees(aptNum As String)
        ApptGuestForm.EmployeeTableAdapter.SelectAllInvited(ApptGuestForm.Ist2dsDataSet.Employee, aptNum)
    End Sub

    '__________________________________________________________________________________________________________________
    'OTHER FunctionResources AND SUBS
    Public Shared Function emailValid(email As String)
        Dim valid As Boolean = True

        Dim emailaddress As String = Strings.Trim(email)

        Try
            Dim a As New System.Net.Mail.MailAddress(emailaddress)
        Catch
            valid = False
        End Try
        Return valid

    End Function

    Public Shared Function IDValid(ID As String)

        Dim valid As Boolean = True

        Dim IDstring As String = Strings.Trim(ID)

        If (IDstring.Length <> 13) Then
            valid = False

        End If

        If (IDstring.Any(Function(c) Not (Char.IsLetterOrDigit(c) OrElse Char.IsWhiteSpace(c))) = True) Then
            valid = False
        End If

        Dim rgx As New System.Text.RegularExpressions.Regex("^[0-9 ]+$")

        If Not (rgx.IsMatch(IDstring)) Then
            valid = False
        End If
        Return valid
    End Function

    Public Shared Function hasClashingAbsence(employeeID As String, absStart As String, absEnd As String)
        Return AbsenceForm.AbsenceTableAdapter.FindClashingAbsences(employeeID, absStart, absEnd) > 0
    End Function

    Public Shared Function PhoneNumValid(phoneNum As String)
        Dim valid As Boolean = True

        Dim phoneNumString As String = Strings.Trim(phoneNum)

        If (phoneNumString.Length <> 10) Then
            valid = False
        End If

        If (phoneNumString.Any(Function(c) Not (Char.IsLetterOrDigit(c) OrElse Char.IsWhiteSpace(c))) = True) Then
            valid = False
        End If

        Dim rgx As New System.Text.RegularExpressions.Regex("^[0-9 ]+$")

        If Not (rgx.IsMatch(phoneNumString)) Then
            valid = False
        End If
        Return valid
    End Function



    Private Shared Sub sendEmail(subjectline As String, emailtext As String, toaddress As String, fromaddress As String, password As String)
        Try
            Dim Smtp_Server As New SmtpClient
            Dim e_mail As New MailMessage()
            Smtp_Server.UseDefaultCredentials = False
            Smtp_Server.Credentials = New Net.NetworkCredential(fromaddress, password)
            Smtp_Server.Port = 587
            Smtp_Server.EnableSsl = True
            Smtp_Server.Host = "smtp.gmail.com"

            e_mail = New MailMessage()
            e_mail.From = New MailAddress(fromaddress)
            e_mail.To.Add(toaddress)
            e_mail.Subject = subjectline
            e_mail.IsBodyHtml = False
            e_mail.Body = emailtext
            Smtp_Server.Send(e_mail)
            MsgBox("Mail Sent")

        Catch error_t As Exception
            MsgBox(error_t.ToString)
        End Try
    End Sub

    Public Shared Sub sendEmailtoMany(toAddresses As ArrayList)
        'for loop; call send Email for each address in toAddresses 
    End Sub

End Class
