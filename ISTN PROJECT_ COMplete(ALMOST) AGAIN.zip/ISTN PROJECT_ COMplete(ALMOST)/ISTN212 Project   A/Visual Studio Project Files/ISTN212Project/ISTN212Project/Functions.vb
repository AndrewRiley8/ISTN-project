﻿Public Class Functions



    '_________________________________________________________________________________________________________________
    'UPDATING


    Public Shared Sub setApplicantInterview(appID As String, apptNum As Integer)
        'open the appointments form in add mode. 
        'after calling addAppointment(), set appointment in Applicant to the newly made appointment 
    End Sub
    '_________________________________________________________________________________________________________________
    'DELETING


End Class
