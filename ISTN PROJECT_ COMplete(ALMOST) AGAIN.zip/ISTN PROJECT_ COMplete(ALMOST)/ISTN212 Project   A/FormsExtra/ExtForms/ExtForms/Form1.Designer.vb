﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTerminaton
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvTerm = New System.Windows.Forms.DataGridView()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.gBoxTerm = New System.Windows.Forms.GroupBox()
        Me.btnClear = New System.Windows.Forms.Button()
        CType(Me.dgvTerm, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gBoxTerm.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvTerm
        '
        Me.dgvTerm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvTerm.Location = New System.Drawing.Point(3, 31)
        Me.dgvTerm.Name = "dgvTerm"
        Me.dgvTerm.Size = New System.Drawing.Size(643, 188)
        Me.dgvTerm.TabIndex = 0
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnBack.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnBack.Location = New System.Drawing.Point(19, 345)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(104, 31)
        Me.btnBack.TabIndex = 7
        Me.btnBack.Text = "Back To Menu"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'gBoxTerm
        '
        Me.gBoxTerm.BackColor = System.Drawing.Color.Transparent
        Me.gBoxTerm.Controls.Add(Me.btnClear)
        Me.gBoxTerm.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.gBoxTerm.Location = New System.Drawing.Point(3, 238)
        Me.gBoxTerm.Name = "gBoxTerm"
        Me.gBoxTerm.Size = New System.Drawing.Size(178, 74)
        Me.gBoxTerm.TabIndex = 8
        Me.gBoxTerm.TabStop = False
        Me.gBoxTerm.Text = "Actions"
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnClear.Location = New System.Drawing.Point(16, 24)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(104, 31)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear All Guests"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'frmTerminaton
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ExtForms.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(654, 388)
        Me.ControlBox = False
        Me.Controls.Add(Me.gBoxTerm)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.dgvTerm)
        Me.Name = "frmTerminaton"
        Me.Text = "Terminations"
        CType(Me.dgvTerm, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gBoxTerm.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dgvTerm As DataGridView
    Friend WithEvents btnBack As Button
    Friend WithEvents gBoxTerm As GroupBox
    Friend WithEvents btnClear As Button
End Class
