﻿Public Class ApptGuestForm
    Private Sub ApptGuestForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Employee' table. You can move, or remove it, as needed.
        'Me.EmployeeTableAdapter.Fill(Me.Ist2dsDataSet.Employee)

    End Sub

    'RADIO BUTTONS
    Private Sub rdbAddGuests_CheckedChanged(sender As Object, e As EventArgs) Handles rdbAddGuests.CheckedChanged
        btnAddRemove.Text = "Add"
        'select all from employees where not

    End Sub

    Private Sub rdbRemoveGuests_CheckedChanged(sender As Object, e As EventArgs) Handles rdbRemoveGuests.CheckedChanged
        btnAddRemove.Text = "Remove"
        'select all from employees where employeeID in (select employeeID from appt_guest where appoinmentNumber =@apptNum)
    End Sub

    Private Sub Label7_MouseHover(sender As Object, e As EventArgs) Handles Label7.MouseHover

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        AppointmentForm.Show()
    End Sub
End Class