﻿Public Class FunctionResources
    Protected Function IDValid(ID As String)
        Return True
    End Function

    Protected Function PhoneNumValid(phoneNum As String)
        Return True
    End Function
    Protected Function emailValid(email As String)
        Return True
    End Function

    'CHECK IF AN EMPLOYEE WAS ABSENT ON A DAY RANGE SPECIFIED
    Protected Function hasClashingAbsence(employeeID As String, absStart As String, absEnd As String)
        If "sql number of absences coinciding with this range for the employee > 0 " Then
            Return False
        End If

        Return True

    End Function

    'ADDING

    Protected Sub addPosition()

    End Sub


    'VALIDATE AN ABSENCE AND ADD IF VALID
    Protected Sub addAbsence(employeeID As String, absStart As String, absEnd As String)
        If Not (hasClashingAbsence(employeeID, absStart, absEnd)) Then
            'do sql adding
        Else

        End If

    End Sub

    'VALIDATE AN APPT_GUEST AND ADD IF VALID
    Protected Sub addAppt_Guest(employeeID As String, aptDate As String, startHr As Integer, startMin As Integer, endHr As Integer, endMin As Integer)
        'do sql adding: it is already ensured that the employee has no other appointment during this time
    End Sub

    'VALIDATE AN APPOINTMENT AND ADD IF VALID
    Protected Sub addAppointment()
        'do sql adding
    End Sub

    'VALIDATE A COMPLAINT AND ADD IF VALID
    Protected Sub addComplaint()
        'do sql adding
    End Sub


    'VALIDATE AN EMPLOYEE AND ADD IF VALID
    Protected Sub addEmployee(id As String, fnam As String, lnam As String, gender As String, race As String, disability As Boolean, dateHired As String, monthlySal As Integer, bankNam As String, bankBranchCode As String, bankacctnum As String, bankBranchNam As String, taxNo As String, position As String, phoneNum As String, email As String, street As String, city As String, postcode As String)
        Dim flagged As Boolean = False

        If emailValid(email) Then
            'message
            flagged = True
        End If

        If IDValid(id) Then
            'message
            flagged = True
        End If

        If PhoneNumValid(phoneNum) Then
            'message
            flagged = True
        End If

        If fnam = vbNullString Then
            'message
            flagged = True
        End If

        If lnam = vbNullString Then
            'message
            flagged = True
        End If

        If monthlySal = 0 Then
            'message
            flagged = True
        End If

        If bankNam = vbNullString Then
            'message
            flagged = True
        End If

        If bankacctnum = vbNullString Then
            'message
            flagged = True
        End If

        If bankBranchCode = vbNullString Then
            'message
            flagged = True
        End If

        If bankBranchNam = vbNullString Then
            'message
            flagged = True
        End If

        If taxNo = vbNullString Then
            'message
            flagged = True
        End If

        If position = vbNullString Then
            'message
            flagged = True
        End If

        If city = vbNullString Then
            'message
            flagged = True
        End If

        If street = vbNullString Then
            'message
            flagged = True
        End If

        If postcode = vbNullString Then
            'message
            flagged = True
        End If




        If Not flagged Then
            'do sql
        End If

    End Sub


    'VALIDATE AN APPLICANT AND ADD IF VALID
    Protected Sub addapplicant(id As String, fnam As String, lnam As String, gender As String, race As String, disability As Boolean, position As String, phoneNum As String, email As String, street As String, city As String, postcode As String)
        Dim flagged As Boolean = False

        If Not emailValid(email) Then
            'message
            flagged = True
        End If

        If Not IDValid(id) Then
            'message
            flagged = True
        End If

        If Not PhoneNumValid(phoneNum) Then
            'message
            flagged = True
        End If
        If fnam = vbNullString Then
            'message
            flagged = True
        End If

        If lnam = vbNullString Then
            'message
            flagged = True
        End If

        If position = vbNullString Then
            'message
            flagged = True
        End If

        If gender = vbNullString Then
            'message
            flagged = True
        End If

        If race = vbNullString Then
            'message
            flagged = True
        End If

        If city = vbNullString Then
            'message
            flagged = True
        End If

        If street = vbNullString Then
            'message
            flagged = True
        End If

        If postcode = vbNullString Then
            'message
            flagged = True
        End If



        If Not flagged Then
            'do sql
        End If

    End Sub

    Protected Sub clearOldAppointments()

    End Sub








End Class
