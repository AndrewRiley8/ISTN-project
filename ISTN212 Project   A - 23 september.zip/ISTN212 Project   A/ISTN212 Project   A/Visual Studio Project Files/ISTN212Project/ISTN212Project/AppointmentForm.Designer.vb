﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AppointmentForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnDeleteAppointment = New System.Windows.Forms.Button()
        Me.btnChangeDateTime = New System.Windows.Forms.Button()
        Me.btnAddAppointment = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cboxShowGuestList = New System.Windows.Forms.CheckBox()
        Me.numUDEndMin = New System.Windows.Forms.NumericUpDown()
        Me.AppointmentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ist2dsDataSet = New ISTN212Project.ist2dsDataSet()
        Me.numUDEndHr = New System.Windows.Forms.NumericUpDown()
        Me.numUDStartMin = New System.Windows.Forms.NumericUpDown()
        Me.numUDStartHr = New System.Windows.Forms.NumericUpDown()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.txtGuestList = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.AppointmentIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DescriptionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StarthourDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StartminDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EndhourDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EndminDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AppointmentTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.AppointmentTableAdapter()
        Me.TableAdapterManager = New ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager()
        Me.Ist2dsDataSet1 = New ISTN212Project.ist2dsDataSet()
        Me.btnShowGuests = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.numUDEndMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AppointmentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numUDEndHr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numUDStartMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.numUDStartHr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ist2dsDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(687, 7)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(37, 16)
        Me.lblDate.TabIndex = 1
        Me.lblDate.Text = "Date"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Button5)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(19, 397)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 170)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Navigation"
        '
        'Button5
        '
        Me.Button5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button5.Location = New System.Drawing.Point(7, 65)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 32)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Search"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(7, 103)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 32)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Previous"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.btnDeleteAppointment)
        Me.GroupBox2.Controls.Add(Me.btnChangeDateTime)
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Location = New System.Drawing.Point(19, 241)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(336, 150)
        Me.GroupBox2.TabIndex = 4
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Edit"
        '
        'btnDeleteAppointment
        '
        Me.btnDeleteAppointment.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnDeleteAppointment.Location = New System.Drawing.Point(7, 101)
        Me.btnDeleteAppointment.Name = "btnDeleteAppointment"
        Me.btnDeleteAppointment.Size = New System.Drawing.Size(321, 32)
        Me.btnDeleteAppointment.TabIndex = 2
        Me.btnDeleteAppointment.Text = "Cancel This Appointment"
        Me.btnDeleteAppointment.UseVisualStyleBackColor = True
        '
        'btnChangeDateTime
        '
        Me.btnChangeDateTime.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnChangeDateTime.Location = New System.Drawing.Point(7, 60)
        Me.btnChangeDateTime.Name = "btnChangeDateTime"
        Me.btnChangeDateTime.Size = New System.Drawing.Size(321, 32)
        Me.btnChangeDateTime.TabIndex = 1
        Me.btnChangeDateTime.Text = "Change This Appointment's Date and Time"
        Me.btnChangeDateTime.UseVisualStyleBackColor = True
        '
        'btnAddAppointment
        '
        Me.btnAddAppointment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnAddAppointment.Location = New System.Drawing.Point(248, 360)
        Me.btnAddAppointment.Name = "btnAddAppointment"
        Me.btnAddAppointment.Size = New System.Drawing.Size(296, 32)
        Me.btnAddAppointment.TabIndex = 0
        Me.btnAddAppointment.Text = "Schedule This Appointment"
        Me.btnAddAppointment.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.btnShowGuests)
        Me.GroupBox3.Controls.Add(Me.cboxShowGuestList)
        Me.GroupBox3.Controls.Add(Me.btnAddAppointment)
        Me.GroupBox3.Controls.Add(Me.numUDEndMin)
        Me.GroupBox3.Controls.Add(Me.numUDEndHr)
        Me.GroupBox3.Controls.Add(Me.numUDStartMin)
        Me.GroupBox3.Controls.Add(Me.numUDStartHr)
        Me.GroupBox3.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox3.Controls.Add(Me.txtGuestList)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.txtDescription)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Location = New System.Drawing.Point(387, 223)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(550, 398)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Details"
        '
        'cboxShowGuestList
        '
        Me.cboxShowGuestList.AutoSize = True
        Me.cboxShowGuestList.CheckAlign = System.Drawing.ContentAlignment.TopRight
        Me.cboxShowGuestList.Location = New System.Drawing.Point(30, 148)
        Me.cboxShowGuestList.Name = "cboxShowGuestList"
        Me.cboxShowGuestList.Size = New System.Drawing.Size(121, 20)
        Me.cboxShowGuestList.TabIndex = 17
        Me.cboxShowGuestList.Text = "Show Guest List"
        Me.cboxShowGuestList.UseVisualStyleBackColor = True
        '
        'numUDEndMin
        '
        Me.numUDEndMin.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "end_min", True))
        Me.numUDEndMin.Enabled = False
        Me.numUDEndMin.Location = New System.Drawing.Point(374, 79)
        Me.numUDEndMin.Maximum = New Decimal(New Integer() {59, 0, 0, 0})
        Me.numUDEndMin.Name = "numUDEndMin"
        Me.numUDEndMin.Size = New System.Drawing.Size(120, 22)
        Me.numUDEndMin.TabIndex = 16
        '
        'AppointmentBindingSource
        '
        Me.AppointmentBindingSource.DataMember = "Appointment"
        Me.AppointmentBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'Ist2dsDataSet
        '
        Me.Ist2dsDataSet.DataSetName = "ist2dsDataSet"
        Me.Ist2dsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'numUDEndHr
        '
        Me.numUDEndHr.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "end_hour", True))
        Me.numUDEndHr.Enabled = False
        Me.numUDEndHr.Location = New System.Drawing.Point(248, 79)
        Me.numUDEndHr.Maximum = New Decimal(New Integer() {17, 0, 0, 0})
        Me.numUDEndHr.Minimum = New Decimal(New Integer() {11, 0, 0, 0})
        Me.numUDEndHr.Name = "numUDEndHr"
        Me.numUDEndHr.Size = New System.Drawing.Size(120, 22)
        Me.numUDEndHr.TabIndex = 15
        Me.numUDEndHr.Value = New Decimal(New Integer() {11, 0, 0, 0})
        '
        'numUDStartMin
        '
        Me.numUDStartMin.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "start_min", True))
        Me.numUDStartMin.Enabled = False
        Me.numUDStartMin.Location = New System.Drawing.Point(374, 50)
        Me.numUDStartMin.Maximum = New Decimal(New Integer() {59, 0, 0, 0})
        Me.numUDStartMin.Name = "numUDStartMin"
        Me.numUDStartMin.Size = New System.Drawing.Size(120, 22)
        Me.numUDStartMin.TabIndex = 14
        '
        'numUDStartHr
        '
        Me.numUDStartHr.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "start_hour", True))
        Me.numUDStartHr.Enabled = False
        Me.numUDStartHr.Location = New System.Drawing.Point(248, 50)
        Me.numUDStartHr.Maximum = New Decimal(New Integer() {15, 0, 0, 0})
        Me.numUDStartHr.Minimum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.numUDStartHr.Name = "numUDStartHr"
        Me.numUDStartHr.Size = New System.Drawing.Size(120, 22)
        Me.numUDStartHr.TabIndex = 13
        Me.numUDStartHr.Value = New Decimal(New Integer() {9, 0, 0, 0})
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "date", True))
        Me.DateTimePicker1.Enabled = False
        Me.DateTimePicker1.Location = New System.Drawing.Point(248, 18)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(296, 22)
        Me.DateTimePicker1.TabIndex = 11
        '
        'txtGuestList
        '
        Me.txtGuestList.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.txtGuestList.Location = New System.Drawing.Point(248, 146)
        Me.txtGuestList.Multiline = True
        Me.txtGuestList.Name = "txtGuestList"
        Me.txtGuestList.ReadOnly = True
        Me.txtGuestList.Size = New System.Drawing.Size(296, 125)
        Me.txtGuestList.TabIndex = 10
        Me.txtGuestList.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(27, 81)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(69, 16)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "End Time:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 112)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Description:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(27, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 16)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Start Time:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 16)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Date:"
        '
        'txtDescription
        '
        Me.txtDescription.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "description", True))
        Me.txtDescription.Location = New System.Drawing.Point(248, 112)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.ReadOnly = True
        Me.txtDescription.Size = New System.Drawing.Size(296, 22)
        Me.txtDescription.TabIndex = 2
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(19, 590)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(98, 31)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back to menu"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.AppointmentIDDataGridViewTextBoxColumn, Me.DescriptionDataGridViewTextBoxColumn, Me.DateDataGridViewTextBoxColumn, Me.StarthourDataGridViewTextBoxColumn, Me.StartminDataGridViewTextBoxColumn, Me.EndhourDataGridViewTextBoxColumn, Me.EndminDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.AppointmentBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(19, 26)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(912, 191)
        Me.DataGridView1.TabIndex = 7
        '
        'AppointmentIDDataGridViewTextBoxColumn
        '
        Me.AppointmentIDDataGridViewTextBoxColumn.DataPropertyName = "appointment_ID"
        Me.AppointmentIDDataGridViewTextBoxColumn.HeaderText = "appointment_ID"
        Me.AppointmentIDDataGridViewTextBoxColumn.Name = "AppointmentIDDataGridViewTextBoxColumn"
        '
        'DescriptionDataGridViewTextBoxColumn
        '
        Me.DescriptionDataGridViewTextBoxColumn.DataPropertyName = "description"
        Me.DescriptionDataGridViewTextBoxColumn.HeaderText = "description"
        Me.DescriptionDataGridViewTextBoxColumn.Name = "DescriptionDataGridViewTextBoxColumn"
        '
        'DateDataGridViewTextBoxColumn
        '
        Me.DateDataGridViewTextBoxColumn.DataPropertyName = "date"
        Me.DateDataGridViewTextBoxColumn.HeaderText = "date"
        Me.DateDataGridViewTextBoxColumn.Name = "DateDataGridViewTextBoxColumn"
        '
        'StarthourDataGridViewTextBoxColumn
        '
        Me.StarthourDataGridViewTextBoxColumn.DataPropertyName = "start_hour"
        Me.StarthourDataGridViewTextBoxColumn.HeaderText = "start_hour"
        Me.StarthourDataGridViewTextBoxColumn.Name = "StarthourDataGridViewTextBoxColumn"
        '
        'StartminDataGridViewTextBoxColumn
        '
        Me.StartminDataGridViewTextBoxColumn.DataPropertyName = "start_min"
        Me.StartminDataGridViewTextBoxColumn.HeaderText = "start_min"
        Me.StartminDataGridViewTextBoxColumn.Name = "StartminDataGridViewTextBoxColumn"
        '
        'EndhourDataGridViewTextBoxColumn
        '
        Me.EndhourDataGridViewTextBoxColumn.DataPropertyName = "end_hour"
        Me.EndhourDataGridViewTextBoxColumn.HeaderText = "end_hour"
        Me.EndhourDataGridViewTextBoxColumn.Name = "EndhourDataGridViewTextBoxColumn"
        '
        'EndminDataGridViewTextBoxColumn
        '
        Me.EndminDataGridViewTextBoxColumn.DataPropertyName = "end_min"
        Me.EndminDataGridViewTextBoxColumn.HeaderText = "end_min"
        Me.EndminDataGridViewTextBoxColumn.Name = "EndminDataGridViewTextBoxColumn"
        '
        'AppointmentTableAdapter
        '
        Me.AppointmentTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AbsenceTableAdapter = Nothing
        Me.TableAdapterManager.ApplicantTableAdapter = Nothing
        Me.TableAdapterManager.AppointmentTableAdapter = Me.AppointmentTableAdapter
        Me.TableAdapterManager.Appt_guestTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComplaintTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Nothing
        Me.TableAdapterManager.PositionTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'Ist2dsDataSet1
        '
        Me.Ist2dsDataSet1.DataSetName = "ist2dsDataSet"
        Me.Ist2dsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnShowGuests
        '
        Me.btnShowGuests.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnShowGuests.Location = New System.Drawing.Point(248, 277)
        Me.btnShowGuests.Name = "btnShowGuests"
        Me.btnShowGuests.Size = New System.Drawing.Size(296, 32)
        Me.btnShowGuests.TabIndex = 18
        Me.btnShowGuests.Text = "Show Guests"
        Me.btnShowGuests.UseVisualStyleBackColor = True
        '
        'AppointmentForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(949, 633)
        Me.ControlBox = False
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblDate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "AppointmentForm"
        Me.Text = "AppointmentForm"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.numUDEndMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AppointmentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numUDEndHr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numUDStartMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.numUDStartHr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ist2dsDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDate As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Button5 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents btnDeleteAppointment As Button
    Friend WithEvents btnChangeDateTime As Button
    Friend WithEvents btnAddAppointment As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents txtDescription As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtGuestList As TextBox
    Friend WithEvents Ist2dsDataSet As ist2dsDataSet
    Friend WithEvents numUDEndMin As NumericUpDown
    Friend WithEvents numUDEndHr As NumericUpDown
    Friend WithEvents numUDStartMin As NumericUpDown
    Friend WithEvents numUDStartHr As NumericUpDown
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents cboxShowGuestList As CheckBox
    Friend WithEvents Starthour1DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Startmin1DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Endhour1DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Endmin1DataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents AppointmentBindingSource As BindingSource
    Friend WithEvents AppointmentTableAdapter As ist2dsDataSetTableAdapters.AppointmentTableAdapter
    Friend WithEvents TableAdapterManager As ist2dsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents AppointmentIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DescriptionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StarthourDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StartminDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EndhourDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EndminDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Ist2dsDataSet1 As ist2dsDataSet
    Friend WithEvents btnShowGuests As Button
End Class
