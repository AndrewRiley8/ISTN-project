﻿Public Class ComplaintsForm
    Private Sub ComplaintsForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Hide()
        MenuForm.Show()

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ComplaintsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Complaint' table. You can move, or remove it, as needed.
        Me.ComplaintTableAdapter.Fill(Me.Ist2dsDataSet.Complaint)

    End Sub

    Private Sub btnChooseTarget_Click(sender As Object, e As EventArgs) Handles btnChooseTarget.Click
        Me.Hide()
        EmployeeSelect_TerminateForm.GroupBox2.Visible = False
        EmployeeSelect_TerminateForm.btnClearHistory.Visible = False
        EmployeeSelect_TerminateForm.btnSelect.Visible = True
        EmployeeSelect_TerminateForm.Show()
    End Sub
End Class