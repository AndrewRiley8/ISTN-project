﻿Public Class ApplicantForm
    Private Sub ApplicantForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub
    'back button'
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()
    End Sub

    Private Sub ApplicantForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.Ist2dsDataSet.Appointment)
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Applicant' table. You can move, or remove it, as needed.

        'TODO: This line of code loads data into the 'Ist2dsDataSet.Applicant' table. You can move, or remove it, as needed.
        Me.ApplicantTableAdapter.Fill(Me.Ist2dsDataSet.Applicant)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        EmployeeForm.Hiring = True
        'enter fields from applicant to employee
        EmployeeForm.txtCity.Text = txtCity.Text
        EmployeeForm.txtEmployeeID.Text = txtApplicantID.Text
        EmployeeForm.txtFirstName.Text = txtFirstName.Text
        EmployeeForm.txtLastName.Text = txtLastName.Text
        EmployeeForm.txtPhoneNum.Text = txtPhoneNum.Text
        EmployeeForm.txtPosition.Text = txtPosition.Text
        EmployeeForm.txtPostCode.Text = txtPostCode.Text
        EmployeeForm.txtStreet.Text = txtStreet.Text
        EmployeeForm.txtEmailAddress.Text = txtEmail.Text
        EmployeeForm.cmbGender.Text = cmbGender.Text
        EmployeeForm.cmbRace.Text = cmbRace.Text
        EmployeeForm.cboxDisability.CheckState = cboxDisability.Checked
        EmployeeForm.txtBankAcctNo.ReadOnly = False
        EmployeeForm.txtBankName.ReadOnly = False
        EmployeeForm.txtBranchCode.ReadOnly = False
        EmployeeForm.txtBranchName.ReadOnly = False
        EmployeeForm.txtMonthlySalary.ReadOnly = False
        EmployeeForm.txtTaxNo.ReadOnly = False
        EmployeeForm.DataGridView1.Enabled = False
        EmployeeForm.Show()

    End Sub

    Private Sub btnChoose_Click(sender As Object, e As EventArgs) Handles btnChoose.Click
        Me.Hide()
        PositionForm.Show()
    End Sub

    Private Sub btnEditPositions_Click(sender As Object, e As EventArgs) Handles btnEditPositions.Click
        Me.Hide()
        PositionForm.Show()
    End Sub

    Private Sub btnUpdateAppointment_Click(sender As Object, e As EventArgs) Handles btnUpdateAppointment.Click

    End Sub
End Class