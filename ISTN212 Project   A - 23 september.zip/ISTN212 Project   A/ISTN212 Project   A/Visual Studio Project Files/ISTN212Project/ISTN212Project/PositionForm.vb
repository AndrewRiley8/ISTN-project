﻿Public Class PositionForm
    Private Sub PositionForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()

    End Sub

    Private Sub PositionForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Position' table. You can move, or remove it, as needed.
        Me.PositionTableAdapter.Fill(Me.Ist2dsDataSet.Position)

    End Sub

    Private Sub btnFilterbyDept_Click(sender As Object, e As EventArgs) Handles btnFilterbyDept.Click

    End Sub

    Private Sub btnSelectPositio_Click(sender As Object, e As EventArgs) Handles btnSelectPositio.Click

    End Sub

    Private Sub btnAddPosition_Click(sender As Object, e As EventArgs) Handles btnPositionChanges.Click

    End Sub

    Private Sub cboxNewPosition_CheckedChanged(sender As Object, e As EventArgs) Handles cboxNewPosition.CheckedChanged
        If cboxNewPosition.Checked Then
            btnPositionChanges.Text = "Add"
            txtPositionName.ReadOnly = False
            cmbDepartment.Enabled = True
        Else
            btnPositionChanges.Text = "Save Changes"
            txtPositionName.ReadOnly = True
            cmbDepartment.Enabled = False
        End If
    End Sub
End Class