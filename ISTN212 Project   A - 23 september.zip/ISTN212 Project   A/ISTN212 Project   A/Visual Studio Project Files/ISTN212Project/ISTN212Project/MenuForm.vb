﻿Public Class MenuForm

    Private Sub MenuForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDateTime.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    'sign out button click
    Private Sub btnSignOut_Click(sender As Object, e As EventArgs) Handles btnSignOut.Click
        LoginForm.Show()
        Me.Hide()
        LoginForm.tbPassword.Text = ""
        LoginForm.tbUserName.Text = ""
        LoginForm.Proceed = True

    End Sub

    'about button click
    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        MessageBox.Show("r/programmerhumor HRMU (Human Resource Management Utility) V1.0.0", "About:")
    End Sub

    'help picture box click'
    Private Sub pboxHelp_Click(sender As Object, e As EventArgs) Handles pboxHelp.Click
        Process.Start("www.youtube.com")
    End Sub

    'personalisation button click'
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Personalised.Show()
        Me.Hide()
    End Sub




    'MENUSTRIP BUTTONS'
    Private Sub OpenApplicants(Dept As String)
        Me.Hide()
        'let the dgview on the applicant form hold:  select * from applicant where position_ID IN (select * from position where department = @Dept) 
        ApplicantForm.Show()
    End Sub
    'HIRING SECTION'
    Private Sub AccountingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccountingToolStripMenuItem.Click
        OpenApplicants("Accounting")
    End Sub

    Private Sub AdministrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdministrationToolStripMenuItem.Click
        OpenApplicants("Administration")
    End Sub

    Private Sub EngineeringToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EngineeringToolStripMenuItem.Click
        OpenApplicants("Engineering")
    End Sub

    Private Sub FinanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FinanceToolStripMenuItem.Click
        OpenApplicants("Finance")
    End Sub

    Private Sub HumanResourcesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HumanResourcesToolStripMenuItem.Click
        OpenApplicants("Human Resources")
    End Sub

    Private Sub ITToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ITToolStripMenuItem.Click
        OpenApplicants("IT")
    End Sub

    Private Sub MarketingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MarketingToolStripMenuItem.Click
        OpenApplicants("Marketing")
    End Sub

    Private Sub SalesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalesToolStripMenuItem.Click
        OpenApplicants("Sales")
    End Sub

    Private Sub AllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AllToolStripMenuItem.Click
        OpenApplicants("empty' OR 1=1")

    End Sub


    'TERMINATION SECTION'
    Private Sub TermEmplToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TermEmplToolStripMenuItem.Click
        Me.Hide()
        EmployeeSelect_TerminateForm.btnSelect.Visible() = False
        EmployeeSelect_TerminateForm.GroupBox2.Enabled = True
        EmployeeSelect_TerminateForm.Show()
    End Sub

    Private Sub ViewTerminationHistoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewTerminationHistoryToolStripMenuItem.Click
        Me.Hide()
        EmployeeSelect_TerminateForm.btnSelect.Visible = False
        EmployeeSelect_TerminateForm.GroupBox2.Enabled = False
        EmployeeSelect_TerminateForm.Show()
    End Sub




    'GENERAL SECTION'
    'COMPLAINTS'
    Private Sub ViewAllComplaintsToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ViewAllComplaintsToolStripMenuItem1.Click
        Me.Hide()
        ComplaintsForm.DateTimePickerIssued.Enabled = False
        ComplaintsForm.txtEmployee.ReadOnly = True
        ComplaintsForm.txtDescription.ReadOnly = True
        ComplaintsForm.btnChooseTarget.Enabled = False
        ComplaintsForm.btnAddressComplaint.Visible = True
        ComplaintsForm.btnAddComplaint.Visible = False
        ComplaintsForm.Show()
    End Sub

    Private Sub AddNewComplaintToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AddNewComplaintToolStripMenuItem1.Click
        Me.Hide()
        ComplaintsForm.DateTimePickerIssued.Enabled = True
        ComplaintsForm.txtEmployee.ReadOnly = False
        ComplaintsForm.txtDescription.ReadOnly = False
        ComplaintsForm.btnChooseTarget.Enabled = True
        ComplaintsForm.btnAddressComplaint.Visible = False
        ComplaintsForm.btnAddComplaint.Visible = True
        ComplaintsForm.Show()

    End Sub

    'ABSENCES'
    Private Sub ViewAllAbsencesToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ViewAllAbsencesToolStripMenuItem2.Click
        Me.Hide()
        AbsenceForm.BtnAddAbsence.Visible = False
        AbsenceForm.Button1.Enabled = False
        AbsenceForm.txtEmployeeID.ReadOnly = True
        AbsenceForm.DateTimePickerStart.Enabled = False
        AbsenceForm.DateTimePickerStart.Enabled = False
        AbsenceForm.cmbType.Enabled = False
        AbsenceForm.Show()
    End Sub

    Private Sub AddNewAbsenceToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles AddNewAbsenceToolStripMenuItem2.Click
        Me.Hide()
        AbsenceForm.BtnAddAbsence.Visible = True
        AbsenceForm.Button1.Enabled = True
        AbsenceForm.txtEmployeeID.ReadOnly = False
        AbsenceForm.DateTimePickerStart.Enabled = True
        AbsenceForm.DateTimePickerStart.Enabled = True
        AbsenceForm.cmbType.Enabled = True
        AbsenceForm.Show()
    End Sub



    'EDIT GENERAL DETAILS'

    Private Sub EditGenEmployeeDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditGenEmployeeDetailsToolStripMenuItem.Click
        Me.Hide()

        EmployeeForm.Show()
        EmployeeForm.ButtonFinHire.Visible = False

    End Sub

    'APPOINTMENT SECTION'

    Private Sub ViewAllAppointmentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewAllAppointmentsToolStripMenuItem.Click
        Me.Hide()
        AppointmentForm.DateTimePicker1.Enabled = False
        AppointmentForm.numUDStartHr.Enabled = False
        AppointmentForm.numUDStartMin.Enabled = False
        AppointmentForm.numUDEndHr.Enabled = False
        AppointmentForm.numUDEndMin.Enabled = False
        AppointmentForm.txtDescription.ReadOnly = True
        AppointmentForm.btnAddAppointment.Visible = False
        AppointmentForm.Show()
    End Sub

    Private Sub AddNewAppointmentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddNewAppointmentToolStripMenuItem.Click
        Me.Hide()
        AppointmentForm.btnAddAppointment.Visible = True
        AppointmentForm.DateTimePicker1.Enabled = True
        AppointmentForm.numUDStartHr.Enabled = True
        AppointmentForm.numUDStartMin.Enabled = True
        AppointmentForm.numUDEndHr.Enabled = True
        AppointmentForm.numUDEndMin.Enabled =  True
        AppointmentForm.txtDescription.ReadOnly = False
        AppointmentForm.Show()
    End Sub

    Private Sub AnalyticsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AnalyticsToolStripMenuItem.Click
        Me.Hide()
        ApptGuestForm.Show()
    End Sub

    'MISC SECTION'




End Class