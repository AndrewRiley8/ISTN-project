﻿Public Class EmployeeSelect_TerminateForm
    Private Activator As Integer
    Protected Const Complaints = 0
    Protected Const Absences = 1
    Protected Const Terminations = 2

    Private Sub MiniEmployeeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Employee' table. You can move, or remove it, as needed.
        'Me.EmployeeTableAdapter.Fill(Me.Ist2dsDataSet.Employee)

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()
    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        Select Case Activator
            Case Complaints
                Me.Hide()
                ComplaintsForm.Show()
            Case Absences
                Me.Hide()
                AbsenceForm.Show()
            Case Terminations
                GroupBox2.Visible = True
                btnSelect.Visible = False
        End Select


    End Sub

    Private Sub btnChoose_Click(sender As Object, e As EventArgs) Handles btnChoose.Click
        GroupBox2.Visible = False
        btnSelect.Visible = True
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

    End Sub
End Class