﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EmployeeForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtSearchEmployeeID = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtSearchEmployeeLastName = New System.Windows.Forms.TextBox()
        Me.txtSearchEmployeeFirstName = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.cmbDepartment = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnFilterByDeptProtected = New System.Windows.Forms.Button()
        Me.btnFilterByDept = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cmbGender = New System.Windows.Forms.ComboBox()
        Me.EmployeeBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ist2dsDataSet = New ISTN212Project.ist2dsDataSet()
        Me.cmbRace = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.cboxDisability = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtTaxNo = New System.Windows.Forms.TextBox()
        Me.txtMonthlySalary = New System.Windows.Forms.TextBox()
        Me.txtBankAcctNo = New System.Windows.Forms.TextBox()
        Me.txtBranchCode = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtPosition = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtBranchName = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtBankName = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.DateTimePickerHired = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtPostCode = New System.Windows.Forms.TextBox()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.txtStreet = New System.Windows.Forms.TextBox()
        Me.txtEmailAddress = New System.Windows.Forms.TextBox()
        Me.txtPhoneNum = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ButtonFinHire = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.EmployeeIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FirstnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PhonenumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailaddressDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StreetnumberandnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CityDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PostalcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateofhireDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateofterminationDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RaceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GenderDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DisabilitystatusDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.MonthlybasesalaryDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BanknameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BankaccountnumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BankbranchnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BankbranchcodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TaxnumberDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.position_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmployeeTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.EmployeeTableAdapter()
        Me.TableAdapterManager = New ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.BackColor = System.Drawing.Color.Transparent
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.lblDate.Location = New System.Drawing.Point(1228, 9)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(40, 16)
        Me.lblDate.TabIndex = 2
        Me.lblDate.Text = "Date:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(15, 713)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(98, 31)
        Me.btnBack.TabIndex = 3
        Me.btnBack.Text = "Back to menu"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.btnSearch)
        Me.GroupBox1.Controls.Add(Me.Label15)
        Me.GroupBox1.Controls.Add(Me.txtSearchEmployeeID)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtSearchEmployeeLastName)
        Me.GroupBox1.Controls.Add(Me.txtSearchEmployeeFirstName)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox1.Location = New System.Drawing.Point(13, 312)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(336, 183)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Navigation"
        '
        'btnSearch
        '
        Me.btnSearch.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnSearch.Location = New System.Drawing.Point(9, 143)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(75, 32)
        Me.btnSearch.TabIndex = 4
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(11, 28)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(89, 16)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "Employee ID:"
        '
        'txtSearchEmployeeID
        '
        Me.txtSearchEmployeeID.Location = New System.Drawing.Point(106, 25)
        Me.txtSearchEmployeeID.Name = "txtSearchEmployeeID"
        Me.txtSearchEmployeeID.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeID.TabIndex = 28
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 16)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "First name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 16)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "Last name:"
        '
        'txtSearchEmployeeLastName
        '
        Me.txtSearchEmployeeLastName.Location = New System.Drawing.Point(106, 85)
        Me.txtSearchEmployeeLastName.Name = "txtSearchEmployeeLastName"
        Me.txtSearchEmployeeLastName.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeLastName.TabIndex = 40
        '
        'txtSearchEmployeeFirstName
        '
        Me.txtSearchEmployeeFirstName.Location = New System.Drawing.Point(106, 56)
        Me.txtSearchEmployeeFirstName.Name = "txtSearchEmployeeFirstName"
        Me.txtSearchEmployeeFirstName.Size = New System.Drawing.Size(212, 22)
        Me.txtSearchEmployeeFirstName.TabIndex = 39
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.cmbDepartment)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.btnFilterByDeptProtected)
        Me.GroupBox2.Controls.Add(Me.btnFilterByDept)
        Me.GroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.GroupBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox2.Location = New System.Drawing.Point(13, 501)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(336, 206)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Filter"
        '
        'cmbDepartment
        '
        Me.cmbDepartment.FormattingEnabled = True
        Me.cmbDepartment.Items.AddRange(New Object() {"Accounting", "Administration", "Engineering", "Finance", "Human Resources", "IT", "Marketing", "Sales", "All"})
        Me.cmbDepartment.Location = New System.Drawing.Point(106, 21)
        Me.cmbDepartment.Name = "cmbDepartment"
        Me.cmbDepartment.Size = New System.Drawing.Size(212, 24)
        Me.cmbDepartment.TabIndex = 47
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(11, 24)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 16)
        Me.Label5.TabIndex = 46
        Me.Label5.Text = "Department:"
        '
        'btnFilterByDeptProtected
        '
        Me.btnFilterByDeptProtected.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnFilterByDeptProtected.Location = New System.Drawing.Point(14, 118)
        Me.btnFilterByDeptProtected.Name = "btnFilterByDeptProtected"
        Me.btnFilterByDeptProtected.Size = New System.Drawing.Size(304, 31)
        Me.btnFilterByDeptProtected.TabIndex = 1
        Me.btnFilterByDeptProtected.Text = "Show Only Protected Class Employees"
        Me.btnFilterByDeptProtected.UseVisualStyleBackColor = True
        '
        'btnFilterByDept
        '
        Me.btnFilterByDept.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnFilterByDept.Location = New System.Drawing.Point(14, 73)
        Me.btnFilterByDept.Name = "btnFilterByDept"
        Me.btnFilterByDept.Size = New System.Drawing.Size(304, 32)
        Me.btnFilterByDept.TabIndex = 0
        Me.btnFilterByDept.Text = "Show All Employees"
        Me.btnFilterByDept.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.cmbGender)
        Me.GroupBox3.Controls.Add(Me.cmbRace)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.txtEmployeeID)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.txtLastName)
        Me.GroupBox3.Controls.Add(Me.txtFirstName)
        Me.GroupBox3.Controls.Add(Me.cboxDisability)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Location = New System.Drawing.Point(375, 312)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(531, 204)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Personal Details"
        '
        'cmbGender
        '
        Me.cmbGender.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "gender", True))
        Me.cmbGender.FormattingEnabled = True
        Me.cmbGender.Items.AddRange(New Object() {"Female", "Male", "Other", "Unspecified"})
        Me.cmbGender.Location = New System.Drawing.Point(255, 113)
        Me.cmbGender.Name = "cmbGender"
        Me.cmbGender.Size = New System.Drawing.Size(258, 24)
        Me.cmbGender.TabIndex = 54
        '
        'EmployeeBindingSource
        '
        Me.EmployeeBindingSource.DataMember = "Employee"
        Me.EmployeeBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'Ist2dsDataSet
        '
        Me.Ist2dsDataSet.DataSetName = "ist2dsDataSet"
        Me.Ist2dsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cmbRace
        '
        Me.cmbRace.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "race", True))
        Me.cmbRace.FormattingEnabled = True
        Me.cmbRace.Items.AddRange(New Object() {"European", "Indian", "African", "Asian", "Other"})
        Me.cmbRace.Location = New System.Drawing.Point(255, 146)
        Me.cmbRace.Name = "cmbRace"
        Me.cmbRace.Size = New System.Drawing.Size(258, 24)
        Me.cmbRace.TabIndex = 53
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(20, 113)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 16)
        Me.Label8.TabIndex = 52
        Me.Label8.Text = "Gender:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 28)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 16)
        Me.Label4.TabIndex = 47
        Me.Label4.Text = "Employee ID:"
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "employee_ID", True))
        Me.txtEmployeeID.Location = New System.Drawing.Point(255, 25)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.ReadOnly = True
        Me.txtEmployeeID.Size = New System.Drawing.Size(258, 22)
        Me.txtEmployeeID.TabIndex = 46
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(20, 56)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(73, 16)
        Me.Label6.TabIndex = 48
        Me.Label6.Text = "First name:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(20, 85)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 16)
        Me.Label7.TabIndex = 49
        Me.Label7.Text = "Last name:"
        '
        'txtLastName
        '
        Me.txtLastName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "last_name", True))
        Me.txtLastName.Location = New System.Drawing.Point(255, 85)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.ReadOnly = True
        Me.txtLastName.Size = New System.Drawing.Size(258, 22)
        Me.txtLastName.TabIndex = 51
        '
        'txtFirstName
        '
        Me.txtFirstName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "first_name", True))
        Me.txtFirstName.Location = New System.Drawing.Point(255, 56)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.ReadOnly = True
        Me.txtFirstName.Size = New System.Drawing.Size(258, 22)
        Me.txtFirstName.TabIndex = 50
        '
        'cboxDisability
        '
        Me.cboxDisability.AutoSize = True
        Me.cboxDisability.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.cboxDisability.DataBindings.Add(New System.Windows.Forms.Binding("Checked", Me.EmployeeBindingSource, "disability_status", True))
        Me.cboxDisability.Enabled = False
        Me.cboxDisability.Location = New System.Drawing.Point(18, 174)
        Me.cboxDisability.Name = "cboxDisability"
        Me.cboxDisability.Size = New System.Drawing.Size(243, 20)
        Me.cboxDisability.TabIndex = 45
        Me.cboxDisability.Text = "This Employee Has A Disability:        "
        Me.cboxDisability.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(20, 146)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 16)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Race:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(20, 24)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(73, 16)
        Me.Label23.TabIndex = 7
        Me.Label23.Text = "Date hired:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(20, 76)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(82, 16)
        Me.Label21.TabIndex = 9
        Me.Label21.Text = "Tax number:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(20, 160)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(123, 16)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Bank Branch Code:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(20, 47)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(117, 16)
        Me.Label18.TabIndex = 12
        Me.Label18.Text = "Monthly base pay:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(20, 132)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(140, 16)
        Me.Label17.TabIndex = 13
        Me.Label17.Text = "Bank account number:"
        '
        'txtTaxNo
        '
        Me.txtTaxNo.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "tax_number", True))
        Me.txtTaxNo.Location = New System.Drawing.Point(255, 73)
        Me.txtTaxNo.Name = "txtTaxNo"
        Me.txtTaxNo.ReadOnly = True
        Me.txtTaxNo.Size = New System.Drawing.Size(262, 22)
        Me.txtTaxNo.TabIndex = 23
        '
        'txtMonthlySalary
        '
        Me.txtMonthlySalary.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "monthly_base_salary", True))
        Me.txtMonthlySalary.Location = New System.Drawing.Point(255, 44)
        Me.txtMonthlySalary.Name = "txtMonthlySalary"
        Me.txtMonthlySalary.ReadOnly = True
        Me.txtMonthlySalary.Size = New System.Drawing.Size(262, 22)
        Me.txtMonthlySalary.TabIndex = 24
        '
        'txtBankAcctNo
        '
        Me.txtBankAcctNo.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "bank_account_number", True))
        Me.txtBankAcctNo.Location = New System.Drawing.Point(255, 129)
        Me.txtBankAcctNo.Name = "txtBankAcctNo"
        Me.txtBankAcctNo.ReadOnly = True
        Me.txtBankAcctNo.Size = New System.Drawing.Size(262, 22)
        Me.txtBankAcctNo.TabIndex = 25
        '
        'txtBranchCode
        '
        Me.txtBranchCode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "bank_branch_code", True))
        Me.txtBranchCode.Location = New System.Drawing.Point(255, 157)
        Me.txtBranchCode.Name = "txtBranchCode"
        Me.txtBranchCode.ReadOnly = True
        Me.txtBranchCode.Size = New System.Drawing.Size(262, 22)
        Me.txtBranchCode.TabIndex = 27
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox4.Controls.Add(Me.txtPosition)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Me.txtBranchName)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.txtBankName)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.DateTimePickerHired)
        Me.GroupBox4.Controls.Add(Me.txtBranchCode)
        Me.GroupBox4.Controls.Add(Me.txtBankAcctNo)
        Me.GroupBox4.Controls.Add(Me.txtMonthlySalary)
        Me.GroupBox4.Controls.Add(Me.txtTaxNo)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox4.Location = New System.Drawing.Point(375, 501)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(531, 243)
        Me.GroupBox4.TabIndex = 7
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Compensation Details"
        '
        'txtPosition
        '
        Me.txtPosition.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "position_name", True))
        Me.txtPosition.Location = New System.Drawing.Point(255, 216)
        Me.txtPosition.Name = "txtPosition"
        Me.txtPosition.ReadOnly = True
        Me.txtPosition.Size = New System.Drawing.Size(262, 22)
        Me.txtPosition.TabIndex = 34
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(20, 219)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(59, 16)
        Me.Label19.TabIndex = 33
        Me.Label19.Text = "Position:"
        '
        'txtBranchName
        '
        Me.txtBranchName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "bank_branch_name", True))
        Me.txtBranchName.Location = New System.Drawing.Point(255, 186)
        Me.txtBranchName.Name = "txtBranchName"
        Me.txtBranchName.ReadOnly = True
        Me.txtBranchName.Size = New System.Drawing.Size(262, 22)
        Me.txtBranchName.TabIndex = 32
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(20, 189)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(127, 16)
        Me.Label16.TabIndex = 31
        Me.Label16.Text = "Bank Branch Name:"
        '
        'txtBankName
        '
        Me.txtBankName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "bank_name", True))
        Me.txtBankName.Location = New System.Drawing.Point(255, 101)
        Me.txtBankName.Name = "txtBankName"
        Me.txtBankName.ReadOnly = True
        Me.txtBankName.Size = New System.Drawing.Size(262, 22)
        Me.txtBankName.TabIndex = 30
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(20, 104)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 16)
        Me.Label14.TabIndex = 29
        Me.Label14.Text = "Bank Name:"
        '
        'DateTimePickerHired
        '
        Me.DateTimePickerHired.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "date_of_hire", True))
        Me.DateTimePickerHired.Location = New System.Drawing.Point(255, 19)
        Me.DateTimePickerHired.Name = "DateTimePickerHired"
        Me.DateTimePickerHired.Size = New System.Drawing.Size(262, 22)
        Me.DateTimePickerHired.TabIndex = 28
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox5.Controls.Add(Me.txtPostCode)
        Me.GroupBox5.Controls.Add(Me.txtCity)
        Me.GroupBox5.Controls.Add(Me.txtStreet)
        Me.GroupBox5.Controls.Add(Me.txtEmailAddress)
        Me.GroupBox5.Controls.Add(Me.txtPhoneNum)
        Me.GroupBox5.Controls.Add(Me.Label9)
        Me.GroupBox5.Controls.Add(Me.Label10)
        Me.GroupBox5.Controls.Add(Me.Label11)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox5.Location = New System.Drawing.Point(923, 312)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(531, 267)
        Me.GroupBox5.TabIndex = 8
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Contact Details"
        '
        'txtPostCode
        '
        Me.txtPostCode.Location = New System.Drawing.Point(180, 136)
        Me.txtPostCode.Name = "txtPostCode"
        Me.txtPostCode.ReadOnly = True
        Me.txtPostCode.Size = New System.Drawing.Size(257, 22)
        Me.txtPostCode.TabIndex = 20
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(180, 107)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.ReadOnly = True
        Me.txtCity.Size = New System.Drawing.Size(257, 22)
        Me.txtCity.TabIndex = 19
        '
        'txtStreet
        '
        Me.txtStreet.Location = New System.Drawing.Point(180, 78)
        Me.txtStreet.Name = "txtStreet"
        Me.txtStreet.ReadOnly = True
        Me.txtStreet.Size = New System.Drawing.Size(257, 22)
        Me.txtStreet.TabIndex = 18
        '
        'txtEmailAddress
        '
        Me.txtEmailAddress.Location = New System.Drawing.Point(180, 50)
        Me.txtEmailAddress.Name = "txtEmailAddress"
        Me.txtEmailAddress.ReadOnly = True
        Me.txtEmailAddress.Size = New System.Drawing.Size(257, 22)
        Me.txtEmailAddress.TabIndex = 17
        '
        'txtPhoneNum
        '
        Me.txtPhoneNum.Location = New System.Drawing.Point(180, 22)
        Me.txtPhoneNum.Name = "txtPhoneNum"
        Me.txtPhoneNum.ReadOnly = True
        Me.txtPhoneNum.Size = New System.Drawing.Size(257, 22)
        Me.txtPhoneNum.TabIndex = 16
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "postal_code", True))
        Me.Label9.Location = New System.Drawing.Point(19, 139)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(83, 16)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Postal code:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "city", True))
        Me.Label10.Location = New System.Drawing.Point(19, 110)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(33, 16)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "City:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "street_number_and_name", True))
        Me.Label11.Location = New System.Drawing.Point(19, 81)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(157, 16)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "Street name and number:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "email_address", True))
        Me.Label12.Location = New System.Drawing.Point(19, 53)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(98, 16)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Email address:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EmployeeBindingSource, "phone_number", True))
        Me.Label13.Location = New System.Drawing.Point(19, 25)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(98, 16)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Phone number:"
        '
        'ButtonFinHire
        '
        Me.ButtonFinHire.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonFinHire.Location = New System.Drawing.Point(1103, 602)
        Me.ButtonFinHire.Name = "ButtonFinHire"
        Me.ButtonFinHire.Size = New System.Drawing.Size(271, 31)
        Me.ButtonFinHire.TabIndex = 9
        Me.ButtonFinHire.Text = "Finalise Hiring"
        Me.ButtonFinHire.UseVisualStyleBackColor = True
        Me.ButtonFinHire.Visible = False
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.EmployeeIDDataGridViewTextBoxColumn, Me.FirstnameDataGridViewTextBoxColumn, Me.LastnameDataGridViewTextBoxColumn, Me.PhonenumberDataGridViewTextBoxColumn, Me.EmailaddressDataGridViewTextBoxColumn, Me.StreetnumberandnameDataGridViewTextBoxColumn, Me.CityDataGridViewTextBoxColumn, Me.PostalcodeDataGridViewTextBoxColumn, Me.DateofhireDataGridViewTextBoxColumn, Me.DateofterminationDataGridViewTextBoxColumn, Me.RaceDataGridViewTextBoxColumn, Me.GenderDataGridViewTextBoxColumn, Me.DisabilitystatusDataGridViewCheckBoxColumn, Me.MonthlybasesalaryDataGridViewTextBoxColumn, Me.BanknameDataGridViewTextBoxColumn, Me.BankaccountnumberDataGridViewTextBoxColumn, Me.BankbranchnameDataGridViewTextBoxColumn, Me.BankbranchcodeDataGridViewTextBoxColumn, Me.TaxnumberDataGridViewTextBoxColumn, Me.position_name})
        Me.DataGridView1.DataSource = Me.EmployeeBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 9)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(1476, 297)
        Me.DataGridView1.TabIndex = 10
        '
        'EmployeeIDDataGridViewTextBoxColumn
        '
        Me.EmployeeIDDataGridViewTextBoxColumn.DataPropertyName = "employee_ID"
        Me.EmployeeIDDataGridViewTextBoxColumn.HeaderText = "employee_ID"
        Me.EmployeeIDDataGridViewTextBoxColumn.Name = "EmployeeIDDataGridViewTextBoxColumn"
        Me.EmployeeIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'FirstnameDataGridViewTextBoxColumn
        '
        Me.FirstnameDataGridViewTextBoxColumn.DataPropertyName = "first_name"
        Me.FirstnameDataGridViewTextBoxColumn.HeaderText = "first_name"
        Me.FirstnameDataGridViewTextBoxColumn.Name = "FirstnameDataGridViewTextBoxColumn"
        Me.FirstnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'LastnameDataGridViewTextBoxColumn
        '
        Me.LastnameDataGridViewTextBoxColumn.DataPropertyName = "last_name"
        Me.LastnameDataGridViewTextBoxColumn.HeaderText = "last_name"
        Me.LastnameDataGridViewTextBoxColumn.Name = "LastnameDataGridViewTextBoxColumn"
        Me.LastnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PhonenumberDataGridViewTextBoxColumn
        '
        Me.PhonenumberDataGridViewTextBoxColumn.DataPropertyName = "phone_number"
        Me.PhonenumberDataGridViewTextBoxColumn.HeaderText = "phone_number"
        Me.PhonenumberDataGridViewTextBoxColumn.Name = "PhonenumberDataGridViewTextBoxColumn"
        Me.PhonenumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'EmailaddressDataGridViewTextBoxColumn
        '
        Me.EmailaddressDataGridViewTextBoxColumn.DataPropertyName = "email_address"
        Me.EmailaddressDataGridViewTextBoxColumn.HeaderText = "email_address"
        Me.EmailaddressDataGridViewTextBoxColumn.Name = "EmailaddressDataGridViewTextBoxColumn"
        Me.EmailaddressDataGridViewTextBoxColumn.ReadOnly = True
        '
        'StreetnumberandnameDataGridViewTextBoxColumn
        '
        Me.StreetnumberandnameDataGridViewTextBoxColumn.DataPropertyName = "street_number_and_name"
        Me.StreetnumberandnameDataGridViewTextBoxColumn.HeaderText = "street_number_and_name"
        Me.StreetnumberandnameDataGridViewTextBoxColumn.Name = "StreetnumberandnameDataGridViewTextBoxColumn"
        Me.StreetnumberandnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'CityDataGridViewTextBoxColumn
        '
        Me.CityDataGridViewTextBoxColumn.DataPropertyName = "city"
        Me.CityDataGridViewTextBoxColumn.HeaderText = "city"
        Me.CityDataGridViewTextBoxColumn.Name = "CityDataGridViewTextBoxColumn"
        Me.CityDataGridViewTextBoxColumn.ReadOnly = True
        '
        'PostalcodeDataGridViewTextBoxColumn
        '
        Me.PostalcodeDataGridViewTextBoxColumn.DataPropertyName = "postal_code"
        Me.PostalcodeDataGridViewTextBoxColumn.HeaderText = "postal_code"
        Me.PostalcodeDataGridViewTextBoxColumn.Name = "PostalcodeDataGridViewTextBoxColumn"
        Me.PostalcodeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DateofhireDataGridViewTextBoxColumn
        '
        Me.DateofhireDataGridViewTextBoxColumn.DataPropertyName = "date_of_hire"
        Me.DateofhireDataGridViewTextBoxColumn.HeaderText = "date_of_hire"
        Me.DateofhireDataGridViewTextBoxColumn.Name = "DateofhireDataGridViewTextBoxColumn"
        Me.DateofhireDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DateofterminationDataGridViewTextBoxColumn
        '
        Me.DateofterminationDataGridViewTextBoxColumn.DataPropertyName = "date_of_termination"
        Me.DateofterminationDataGridViewTextBoxColumn.HeaderText = "date_of_termination"
        Me.DateofterminationDataGridViewTextBoxColumn.Name = "DateofterminationDataGridViewTextBoxColumn"
        Me.DateofterminationDataGridViewTextBoxColumn.ReadOnly = True
        '
        'RaceDataGridViewTextBoxColumn
        '
        Me.RaceDataGridViewTextBoxColumn.DataPropertyName = "race"
        Me.RaceDataGridViewTextBoxColumn.HeaderText = "race"
        Me.RaceDataGridViewTextBoxColumn.Name = "RaceDataGridViewTextBoxColumn"
        Me.RaceDataGridViewTextBoxColumn.ReadOnly = True
        '
        'GenderDataGridViewTextBoxColumn
        '
        Me.GenderDataGridViewTextBoxColumn.DataPropertyName = "gender"
        Me.GenderDataGridViewTextBoxColumn.HeaderText = "gender"
        Me.GenderDataGridViewTextBoxColumn.Name = "GenderDataGridViewTextBoxColumn"
        Me.GenderDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DisabilitystatusDataGridViewCheckBoxColumn
        '
        Me.DisabilitystatusDataGridViewCheckBoxColumn.DataPropertyName = "disability_status"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.HeaderText = "disability_status"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.Name = "DisabilitystatusDataGridViewCheckBoxColumn"
        Me.DisabilitystatusDataGridViewCheckBoxColumn.ReadOnly = True
        '
        'MonthlybasesalaryDataGridViewTextBoxColumn
        '
        Me.MonthlybasesalaryDataGridViewTextBoxColumn.DataPropertyName = "monthly_base_salary"
        Me.MonthlybasesalaryDataGridViewTextBoxColumn.HeaderText = "monthly_base_salary"
        Me.MonthlybasesalaryDataGridViewTextBoxColumn.Name = "MonthlybasesalaryDataGridViewTextBoxColumn"
        Me.MonthlybasesalaryDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BanknameDataGridViewTextBoxColumn
        '
        Me.BanknameDataGridViewTextBoxColumn.DataPropertyName = "bank_name"
        Me.BanknameDataGridViewTextBoxColumn.HeaderText = "bank_name"
        Me.BanknameDataGridViewTextBoxColumn.Name = "BanknameDataGridViewTextBoxColumn"
        Me.BanknameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BankaccountnumberDataGridViewTextBoxColumn
        '
        Me.BankaccountnumberDataGridViewTextBoxColumn.DataPropertyName = "bank_account_number"
        Me.BankaccountnumberDataGridViewTextBoxColumn.HeaderText = "bank_account_number"
        Me.BankaccountnumberDataGridViewTextBoxColumn.Name = "BankaccountnumberDataGridViewTextBoxColumn"
        Me.BankaccountnumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BankbranchnameDataGridViewTextBoxColumn
        '
        Me.BankbranchnameDataGridViewTextBoxColumn.DataPropertyName = "bank_branch_name"
        Me.BankbranchnameDataGridViewTextBoxColumn.HeaderText = "bank_branch_name"
        Me.BankbranchnameDataGridViewTextBoxColumn.Name = "BankbranchnameDataGridViewTextBoxColumn"
        Me.BankbranchnameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'BankbranchcodeDataGridViewTextBoxColumn
        '
        Me.BankbranchcodeDataGridViewTextBoxColumn.DataPropertyName = "bank_branch_code"
        Me.BankbranchcodeDataGridViewTextBoxColumn.HeaderText = "bank_branch_code"
        Me.BankbranchcodeDataGridViewTextBoxColumn.Name = "BankbranchcodeDataGridViewTextBoxColumn"
        Me.BankbranchcodeDataGridViewTextBoxColumn.ReadOnly = True
        '
        'TaxnumberDataGridViewTextBoxColumn
        '
        Me.TaxnumberDataGridViewTextBoxColumn.DataPropertyName = "tax_number"
        Me.TaxnumberDataGridViewTextBoxColumn.HeaderText = "tax_number"
        Me.TaxnumberDataGridViewTextBoxColumn.Name = "TaxnumberDataGridViewTextBoxColumn"
        Me.TaxnumberDataGridViewTextBoxColumn.ReadOnly = True
        '
        'position_name
        '
        Me.position_name.DataPropertyName = "position_name"
        Me.position_name.HeaderText = "position_name"
        Me.position_name.Name = "position_name"
        Me.position_name.ReadOnly = True
        '
        'EmployeeTableAdapter
        '
        Me.EmployeeTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AbsenceTableAdapter = Nothing
        Me.TableAdapterManager.ApplicantTableAdapter = Nothing
        Me.TableAdapterManager.AppointmentTableAdapter = Nothing
        Me.TableAdapterManager.Appt_guestTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComplaintTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Me.EmployeeTableAdapter
        Me.TableAdapterManager.PositionTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'EmployeeForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.ControlBox = False
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.ButtonFinHire)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.lblDate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "EmployeeForm"
        Me.Text = "Employees"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.EmployeeBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDate As Label
    Friend WithEvents btnBack As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnFilterByDeptProtected As Button
    Friend WithEvents btnFilterByDept As Button
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtSearchEmployeeID As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents txtTaxNo As TextBox
    Friend WithEvents txtMonthlySalary As TextBox
    Friend WithEvents txtBankAcctNo As TextBox
    Friend WithEvents txtBranchCode As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents txtPostCode As TextBox
    Friend WithEvents txtCity As TextBox
    Friend WithEvents txtStreet As TextBox
    Friend WithEvents txtEmailAddress As TextBox
    Friend WithEvents txtPhoneNum As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents cboxDisability As CheckBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtSearchEmployeeLastName As TextBox
    Friend WithEvents txtSearchEmployeeFirstName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents cmbDepartment As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Ist2dsDataSet As ist2dsDataSet
    Friend WithEvents ButtonFinHire As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents EmployeeBindingSource As BindingSource
    Friend WithEvents EmployeeTableAdapter As ist2dsDataSetTableAdapters.EmployeeTableAdapter
    Friend WithEvents TableAdapterManager As ist2dsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents cmbGender As ComboBox
    Friend WithEvents cmbRace As ComboBox
    Friend WithEvents DateTimePickerHired As DateTimePicker
    Friend WithEvents EmployeeIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents FirstnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LastnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PhonenumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmailaddressDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents StreetnumberandnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CityDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PostalcodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateofhireDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DateofterminationDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RaceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents GenderDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DisabilitystatusDataGridViewCheckBoxColumn As DataGridViewCheckBoxColumn
    Friend WithEvents MonthlybasesalaryDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BanknameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BankaccountnumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BankbranchnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents BankbranchcodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TaxnumberDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents position_name As DataGridViewTextBoxColumn
    Friend WithEvents txtPosition As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents txtBranchName As TextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtBankName As TextBox
    Friend WithEvents Label14 As Label
End Class
