﻿Public Class EmployeeForm
    Private Sub EmployeeForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyy/MM/dd")
    End Sub


    Private Sub EmployeeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Employee' table. You can move, or remove it, as needed.
        Me.EmployeeTableAdapter.Fill(Me.Ist2dsDataSet.Employee)
    End Sub
    '__________________________________________________________________________________________________________________________________________________________________
    'BUTTON EVENT HANDLERS

    'return to menu
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()

    End Sub

    'filters
    Private Sub btnFilterByDept_Click(sender As Object, e As EventArgs) Handles btnFilterByDept.Click
        FunctionResources.filterEmployee(cmbDepartment.Text, False)

        '        If cmbDepartment.Text <> "All" Then
        '            EmployeeTableAdapter.FilterByDept(Ist2dsDataSet.Employee, cmbDepartment.Text)
        '
        '        Else
        '            Me.EmployeeTableAdapter.Fill(Me.Ist2dsDataSet.Employee)
        '        End If

    End Sub

    Private Sub btnFilterByDeptProtected_Click(sender As Object, e As EventArgs) Handles btnFilterByDeptProtected.Click
        FunctionResources.filterEmployee(cmbDepartment.Text, True)
    End Sub

    'search
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        FunctionResources.searchEmployee(Me, txtSearchEmployeeID.Text, txtSearchEmployeeFirstName.Text, txtSearchEmployeeLastName.Text, cmbDepartment.Text)
    End Sub

    'choose position (when updating)
    Private Sub btnChoose_Click(sender As Object, e As EventArgs) Handles btnChoose.Click
        MenuForm.openPositionAsView(PositionForm.EmployeeUpdate, "All")
    End Sub

    'finalise updates
    Private Sub btnUpdateEmployee_Click(sender As Object, e As EventArgs) Handles btnUpdateEmployee.Click
        FunctionResources.updateEmployeeFin(txtEmployeeID.Text, txtMonthlySalary.Text, txtBankName.Text, txtBranchCode.Text, txtBankAcctNo.Text, txtBranchName.Text, txtTaxNo.Text, txtPosition.Text)
        FunctionResources.updateEmployeeGen(txtEmployeeID.Text, txtFirstName.Text, txtLastName.Text, cboxDisability.Checked, txtPhoneNum.Text, txtEmailAddress.Text, txtStreet.Text, txtCity.Text, txtPostCode.Text)
    End Sub
End Class