﻿Public Class AddNewPersonForm
    'FIELDS AND CONSTANTS
    Public Type As Integer
    Public Const Applicant = 0
    Public Const Employee = 1

    'INITIALIZATION
    Private Sub AddNewPersonForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    '_____________________________________________________________________________________________
    'BUTTON EVENT HANDLERS
    Private Sub btnChoose_Click(sender As Object, e As EventArgs) Handles btnChoose.Click
        'only enabled for calling when making new applicant, not new employee
        MenuForm.openPositionAsView(Applicant, ApplicantForm.Dept)
    End Sub

    Private Sub BtnFinAdd_Click(sender As Object, e As EventArgs) Handles btnFinAdd.Click
        If Type = Applicant Then
            FunctionResources.addApplicant(txtIDNum.Text, txtFirstName.Text, txtLastName.Text, cmbGender.Text, cmbRace.Text, cboxDisability.Checked, txtPosition.Text, txtPhoneNum.Text, txtEmail.Text, txtStreet.Text, txtCity.Text, txtPostCode.Text)
        Else 'Type = employee i.e hiring
            FunctionResources.addEmployee(txtIDNum.Text, txtFirstName.Text, txtLastName.Text, cmbGender.Text, cmbRace.Text, cboxDisability.Checked, DateTimePickerHired.Value, txtMonthlySalary.Text, txtBankName.Text, txtBranchCode.Text, txtBankAcctNo.Text, txtBranchName.Text, txtTaxNo.Text, txtPosition.Text, txtPhoneNum.Text, txtEmail.Text, txtStreet.Text, txtCity.Text, txtPostCode.Text)
            FunctionResources.deleteApplicant(txtIDNum.Text)
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        If Type = Employee Then
            ApplicantForm.Hide()
            MenuForm.openEmployeesAsView()
        End If
    End Sub


End Class