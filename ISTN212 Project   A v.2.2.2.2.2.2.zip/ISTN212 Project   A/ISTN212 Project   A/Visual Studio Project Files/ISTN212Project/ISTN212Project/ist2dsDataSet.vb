﻿

Partial Public Class ist2dsDataSet
End Class


Partial Public Class ist2dsDataSet
End Class
