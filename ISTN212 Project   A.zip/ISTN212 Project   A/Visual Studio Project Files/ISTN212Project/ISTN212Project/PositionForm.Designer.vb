﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PositionForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PositionnameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AvailablepostsDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DepartmentDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PositionBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Ist2dsDataSet = New ISTN212Project.ist2dsDataSet()
        Me.btnPositionChanges = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cboxNewPosition = New System.Windows.Forms.CheckBox()
        Me.numUDPositionsAvailable = New System.Windows.Forms.NumericUpDown()
        Me.cmbDepartment = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPositionName = New System.Windows.Forms.TextBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.PositionTableAdapter = New ISTN212Project.ist2dsDataSetTableAdapters.PositionTableAdapter()
        Me.TableAdapterManager = New ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager()
        Me.btnSelectPosition = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PositionBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.numUDPositionsAvailable, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(525, 9)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(37, 16)
        Me.lblDate.TabIndex = 1
        Me.lblDate.Text = "Date"
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PositionnameDataGridViewTextBoxColumn, Me.AvailablepostsDataGridViewTextBoxColumn, Me.DepartmentDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.PositionBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 31)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(550, 215)
        Me.DataGridView1.TabIndex = 2
        '
        'PositionnameDataGridViewTextBoxColumn
        '
        Me.PositionnameDataGridViewTextBoxColumn.DataPropertyName = "position_name"
        Me.PositionnameDataGridViewTextBoxColumn.HeaderText = "position_name"
        Me.PositionnameDataGridViewTextBoxColumn.Name = "PositionnameDataGridViewTextBoxColumn"
        '
        'AvailablepostsDataGridViewTextBoxColumn
        '
        Me.AvailablepostsDataGridViewTextBoxColumn.DataPropertyName = "available_posts"
        Me.AvailablepostsDataGridViewTextBoxColumn.HeaderText = "available_posts"
        Me.AvailablepostsDataGridViewTextBoxColumn.Name = "AvailablepostsDataGridViewTextBoxColumn"
        '
        'DepartmentDataGridViewTextBoxColumn
        '
        Me.DepartmentDataGridViewTextBoxColumn.DataPropertyName = "department"
        Me.DepartmentDataGridViewTextBoxColumn.HeaderText = "department"
        Me.DepartmentDataGridViewTextBoxColumn.Name = "DepartmentDataGridViewTextBoxColumn"
        '
        'PositionBindingSource
        '
        Me.PositionBindingSource.DataMember = "Position"
        Me.PositionBindingSource.DataSource = Me.Ist2dsDataSet
        '
        'Ist2dsDataSet
        '
        Me.Ist2dsDataSet.DataSetName = "ist2dsDataSet"
        Me.Ist2dsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnPositionChanges
        '
        Me.btnPositionChanges.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnPositionChanges.Location = New System.Drawing.Point(240, 147)
        Me.btnPositionChanges.Name = "btnPositionChanges"
        Me.btnPositionChanges.Size = New System.Drawing.Size(296, 32)
        Me.btnPositionChanges.TabIndex = 0
        Me.btnPositionChanges.Text = "Add"
        Me.btnPositionChanges.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox3.Controls.Add(Me.cboxNewPosition)
        Me.GroupBox3.Controls.Add(Me.numUDPositionsAvailable)
        Me.GroupBox3.Controls.Add(Me.cmbDepartment)
        Me.GroupBox3.Controls.Add(Me.btnPositionChanges)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Controls.Add(Me.txtPositionName)
        Me.GroupBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GroupBox3.Location = New System.Drawing.Point(12, 252)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(550, 189)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Details"
        '
        'cboxNewPosition
        '
        Me.cboxNewPosition.AutoSize = True
        Me.cboxNewPosition.Checked = True
        Me.cboxNewPosition.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cboxNewPosition.Location = New System.Drawing.Point(178, 21)
        Me.cboxNewPosition.Name = "cboxNewPosition"
        Me.cboxNewPosition.Size = New System.Drawing.Size(148, 20)
        Me.cboxNewPosition.TabIndex = 52
        Me.cboxNewPosition.Text = "Create New Position"
        Me.cboxNewPosition.UseVisualStyleBackColor = True
        '
        'numUDPositionsAvailable
        '
        Me.numUDPositionsAvailable.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PositionBindingSource, "available_posts", True))
        Me.numUDPositionsAvailable.Location = New System.Drawing.Point(415, 107)
        Me.numUDPositionsAvailable.Name = "numUDPositionsAvailable"
        Me.numUDPositionsAvailable.Size = New System.Drawing.Size(121, 22)
        Me.numUDPositionsAvailable.TabIndex = 49
        '
        'cmbDepartment
        '
        Me.cmbDepartment.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PositionBindingSource, "department", True))
        Me.cmbDepartment.FormattingEnabled = True
        Me.cmbDepartment.Items.AddRange(New Object() {"Accounting", "Administration", "Engineering", "Finance", "Human Resources", "IT", "Marketing", "Sales", "All"})
        Me.cmbDepartment.Location = New System.Drawing.Point(240, 75)
        Me.cmbDepartment.Name = "cmbDepartment"
        Me.cmbDepartment.Size = New System.Drawing.Size(296, 24)
        Me.cmbDepartment.TabIndex = 48
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(17, 78)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(118, 16)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Department name:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(17, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Position name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(17, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(189, 16)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Number of positions available:"
        '
        'txtPositionName
        '
        Me.txtPositionName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PositionBindingSource, "position_name", True))
        Me.txtPositionName.Location = New System.Drawing.Point(240, 47)
        Me.txtPositionName.Name = "txtPositionName"
        Me.txtPositionName.Size = New System.Drawing.Size(296, 22)
        Me.txtPositionName.TabIndex = 2
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(12, 515)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(98, 31)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'PositionTableAdapter
        '
        Me.PositionTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AbsenceTableAdapter = Nothing
        Me.TableAdapterManager.ApplicantTableAdapter = Nothing
        Me.TableAdapterManager.AppointmentTableAdapter = Nothing
        Me.TableAdapterManager.Appt_guestTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComplaintTableAdapter = Nothing
        Me.TableAdapterManager.EmployeeTableAdapter = Nothing
        Me.TableAdapterManager.PositionTableAdapter = Me.PositionTableAdapter
        Me.TableAdapterManager.UpdateOrder = ISTN212Project.ist2dsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'btnSelectPosition
        '
        Me.btnSelectPosition.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSelectPosition.Location = New System.Drawing.Point(12, 460)
        Me.btnSelectPosition.Name = "btnSelectPosition"
        Me.btnSelectPosition.Size = New System.Drawing.Size(547, 31)
        Me.btnSelectPosition.TabIndex = 7
        Me.btnSelectPosition.Text = "Select"
        Me.btnSelectPosition.UseVisualStyleBackColor = True
        '
        'PositionForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.ISTN212Project.My.Resources.Resources.darkgon
        Me.ClientSize = New System.Drawing.Size(571, 558)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnSelectPosition)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.lblDate)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "PositionForm"
        Me.Text = "PositionForm"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PositionBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ist2dsDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.numUDPositionsAvailable, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblDate As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents btnPositionChanges As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents txtPositionName As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cmbDepartment As ComboBox
    Friend WithEvents numUDPositionsAvailable As NumericUpDown
    Friend WithEvents Ist2dsDataSet As ist2dsDataSet
    Friend WithEvents PositionBindingSource As BindingSource
    Friend WithEvents PositionTableAdapter As ist2dsDataSetTableAdapters.PositionTableAdapter
    Friend WithEvents TableAdapterManager As ist2dsDataSetTableAdapters.TableAdapterManager
    Friend WithEvents PositionnameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AvailablepostsDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DepartmentDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents cboxNewPosition As CheckBox
    Friend WithEvents btnSelectPosition As Button
End Class
