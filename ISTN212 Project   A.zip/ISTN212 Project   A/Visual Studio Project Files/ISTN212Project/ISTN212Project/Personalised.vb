﻿Public Class Personalised

    Public picture As Image


    Private Sub Personalised_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        If ComboBox1.SelectedItem = "Background1" Then
            PictureBox1.BackgroundImage = My.Resources.darkgon
            picture = My.Resources.darkgon
        ElseIf ComboBox1.SelectedItem = "Background2" Then
            PictureBox1.BackgroundImage = My.Resources.Leelou_Designs_December_Mobile_Background
            picture = My.Resources.Leelou_Designs_December_Mobile_Background
        End If
    End Sub

    Private Sub btnApply_Click(sender As Object, e As EventArgs) Handles btnApply.Click
        MenuForm.BackgroundImage = picture
        Me.BackgroundImage = picture
        LoginForm.BackgroundImage = picture
        EmployeeForm.BackgroundImage = picture
        ApplicantForm.BackgroundImage = picture
        ComplaintsForm.BackgroundImage = picture
        PositionForm.BackgroundImage = picture
        AppointmentForm.BackgroundImage = picture
        AbsenceForm.BackgroundImage = picture
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        MenuForm.Show()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub
End Class