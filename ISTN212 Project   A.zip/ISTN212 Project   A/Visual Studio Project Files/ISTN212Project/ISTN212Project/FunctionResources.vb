﻿Public Class FunctionResources



    '_________________________________________________________________________________________________________________
    'ADDING
    Public Shared Sub addAbsence(num As Integer, employeeID As String, absStart As String, absEnd As String, type As String)
        'validate inputs. if valid:
        If Not (hasClashingAbsence(employeeID, absStart, absEnd)) Then
            AbsenceForm.AbsenceTableAdapter.InsertAbsence(num, employeeID, absStart, absEnd, type)
        Else
            'msg fault
        End If

    End Sub

    Public Shared Sub addApplicant(id As String, fnam As String, lnam As String, gender As String, race As String, disability As Boolean, position As String, phoneNum As String, email As String, street As String, city As String, postcode As String)
        Dim flagged As Boolean = False

        If Not emailValid(email) Then
            'message
            flagged = True
        End If

        If Not IDValid(id) Then
            'message
            flagged = True
        End If

        If Not PhoneNumValid(phoneNum) Then
            'message
            flagged = True
        End If
        If fnam = vbNullString Then
            'message
            flagged = True
        End If

        If lnam = vbNullString Then
            'message
            flagged = True
        End If

        If position = vbNullString Then
            'message
            flagged = True
        End If

        If gender = vbNullString Then
            'message
            flagged = True
        End If

        If race = vbNullString Then
            'message
            flagged = True
        End If

        If city = vbNullString Then
            'message
            flagged = True
        End If

        If street = vbNullString Then
            'message
            flagged = True
        End If

        If postcode = vbNullString Then
            'message
            flagged = True
        End If



        If Not flagged Then
            'do sql
        End If

    End Sub

    Public Shared Sub addAppointment(aptDate As String, startHr As Integer, startMin As Integer, endHr As Integer, endMin As Integer, desc As String)
    End Sub

    Public Shared Sub addAppt_Guest(aptNum As Integer, empID As String)
        'do sql adding: it is already ensured that the employee has no other appointment during this time
    End Sub

    Public Shared Sub addComplaint(compdate As Date, target As String, untargetted As Boolean, desc As String)
        'validate
        'do sql adding
    End Sub

    Public Shared Sub addEmployee(id As String, fnam As String, lnam As String, gender As String, race As String, disability As Boolean, dateHired As String, monthlySal As Integer, bankNam As String, bankBranchCode As String, bankacctnum As String, bankBranchNam As String, taxNo As String, position As String, phoneNum As String, email As String, street As String, city As String, postcode As String)
        Dim flagged As Boolean = False

        If emailValid(email) Then
            'message
            flagged = True
        End If

        If IDValid(id) Then
            'message
            flagged = True
        End If

        If PhoneNumValid(phoneNum) Then
            'message
            flagged = True
        End If

        If fnam = vbNullString Then
            'message
            flagged = True
        End If

        If lnam = vbNullString Then
            'message
            flagged = True
        End If

        If monthlySal = 0 Then
            'message
            flagged = True
        End If

        If bankNam = vbNullString Then
            'message
            flagged = True
        End If

        If bankacctnum = vbNullString Then
            'message
            flagged = True
        End If

        If bankBranchCode = vbNullString Then
            'message
            flagged = True
        End If

        If bankBranchNam = vbNullString Then
            'message
            flagged = True
        End If

        If taxNo = vbNullString Then
            'message
            flagged = True
        End If

        If position = vbNullString Then
            'message
            flagged = True
        End If

        If city = vbNullString Then
            'message
            flagged = True
        End If

        If street = vbNullString Then
            'message
            flagged = True
        End If

        If postcode = vbNullString Then
            'message
            flagged = True
        End If




        If Not flagged Then
            'do sql
        End If

    End Sub

    Public Shared Sub addPosition(positionName As String, dept As String, availablePosts As Integer)

    End Sub


    '_________________________________________________________________________________________________________________
    'UPDATING
    Public Shared Sub addressComplaint(dateIssued As Date, isUntargetted As Boolean, target As String, desc As String)

    End Sub

    Public Shared Sub rescheduleAppointment(aptDate As Date, startHr As Integer, startMin As Integer, endHr As Integer, endMin As Integer, desc As String)

    End Sub

    Public Shared Sub setApplicantInterview(appID As String, apptNum As Integer)
        'open the appointments form in add mode. 
        'after calling addAppointment(), set appointment in Applicant to the newly made appointment 
    End Sub

    Public Shared Sub updateEmployeeGen(id As String, fnam As String, lnam As String, disability As Boolean, phoneNum As String, email As String, street As String, city As String, postcode As String)

    End Sub

    Public Shared Sub updateEmployeeFin(id As String, monthlySal As Integer, bankNam As String, bankBranchCode As String, bankacctnum As String, bankBranchNam As String, taxNo As String, position As String)

    End Sub

    Public Shared Sub terminateEmployee(id As String, type As String, termDate As Date)

    End Sub

    Public Shared Sub updateAvailablePosts(positionName As String, newNum As Integer)

    End Sub

    '_________________________________________________________________________________________________________________
    'DELETING

    Public Shared Sub clearTerminationHistory()
        'do sql delete
    End Sub

    Public Shared Sub deleteAppointment(apptNum As Integer)
    End Sub

    Public Shared Sub removeApptGuest(aptNum As Integer, empID As String)

    End Sub

    Public Shared Sub cancelLeave(EmpID As String, StartDate As Date)

    End Sub

    Public Shared Sub deleteApplicant(appID As String)

    End Sub
    'no function needed directly to delete complaint
    'no function needed to delete position

    '__________________________________________________________________________________________________________________
    'SEARCH AND FILTER
    Public Shared Sub searchComplaints(allDays As Boolean, complaintDate As Date, untargetted As Boolean, target As String)
        If untargetted Then
            target = "NULL"
        End If
        If Not (IDValid(target) And complaintDate < Today) Then
            'flag
            'message
        Else

        End If

        If allDays And untargetted Then
            'select * from complaints
        ElseIf allDays Then
            'select * from complaints where employee_ID=@ID
        ElseIf untargetted Then
            'select * from complaints where complaint_date = @cdate
        Else
            'select * from complaints where complaint_date = @cdate and employee_ID=@ID
        End If
    End Sub

    Public Shared Sub searchEmployee(caller As Form, id As String, fnam As String, lnam As String, dept As String)
    End Sub

    Public Shared Sub filterEmployee(dept As String, protectedOnly As Boolean)
    End Sub

    Public Shared Sub searchApplicant(id As String, fnam As String, lnam As String, dept As String)
    End Sub

    Public Shared Sub filterApplicants(dept As String, protectedOnly As Boolean)
    End Sub

    Public Shared Sub filterPosition(dept As String)
    End Sub

    Public Shared Sub filterAbsences(allDays As Boolean, absDate As Date, allEmp As Boolean, empID As String)

    End Sub

    Public Shared Sub filterAppointments(aptDate As Date)

    End Sub


    '__________________________________________________________________________________________________________________
    'OTHER FUNCTIONS AND SUBS
    Public Shared Function emailValid(email As String)
        Return True
    End Function

    Public Shared Function IDValid(ID As String)
        Return True
    End Function

    Public Shared Function hasClashingAbsence(employeeID As String, absStart As String, absEnd As String)
        If "sql number of absences coinciding with this range for the employee > 0 " Then
            Return False
        End If

        Return True

    End Function

    Public Shared Function PhoneNumValid(phoneNum As String)
        Return True
    End Function



    Private Shared Sub sendEmail()
        'nikiel put this on on Github
    End Sub

    Public Shared Sub sendEmailtoMany(toAddresses As ArrayList)
        'for loop; call send Email for each address in toAddresses 
    End Sub

End Class
