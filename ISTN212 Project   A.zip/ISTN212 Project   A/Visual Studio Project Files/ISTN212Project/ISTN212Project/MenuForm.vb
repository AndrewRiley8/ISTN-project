﻿Public Class MenuForm

    Private Sub MenuForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDateTime.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    'sign out button click
    Private Sub btnSignOut_Click(sender As Object, e As EventArgs) Handles btnSignOut.Click
        LoginForm.Show()
        Me.Hide()
        LoginForm.tbPassword.Text = ""
        LoginForm.tbUserName.Text = ""
        LoginForm.Proceed = True

    End Sub

    'about button click
    Private Sub btnAbout_Click(sender As Object, e As EventArgs) Handles btnAbout.Click
        MessageBox.Show("r/programmerhumor HRMU (Human Resource Management Utility) V1.0.0", "About:")
    End Sub

    'help picture box click'
    Private Sub pboxHelp_Click(sender As Object, e As EventArgs) Handles pboxHelp.Click
        Process.Start("www.youtube.com")
    End Sub

    'personalisation button click'
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Personalised.Show()
        Me.Hide()
    End Sub




    'MENUSTRIP BUTTONS'
    Private Sub OpenApplicants(Dept As String)
        Me.Hide()
        'let the dgview on the applicant form hold:  select * from applicant where position_ID IN (select * from position where department = @Dept) 
        ApplicantForm.Show()
    End Sub
    'HIRING SECTION'
    Private Sub AccountingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccountingToolStripMenuItem.Click
        OpenApplicants("Accounting")
    End Sub

    Private Sub AdministrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdministrationToolStripMenuItem.Click
        OpenApplicants("Administration")
    End Sub

    Private Sub EngineeringToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EngineeringToolStripMenuItem.Click
        OpenApplicants("Engineering")
    End Sub

    Private Sub HumanResourcesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HumanResourcesToolStripMenuItem.Click
        OpenApplicants("Human Resources")
    End Sub

    Private Sub ITToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ITToolStripMenuItem.Click
        OpenApplicants("IT")
    End Sub

    Private Sub MarketingToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MarketingToolStripMenuItem.Click
        OpenApplicants("Marketing")
    End Sub

    Private Sub SalesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalesToolStripMenuItem.Click
        OpenApplicants("Sales")
    End Sub

    Private Sub AllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AllToolStripMenuItem.Click
        OpenApplicants("empty' OR 1=1")

    End Sub


    'TERMINATION SECTION'
    Private Sub TermEmplToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TermEmplToolStripMenuItem.Click

    End Sub

    Private Sub ViewTerminationHistoryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewTerminationHistoryToolStripMenuItem.Click

    End Sub




    'GENERAL SECTION'
    'COMPLAINTS'
    Private Sub ViewAllComplaintsToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ViewAllComplaintsToolStripMenuItem1.Click
        Me.Hide()
        ComplaintsForm.Show()
    End Sub

    Private Sub AddNewComplaintToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AddNewComplaintToolStripMenuItem1.Click

    End Sub

    'ABSENCES'
    Private Sub ViewAllAbsencesToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ViewAllAbsencesToolStripMenuItem2.Click
        Me.Hide()
        AbsenceForm.Show()
    End Sub

    Private Sub AddNewAbsenceToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles AddNewAbsenceToolStripMenuItem2.Click

    End Sub



    'EDIT GENERAL DETAILS'

    Private Sub EditGenEmployeeDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditGenEmployeeDetailsToolStripMenuItem.Click
        Me.Hide()

        EmployeeForm.Show()
        EmployeeForm.ButtonFinHire.Visible = False

    End Sub



    'PAYMENT SECTION'
    Private Sub EditEmployeePayementDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditEmployeePayementDetailsToolStripMenuItem.Click
        Me.Hide()
        EmployeeForm.Show()
    End Sub

    Private Sub MakeMonthlyPaymentsToolStripMenuItem_Click(sender As Object, e As EventArgs)
        'I am a dummy'
    End Sub



    'APPOINTMENT SECTION'

    Private Sub ViewAllAppointmentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewAllAppointmentsToolStripMenuItem.Click
        Me.Hide()
        AppointmentForm.Show()
    End Sub

    Private Sub AddNewAppointmentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddNewAppointmentToolStripMenuItem.Click

    End Sub

    'MISC SECTION'




End Class