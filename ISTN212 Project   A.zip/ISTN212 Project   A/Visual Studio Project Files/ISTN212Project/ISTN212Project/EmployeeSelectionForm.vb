﻿Public Class EmployeeSelectionForm
    Public caller As Integer
    Public Const Complaints = 0
    Public Const Absences = 1
    Public Const Terminations = 2

    Private Sub EmployeeSelectionForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Employee' table. You can move, or remove it, as needed.
        Me.EmployeeTableAdapter.Fill(Me.Ist2dsDataSet.Employee)

    End Sub
    '_________________________________________________________________________________________________________________________
    'BUTTON EVENT HANDLERS
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        FunctionResources.searchEmployee(Me, txtEmployeeID.Text, txtEmployeeFirstName.Text, txtEmployeeLastName.Text, cmbDepartment.Text)
    End Sub

    Private Sub btnSelect_Click(sender As Object, e As EventArgs) Handles btnSelect.Click
        Me.Hide()

        Select Case caller
            Case Complaints
                'move data: PROBLEMATIC
                ComplaintsForm.txtEmployeeID.Text = txtEmployeeID.Text
            Case Absences
                'move data: PROBLEMATIC
                AbsenceForm.txtEmployeeID.Text = txtEmployeeID.Text
            Case Terminations
                'move data: PROBLEMATIC
                EmployeeTerminateForm.txtEmployeeID.Text = txtEmployeeID.Text
        End Select

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
    End Sub
End Class