﻿Public Class ApplicantForm
    Private Sub ApplicantForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub
    'back button'
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()
    End Sub

    Private Sub ApplicantForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Applicant' table. You can move, or remove it, as needed.

        'TODO: This line of code loads data into the 'Ist2dsDataSet.Applicant' table. You can move, or remove it, as needed.
        Me.ApplicantTableAdapter.Fill(Me.Ist2dsDataSet.Applicant)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        EmployeeForm.Hiring = True
        EmployeeForm.Show()
        'enter fields from applicant to employee

        Dim f As String = Button2.Name





    End Sub
End Class