﻿Public Class ComplaintsForm
    Private Sub ComplaintsForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub ComplaintsForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Complaint' table. You can move, or remove it, as needed.
        Me.ComplaintTableAdapter.Fill(Me.Ist2dsDataSet.Complaint)

    End Sub

    Private Sub cboxSearchUntargetted_CheckedChanged(sender As Object, e As EventArgs) Handles cboxSearchUntargetted.CheckedChanged
        If cboxSearchUntargetted.Checked Then
            txtSearchEmployeeID.Enabled = False
        Else
            txtSearchEmployeeID.Enabled = True

        End If
    End Sub
    Private Sub cboxUntargetted_CheckedChanged(sender As Object, e As EventArgs) Handles cboxUntrgetted.CheckedChanged
        If cboxSearchUntargetted.Checked Then
            txtEmployeeID.Enabled = False
            btnChooseTarget.Enabled = False
        Else
            btnChooseTarget.Enabled = True
            txtEmployeeID.Enabled = True

        End If
    End Sub
    '____________________________________________________________________________________________________________________________________
    'BELOW THIS POINT ARE ALL THE BUTTON EVENT HANDLERS FOR COMPLAINTSFORM

    Private Sub BbtnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()

    End Sub
    Private Sub btnChooseTarget_Click(sender As Object, e As EventArgs) Handles btnChooseTarget.Click
        Me.Hide()
        EmployeeSelect_TerminateForm.GroupBox2.Visible = False
        EmployeeSelect_TerminateForm.btnClearHistory.Visible = False
        EmployeeSelect_TerminateForm.btnSelect.Visible = True
        EmployeeSelect_TerminateForm.Show()
    End Sub

    Private Sub BtnSeacrh_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        FunctionResources.searchComplaints(cboxDate.Checked, DateTimePicker1.Value, cboxSearchUntargetted.Checked, txtSearchEmployeeID.Text)
    End Sub

    Private Sub btnAddressComplaint_Click(sender As Object, e As EventArgs) Handles btnAddressComplaint.Click
        'the parameter here must be determined from the complaint selected in the datagrid
        Dim complaintNum As Integer = 0 'get value from datagrid
        FunctionResources.addressComplaint(complaintNum)
    End Sub

    Private Sub btnAddComplaint_Click(sender As Object, e As EventArgs) Handles btnAddComplaint.Click
        FunctionResources.addComplaint(DateTimePickerIssued.Value, txtEmployeeID.Text, cboxSearchUntargetted.Checked, txtDescription.Text)
    End Sub


End Class