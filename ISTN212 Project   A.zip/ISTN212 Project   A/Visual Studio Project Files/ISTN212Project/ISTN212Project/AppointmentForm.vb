﻿Public Class AppointmentForm
    Private Sub AppointmentForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub


    Private Sub AppointmentForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.Ist2dsDataSet.Appointment)
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.Ist2dsDataSet.Appointment)
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.Ist2dsDataSet.Appointment)

    End Sub
    '_________________________________________________________________________________________________________________________________________
    'BELOW THIS POINT ARE THE BUTTON EVENT HANDLERS FOR APPOINTMENT FORM
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()

    End Sub

    Private Sub btnChangeDateTime_Click(sender As Object, e As EventArgs) Handles btnChangeDateTime.Click

    End Sub

    Private Sub btnShowGuests_Click(sender As Object, e As EventArgs) Handles btnShowGuests.Click
        Me.Hide()
        ApptGuestForm.Show()
    End Sub

    Private Sub btnDeleteAppointment_Click(sender As Object, e As EventArgs) Handles btnDeleteAppointment.Click

    End Sub

    Private Sub btnAddAppointment_Click(sender As Object, e As EventArgs) Handles btnAddAppointment.Click
        'FunctionResources.addAppointment()
    End Sub
End Class