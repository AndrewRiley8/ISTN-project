﻿Public Class AbsenceForm
    Private Sub AbsenceForm_Shown(sender As Object, e As EventArgs) Handles MyBase.Shown
        lblDate.Text = Date.Now.ToString("yyyy/MM/dd")
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        MenuForm.Show()

    End Sub

    Private Sub AbsenceForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Ist2dsDataSet.Absence' table. You can move, or remove it, as needed.
        Me.AbsenceTableAdapter.Fill(Me.Ist2dsDataSet.Absence)

    End Sub
End Class